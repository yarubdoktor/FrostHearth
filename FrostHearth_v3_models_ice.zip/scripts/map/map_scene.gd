extends "res://scripts/map/map_core.gd"
## الطبقة 2/5 — مشهد خريطة الإقليم الصغير: أرض ثلجية مولّدة برمجيًا، أربع مدن،
## مبنى «عرس الإقليم» في المنتصف، وموارد ووحوش من ملف JSON.


# ================================================================ البيئة
func _setup_env() -> void:
	env = Environment.new()
	sky_mat = ProceduralSkyMaterial.new()
	var sky := Sky.new()
	sky.sky_material = sky_mat
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_ACES
	env.tonemap_white = 1.1
	env.fog_enabled = true
	env.glow_enabled = true
	env.glow_intensity = 0.4
	env.glow_hdr_threshold = 1.45
	env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SOFTLIGHT
	env.adjustment_enabled = true
	# المرحلة 33: تشبّع أغنى على خريطة الإقليم أيضًا — اتساق مع مدينة الصقيع
	env.adjustment_saturation = 1.12
	env.adjustment_contrast = 1.06
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-46, -28, 0)
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 160.0
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	sun.directional_shadow_blend_splits = true
	add_child(sun)
	_apply_daytime()


func _apply_daytime() -> void:
	if night:
		sky_mat.sky_top_color = Color("101826")
		sky_mat.sky_horizon_color = Color("2a3346")
		sky_mat.ground_horizon_color = Color("2a3346")
		sky_mat.ground_bottom_color = Color("101826")
		env.ambient_light_energy = 0.3
		env.fog_light_color = Color("222b3c")
		env.fog_density = 0.0022
		sun.light_color = Color("c4d0f0")
		sun.light_energy = 0.35
	else:
		sky_mat.sky_top_color = Color("6d95ba")
		sky_mat.sky_horizon_color = Color("e9e8da")
		sky_mat.ground_horizon_color = Color("dde2e9")
		sky_mat.ground_bottom_color = Color("a8b6c6")
		env.ambient_light_energy = 0.5
		env.fog_light_color = Color("d6e2f0")
		env.fog_density = 0.0016
		sun.light_color = Color("ffe4b8")
		sun.light_energy = 1.05


# ================================================================ ضباب الحرب
func _setup_fog() -> void:
	## الإقليم الصغير مكشوف بالكامل — لا طائرة ضباب ولا كشف تدريجي
	pass


func _update_fog() -> void:
	## لا ضباب: تظهر اللوحات دومًا (يبقى الاتصال للتوافق مع إشارات الحالة)
	for fl in fog_labels:
		(fl["label"] as Label3D).visible = true


# ================================================================ الأرض والديكور
func _build_ground() -> void:
	## أرض الإقليم: سهل ثلجي مربّع + إطار جبلي يحدّ الخريطة بصريًا
	var size := float(data["size"])
	var ground := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(size, size)
	pm.subdivide_width = 16
	pm.subdivide_depth = 16
	var sm := StandardMaterial3D.new()
	sm.albedo_color = Color("dfe9f2")
	sm.roughness = 1.0
	ground.mesh = pm
	ground.material_override = sm
	ground.position = Vector3(size * 0.5, 0.0, size * 0.5)
	add_child(ground)
	# جبال محيطة (حلقة مقعّرة حول الأرض)
	var rock_mat := StandardMaterial3D.new()
	rock_mat.albedo_color = Color("9fb0c0")
	var ring := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = size * 0.5
	tm.outer_radius = size * 0.56
	tm.rings = 64
	ring.mesh = tm
	ring.material_override = rock_mat
	ring.position = Vector3(size * 0.5, -1.5, size * 0.5)
	add_child(ring)
	# بحيرة متجمدة صغيرة جنوب شرق المركز تكسر رتابة السهل
	var ice := MeshInstance3D.new()
	var ip := PlaneMesh.new()
	ip.size = Vector2(14, 10)
	var im := StandardMaterial3D.new()
	im.albedo_color = Color("bcd8e8")
	im.roughness = 0.25
	ice.mesh = ip
	ice.material_override = im
	ice.position = Vector3(74, 0.06, 68)
	ice.rotation.y = 0.6
	add_child(ice)
	# صنوبرات وطحالب صخرية متناثرة (بذرة ثابتة كي لا تتغير بين الجلسات)
	var rng := RandomNumberGenerator.new()
	rng.seed = 20260127
	var pine_mat := StandardMaterial3D.new()
	pine_mat.albedo_color = Color("3f6b52")
	var trunk_mat := StandardMaterial3D.new()
	trunk_mat.albedo_color = Color("6b5a48")
	var keep_out: Array = []
	for c in Defs.RIVAL_CITIES:
		keep_out.append(Vector2(float(c["x"]), float(c["y"])))
	keep_out.append(Vector2(float(Defs.AURS["x"]), float(Defs.AURS["y"])))
	keep_out.append(Vector2(float(Game.home.x) + 0.5, float(Game.home.y) + 0.5))
	for i in 70:
		var px := rng.randf_range(6.0, size - 6.0)
		var pz := rng.randf_range(6.0, size - 6.0)
		var ok := true
		for k in keep_out:
			if Vector2(px, pz).distance_to(k) < 12.0:
				ok = false
				break
		if not ok:
			continue
		var h := rng.randf_range(0.8, 1.6)
		var pine := MeshInstance3D.new()
		var cone := CylinderMesh.new()
		cone.top_radius = 0.0
		cone.bottom_radius = rng.randf_range(0.7, 1.1)
		cone.height = h * 2.2
		pine.mesh = cone
		pine.material_override = pine_mat
		pine.position = Vector3(px, h, pz)
		add_child(pine)
		var trunk := MeshInstance3D.new()
		var cyl := CylinderMesh.new()
		cyl.top_radius = 0.12
		cyl.bottom_radius = 0.16
		cyl.height = h * 0.8
		trunk.mesh = cyl
		trunk.material_override = trunk_mat
		trunk.position = Vector3(px, h * 0.4, pz)
		add_child(trunk)


# ================================================================ مبنى عرس الإقليم
func _build_aurs() -> void:
	## قاعة احتفالات إقليمية: قاعدة رخامية، قاعة عريضة، قبة ذهبية، وسارية يعلوها
	## علم يلوّن بلون المالك الحالي (يتحدث مع كل تغيّر عبر _on_region_changed)
	var p := Vector3(float(Defs.AURS["x"]), 0.0, float(Defs.AURS["y"]))
	aurs_root = Node3D.new()
	aurs_root.position = p
	add_child(aurs_root)
	var mat_wall := StandardMaterial3D.new()
	mat_wall.albedo_color = Color("e8dcc8")
	var mat_roof := StandardMaterial3D.new()
	mat_roof.albedo_color = Color("c9a24b")
	mat_roof.metallic = 0.35
	var mat_stone := StandardMaterial3D.new()
	mat_stone.albedo_color = Color("9aa7b5")
	# القاعدة والدرج
	_box(aurs_root, Vector3(15.0, 0.5, 15.0), Vector3(0, 0.25, 0), mat_stone)
	_box(aurs_root, Vector3(12.0, 0.4, 12.0), Vector3(0, 0.65, 0), mat_stone)
	_box(aurs_root, Vector3(4.0, 0.3, 1.6), Vector3(0, 0.35, 8.6), mat_stone)
	# القاعة الرئيسية
	_box(aurs_root, Vector3(9.0, 4.4, 9.0), Vector3(0, 3.1, 0), mat_wall)
	# القبة الذهبية
	var dome := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 4.1
	sm.height = 8.2
	dome.mesh = sm
	dome.material_override = mat_roof
	dome.position = Vector3(0, 5.3, 0)
	aurs_root.add_child(dome)
	# أعمدة الزوايا
	for dx in [-4.6, 4.6]:
		for dz in [-4.6, 4.6]:
			_cylinder(aurs_root, 0.45, 5.2, Vector3(dx, 2.9, dz), mat_wall)
	# السارية والعلم — لون العلم يعبّر عن المالك
	var pole := MeshInstance3D.new()
	var pcm := CylinderMesh.new()
	pcm.top_radius = 0.09
	pcm.bottom_radius = 0.09
	pcm.height = 7.5
	pole.mesh = pcm
	pole.material_override = mat_stone
	pole.position = Vector3(0, 7.6, 6.2)
	aurs_root.add_child(pole)
	aurs_flag_mat = StandardMaterial3D.new()
	aurs_flag_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	aurs_flag_mat.albedo_color = Color.WHITE
	var flag := MeshInstance3D.new()
	var fm := BoxMesh.new()
	fm.size = Vector3(2.8, 1.7, 0.06)
	flag.mesh = fm
	flag.material_override = aurs_flag_mat
	flag.position = Vector3(1.45, 10.2, 6.2)
	aurs_root.add_child(flag)
	# اللوح واللمعان الاحتفالي (مشاعل صغيرة حول القاعدة)
	aurs_label_pos = p + Vector3(0, 12.5, 0)
	aurs_label = _label3d("عرس الإقليم", aurs_label_pos, 42, Color("ffd36b"), 0)
	for i in 8:
		var a := TAU * float(i) / 8.0
		var torch := MeshInstance3D.new()
		var ts := SphereMesh.new()
		ts.radius = 0.22
		ts.height = 0.44
		torch.mesh = ts
		var tmat := StandardMaterial3D.new()
		tmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		tmat.albedo_color = Color("ffb066")
		tmat.emission_enabled = true
		tmat.emission = Color("ff9a4a")
		torch.material_override = tmat
		torch.position = Vector3(cos(a) * 8.2, 1.6, sin(a) * 8.2)
		aurs_root.add_child(torch)


func _box(parent: Node, size: Vector3, pos: Vector3, mat: StandardMaterial3D) -> void:
	var m := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	m.mesh = bm
	m.material_override = mat
	m.position = pos
	parent.add_child(m)


func _cylinder(parent: Node, radius: float, height: float, pos: Vector3, mat: StandardMaterial3D) -> void:
	var m := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = radius
	cm.bottom_radius = radius
	cm.height = height
	m.mesh = cm
	m.material_override = mat
	m.position = pos
	parent.add_child(m)


# ================================================================ توزيع العناصر
func _spawn_group(mesh: Mesh, items: Array, visual_scale := 1.0) -> void:
	var regions := {}
	for it in items:
		var key := Vector2i(int(it["x"]) / 30, int(it["y"]) / 30)
		if not regions.has(key):
			regions[key] = []
		regions[key].append(it)
	for key in regions:
		var arr: Array = regions[key]
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.mesh = mesh
		mm.instance_count = arr.size()
		for i in arr.size():
			var it: Dictionary = arr[i]
			var ry: float = it.get("ry", fmod(it["x"] * 12.9898 + it["y"] * 78.233, TAU))
			var b := Basis(Vector3.UP, ry).scaled(Vector3.ONE * visual_scale)
			mm.set_instance_transform(i, Transform3D(b, Vector3(it["x"], it["h"], it["y"])))
		var mmi := MultiMeshInstance3D.new()
		mmi.multimesh = mm
		add_child(mmi)


func _spawn_all() -> void:
	_build_ground()
	# الموارد
	for t in RES_NAMES:
		var items: Array = data["resources"].filter(func(r): return r["t"] == t)
		_spawn_group(_mesh_from("res://assets/res_%s.glb" % t), items, MapVisuals.RESOURCE_SCALE)
		for r in items:
			_reg(int(r["x"]), int(r["y"]), 1, {"kind": "res", "t": t, "l": r["l"],
					"x": int(r["x"]), "y": int(r["y"]), "pos": Vector3(r["x"], r["h"], r["y"])})
	# الوحوش
	for t in BEAST_NAMES:
		var items: Array = data["beasts"].filter(func(b): return b["t"] == t)
		_spawn_group(_mesh_from("res://assets/beast_%s.glb" % t), items)
		for b in items:
			_reg(int(b["x"]), int(b["y"]), 1, {"kind": "beast", "t": t, "l": b["l"],
					"x": int(b["x"]), "y": int(b["y"]), "pos": Vector3(b["x"], b["h"], b["y"])})
	# مدن الخصوم الثلاث — قوى الحرب على عرس الإقليم
	for c in data["cities"]:
		if str(c.get("team", "enemy")) != "enemy":
			continue
		var p := Vector3(c["x"], c["h"], c["y"])
		var info := {"kind": "city", "n": c["n"], "team": "enemy",
				"l": c["l"], "x": int(c["x"]), "y": int(c["y"]), "pos": p}
		_register_city(info)
		city_targets.append(info)
		var rc := Color(String(RegionWar.city_def(str(c["id"])).get("col", "ff9a8a")))
		var cl := _label3d(c["n"], p + Vector3(0, MapVisuals.CITY_LABEL_HEIGHT, 0), 26, rc, 90.0)
		fog_labels.append({"label": cl, "x": int(c["x"]), "y": int(c["y"])})
	# مدينتك
	var h: Dictionary = data["home"]
	h["x"] = Game.home.x + 0.5
	h["y"] = Game.home.y + 0.5
	h["l"] = Game.furnace_level()
	h["n"] = "مدينتي"
	home_pos = Vector3(h["x"], h["h"], h["y"])
	home_node = MeshInstance3D.new()
	home_node.mesh = _mesh_from(CitySkins.mesh_path(Game.city_skin))
	home_node.scale = Vector3.ONE * MapVisuals.CITY_SCALE
	home_node.position = home_pos
	add_child(home_node)
	home_label = _label3d("%s  %d" % [h["n"], h["l"]], home_pos + Vector3(0, MapVisuals.CITY_LABEL_HEIGHT, 0), 32, Color("ffd36b"), 0)
	home_info = {"kind": "city", "n": h["n"], "team": "me", "l": h["l"], "x": Game.home.x, "y": Game.home.y, "pos": home_pos}
	city_targets.append(home_info)
	_register_city(home_info)
	# عرس الإقليم — قلب الحرب في منتصف الإقليم
	_build_aurs()
	var ax := int(Defs.AURS["x"])
	var ay := int(Defs.AURS["y"])
	_reg(ax - 8, ay - 8, 17, {"kind": "aurs", "n": "عرس الإقليم", "id": "aurs",
			"x": ax, "y": ay, "pos": Vector3(float(ax), 0.0, float(ay)), "r": 8})
	# حلقة التحديد
	sel_ring = MeshInstance3D.new()
	var torus := TorusMesh.new()
	torus.inner_radius = 0.94
	torus.outer_radius = 1.0
	torus.rings = 48
	sel_ring.mesh = torus
	var rm := StandardMaterial3D.new()
	rm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	rm.albedo_color = Color("ffd36b")
	rm.no_depth_test = true
	sel_ring.material_override = rm
	sel_ring.visible = false
	add_child(sel_ring)
	# القوات
	troop_mesh = _mesh_from("res://assets/troop.glb")
	march_mat = StandardMaterial3D.new()
	march_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	march_mat.albedo_color = Color("7fd3ff")
	march_mat.no_depth_test = true
	march_mat.cull_mode = BaseMaterial3D.CULL_DISABLED


func apply_city_skin(id: String) -> void:
	# Never replace the node, transform, selection record or mission target.
	home_node.mesh = _mesh_from(CitySkins.mesh_path(id))


func _toggle_night() -> void:
	night = not night
	_apply_daytime()
	_on_view(rig.focus, rig.dist)


func _sync_marches() -> void:
	var alive := {}
	for m in Game.marches:
		var key := str(m["start"])
		alive[key] = true
		if not march_vis.has(key):
			var troop := MeshInstance3D.new()
			troop.mesh = troop_mesh
			add_child(troop)
			var line := MeshInstance3D.new()
			var im := ImmediateMesh.new()
			line.mesh = im
			line.material_override = march_mat
			line.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			add_child(line)
			march_vis[key] = {"troop": troop, "line": line, "im": im}
	# المرحلة 3: الفرقة العسكرية نحو المنفث (مفتاح ثابت ولون مميز)
	# يُسجل قبل حلقة التنظيف حتى لا يُهدم ويُعاد بناؤه كل إطار
	if not Game.venture.is_empty():
		alive["venture"] = true
		if not march_vis.has("venture"):
			var troop := MeshInstance3D.new()
			troop.mesh = troop_mesh
			add_child(troop)
			var line := MeshInstance3D.new()
			var im := ImmediateMesh.new()
			line.mesh = im
			var vm: StandardMaterial3D = march_mat.duplicate() as StandardMaterial3D
			vm.albedo_color = Color("ff9a4a")
			line.material_override = vm
			line.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			add_child(line)
			march_vis["venture"] = {"troop": troop, "line": line, "im": im}
	for key in march_vis.keys():
		if not alive.has(key):
			(march_vis[key]["troop"] as Node).queue_free()
			(march_vis[key]["line"] as Node).queue_free()
			march_vis.erase(key)


func _sync_sieges() -> void:
	## حصارات مدن الخصوم: مجسم قوة متحرك نحو عرس الإقليم وخط سير متقطع
	var alive := {}
	for s in Game.region.get("sieges", []):
		var key := str(s["id"])
		alive[key] = true
		if not siege_vis.has(key):
			var troop := MeshInstance3D.new()
			troop.mesh = troop_mesh
			var vm: StandardMaterial3D = march_mat.duplicate() as StandardMaterial3D
			vm.albedo_color = Color(RegionWar.city_def(str(s["city"])).get("col", "ff6a5a"))
			troop.material_override = vm
			add_child(troop)
			var line := MeshInstance3D.new()
			var im := ImmediateMesh.new()
			line.mesh = im
			line.material_override = vm
			line.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			add_child(line)
			siege_vis[key] = {"troop": troop, "line": line, "im": im}
	for key in siege_vis.keys():
		if not alive.has(key):
			(siege_vis[key]["troop"] as Node).queue_free()
			(siege_vis[key]["line"] as Node).queue_free()
			siege_vis.erase(key)
