extends Control
## شاشة خريطة مستقلة بكامل الشاشة، وليست نافذة منبثقة.
const MAP_SCRIPT = preload("res://scripts/world_map_canvas.gd")
const UITheme = preload("res://scripts/ui/ui_theme.gd")
const UIStrings = preload("res://scripts/ui/ui_strings.gd")
var map: Control
var province_id := "north_ridge"
var coords_label: Label
var detail_label: Label
var action_button: Button
var caravan_label: Label
var _caravan_ui_clock: float = 0.0
var _map_audit_clock: float = 0.0
var search_panel: PanelContainer
var x_input: LineEdit
var y_input: LineEdit
var saved_panel: PanelContainer
var selected_info: Dictionary = {}
var selected_kind := ""
var selected_id := ""
var saved_locations: Array[Dictionary] = []
var hud: Control

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_apply_map_theme()
	mouse_filter = Control.MOUSE_FILTER_STOP
	map = Control.new()
	map.set_script(MAP_SCRIPT)
	map.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	map.offset_top = UITheme.SAFE_FALLBACK_TOP + 112
	map.offset_bottom = -120
	map.offset_left = 0
	map.offset_right = 0
	map.set("province_id", province_id)
	map.connect("location_picked", _on_location_picked)
	add_child(map)
	saved_locations.assign(GameState.get_world_map_saved_locations(province_id))
	_build_hud()
	_enforce_map_minimums(hud)
	set_process(true)
	_refresh_caravan_counter()
	queue_redraw()

func _apply_map_theme() -> void:
	var th := Theme.new()
	var font := SystemFont.new()
	font.font_names = PackedStringArray(["Noto Sans Arabic", "Noto Naskh Arabic", "Droid Arabic Naskh", "Cairo", "Tajawal", "Arial", "Tahoma", "sans-serif"])
	font.allow_system_fallback = true
	th.default_font = font
	th.default_font_size = UITheme.FONT_BODY
	var panel_style := StyleBoxFlat.new()
	panel_style.bg_color = UITheme.NAVY
	panel_style.set_corner_radius_all(UITheme.PANEL_RADIUS)
	panel_style.set_border_width_all(1)
	panel_style.border_color = UITheme.BORDER
	panel_style.set_content_margin_all(16)
	th.set_stylebox("panel", "PanelContainer", panel_style)
	var button_style := StyleBoxFlat.new()
	button_style.bg_color = UITheme.NAVY_LIGHT
	button_style.set_corner_radius_all(16)
	button_style.set_content_margin_all(12)
	th.set_stylebox("normal", "Button", button_style)
	var pressed := StyleBoxFlat.new()
	pressed.bg_color = UITheme.AMBER
	pressed.set_corner_radius_all(16)
	th.set_stylebox("pressed", "Button", pressed)
	th.set_color("font_color", "Button", UITheme.ICE)
	th.set_color("font_color", "Label", UITheme.ICE)
	theme = th

func is_map_input_blocked(viewport_position: Vector2) -> bool:
	# هذه الدالة يستدعيها سكربت الخريطة قبل استهلاك الحدث في _input.
	# تمنع السحب من ابتلاع لمس الأزرار وحقول البحث، بما فيها زر إرسال القافلة.
	if is_instance_valid(search_panel) and search_panel.visible and search_panel.get_global_rect().has_point(viewport_position):
		return true
	if is_instance_valid(saved_panel) and saved_panel.visible and saved_panel.get_global_rect().has_point(viewport_position):
		return true
	if not is_instance_valid(hud):
		return false
	for control in hud.find_children("*", "Control", true, false):
		if not control is Control:
			continue
		var item: Control = control as Control
		if not item.is_visible_in_tree() or item.mouse_filter == Control.MOUSE_FILTER_IGNORE:
			continue
		if item is BaseButton or item is LineEdit or item is TextEdit or item is SpinBox or item is OptionButton:
			if item.get_global_rect().has_point(viewport_position):
				return true
	return false


func _build_hud() -> void:
	hud = Control.new(); hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); hud.mouse_filter = Control.MOUSE_FILTER_PASS; add_child(hud)
	var top := PanelContainer.new(); hud.add_child(top); top.anchor_left=0.0; top.anchor_right=1.0; top.offset_left=UITheme.SIDE_MARGIN; top.offset_right=-UITheme.SIDE_MARGIN; top.offset_top=UITheme.SAFE_FALLBACK_TOP; top.offset_bottom=UITheme.SAFE_FALLBACK_TOP+112
	var row := HBoxContainer.new(); row.layout_direction = Control.LAYOUT_DIRECTION_INHERITED; top.add_child(row)
	var back := Button.new(); back.text=UIStrings.T("close"); back.icon=load("res://assets/ui/icons/back.svg"); back.custom_minimum_size=Vector2(128,UITheme.BUTTON_HEIGHT); back.pressed.connect(func(): get_parent().call("close_world_map")); row.add_child(back)
	var title := Label.new(); title.text="خريطة المقاطعة"; title.size_flags_horizontal=Control.SIZE_EXPAND_FILL; title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; title.add_theme_font_size_override("font_size",UITheme.FONT_TITLE); row.add_child(title)
	var province := OptionButton.new(); province.custom_minimum_size=Vector2(210,UITheme.BUTTON_HEIGHT)
	var provinces:Array=GameState.province_data(); var chosen:=0
	for i in range(provinces.size()):
		province.add_item(str(provinces[i].get("name","مقاطعة")))
		if str(provinces[i].get("id",""))==province_id: chosen=i
	province.select(chosen); row.add_child(province)
	province.item_selected.connect(func(index:int):
		province_id=str(provinces[index].get("id","north_ridge"))
		map.call("set_province",province_id,74129+index*991)
		saved_locations.assign(GameState.get_world_map_saved_locations(province_id))
		selected_info = {}
		_refresh_coords()
	)
	var right := VBoxContainer.new(); hud.add_child(right); right.anchor_left=1.0; right.anchor_right=1.0; right.offset_left=-138; right.offset_right=-10; right.offset_top=220; right.offset_bottom=640
	for pair in [["مدينتي","my_city","city"],["بحث","search","map"],["نظرة عامة","overview","map"],["المحفوظات","saved","mission"]]:
		var b:=Button.new(); b.text=pair[0]; b.icon=load("res://assets/ui/icons/%s.svg" % pair[2]); b.custom_minimum_size=Vector2(126,UITheme.BUTTON_HEIGHT); b.pressed.connect(_side_action.bind(str(pair[1]))); right.add_child(b)
	var bottom := PanelContainer.new(); hud.add_child(bottom); bottom.anchor_left=0; bottom.anchor_right=1; bottom.anchor_top=1; bottom.anchor_bottom=1; bottom.offset_left=10; bottom.offset_right=-10; bottom.offset_top=-120; bottom.offset_bottom=-8
	var b_row:=HBoxContainer.new(); bottom.add_child(b_row)
	var search:=Button.new(); search.text="بحث"; search.icon=load("res://assets/ui/icons/map.svg"); search.custom_minimum_size=Vector2(110,UITheme.BUTTON_HEIGHT); search.pressed.connect(_show_search); b_row.add_child(search)
	coords_label=Label.new(); coords_label.text="#1  X:600  Y:600"; coords_label.size_flags_horizontal=Control.SIZE_EXPAND_FILL; coords_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; coords_label.add_theme_font_size_override("font_size",UITheme.FONT_DETAIL); b_row.add_child(coords_label)
	caravan_label=Label.new(); caravan_label.text="القوافل: 0/1"; caravan_label.custom_minimum_size=Vector2(140,0); caravan_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; b_row.add_child(caravan_label)
	var star:=Button.new(); star.text="☆"; star.custom_minimum_size=Vector2(88,UITheme.BUTTON_HEIGHT); star.pressed.connect(_save_selected); b_row.add_child(star)
	detail_label=Label.new(); detail_label.text="اضغط على مدينة أو مورد أو قبيلة لعرض التفاصيل"; detail_label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; detail_label.add_theme_font_size_override("font_size",UITheme.FONT_DETAIL); detail_label.mouse_filter=Control.MOUSE_FILTER_IGNORE; hud.add_child(detail_label); detail_label.anchor_left=0; detail_label.anchor_right=0.78; detail_label.anchor_top=0; detail_label.anchor_bottom=0; detail_label.offset_left=14; detail_label.offset_right=0; detail_label.offset_top=98; detail_label.offset_bottom=188
	action_button=Button.new(); action_button.visible=false; action_button.custom_minimum_size=Vector2(0,UITheme.BUTTON_HEIGHT); action_button.anchor_left=0.04; action_button.anchor_right=0.96; action_button.anchor_top=1; action_button.anchor_bottom=1; action_button.offset_left=0; action_button.offset_right=0; action_button.offset_top=-208; action_button.offset_bottom=-104; hud.add_child(action_button)
	search_panel=PanelContainer.new(); hud.add_child(search_panel); search_panel.visible=false; search_panel.anchor_left=0.12; search_panel.anchor_right=0.88; search_panel.anchor_top=0.35; search_panel.anchor_bottom=0.58
	var sv:=VBoxContainer.new(); search_panel.add_child(sv)
	var sh:=Label.new(); sh.text="اذهب إلى X,Y"; sh.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; sv.add_child(sh)
	var fields:=HBoxContainer.new(); sv.add_child(fields)
	x_input=LineEdit.new(); x_input.placeholder_text="X (0–1199)"; x_input.text="600"; x_input.size_flags_horizontal=Control.SIZE_EXPAND_FILL; fields.add_child(x_input)
	y_input=LineEdit.new(); y_input.placeholder_text="Y (0–1199)"; y_input.text="600"; y_input.size_flags_horizontal=Control.SIZE_EXPAND_FILL; fields.add_child(y_input)
	var go:=Button.new(); go.text="انتقال"; go.pressed.connect(_go_to_coords); sv.add_child(go)
	var cancel:=Button.new(); cancel.text="إلغاء"; cancel.pressed.connect(func(): search_panel.visible=false); sv.add_child(cancel)
	saved_panel=PanelContainer.new(); hud.add_child(saved_panel); saved_panel.visible=false; saved_panel.anchor_left=0.1; saved_panel.anchor_right=0.9; saved_panel.anchor_top=0.2; saved_panel.anchor_bottom=0.75

func _enforce_map_minimums(node: Node) -> void:
	for child in node.get_children():
		if child is Button:
			var button := child as Button
			button.custom_minimum_size = Vector2(maxf(button.custom_minimum_size.x, UITheme.TOUCH_MIN), maxf(button.custom_minimum_size.y, UITheme.BUTTON_HEIGHT))
		elif child is Label:
			var label := child as Label
			if label.get_theme_font_size("font_size") < UITheme.FONT_DETAIL:
				label.add_theme_font_size_override("font_size", UITheme.FONT_DETAIL)
		_enforce_map_minimums(child)

func _side_action(action:String) -> void:
	match action:
		"search": _show_search()
		"my_city": map.call("go_to_player_city"); _refresh_coords()
		"overview": map.call("go_to_overview"); _refresh_coords()
		"saved": _show_saved()

func _show_search() -> void:
	saved_panel.visible=false; search_panel.visible=true

func _go_to_coords() -> void:
	var x:=clampi(int(x_input.text) if x_input.text.is_valid_int() else 600,0,1199)
	var y:=clampi(int(y_input.text) if y_input.text.is_valid_int() else 600,0,1199)
	map.call("go_to",x,y); search_panel.visible=false; selected_info={"x":x,"y":y}; _refresh_coords()

func _save_selected() -> void:
	if selected_info.is_empty():
		var c:Vector2i=map.call("get_camera_center"); selected_info={"x":c.x,"y":c.y,"name":"موقع محفوظ"}
	var item:Dictionary=selected_info.duplicate(true)
	item["province_id"] = province_id
	if not saved_locations.has(item): saved_locations.append(item)
	GameState.set_world_map_saved_locations(province_id, saved_locations)
	detail_label.text="تم حفظ الموقع: X:%d  Y:%d" % [int(item.get("x",0)),int(item.get("y",0))]

func _show_saved() -> void:
	search_panel.visible=false
	for child in saved_panel.get_children(): child.queue_free()
	var vb:=VBoxContainer.new(); saved_panel.add_child(vb)
	var title:=Label.new(); title.text="المواقع المحفوظة"; title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; vb.add_child(title)
	if saved_locations.is_empty():
		var empty:=Label.new(); empty.text="لم تحفظ أي موقع بعد"; vb.add_child(empty)
	else:
		for item in saved_locations:
			var b:=Button.new(); b.text="%s  X:%d Y:%d" % [str(item.get("name","موقع")),int(item.get("x",0)),int(item.get("y",0))]; b.pressed.connect(func(): map.call("go_to",int(item.get("x",0)),int(item.get("y",0))); saved_panel.visible=false); vb.add_child(b)
	var close:=Button.new(); close.text="إغلاق"; close.pressed.connect(func(): saved_panel.visible=false); vb.add_child(close)
	saved_panel.visible=true

func _on_location_picked(kind:String,object_id:String,info:Dictionary) -> void:
	selected_kind=kind
	selected_id=object_id
	selected_info=info.duplicate(true)
	_refresh_coords()
	_clear_action_connections()
	action_button.visible = false
	action_button.disabled = false
	var x: int = int(info.get("x",0))
	var y: int = int(info.get("y",0))
	match kind:
		"city":
			if bool(info.get("is_player", false)):
				detail_label.text="مدينتي  •  المستوى %d\nالإحداثيات: X:%d Y:%d" % [int(info.get("level",1)),x,y]
			else:
				detail_label.text="%s  •  التحالف: %s  •  المستوى %d\nالمالك: %s  •  X:%d Y:%d%s" % [str(info.get("name", "مدينة")),str(info.get("alliance","")),int(info.get("level",1)),str(info.get("owner","لاعب")),x,y,"  •  مدينة تجريبية" if bool(info.get("fake",false)) else ""]
		"resource":
			var current_info: Dictionary = GameState.world_node_info(object_id, province_id)
			detail_label.text="%s — مستوى %d\nX:%d Y:%d  •  المتبقي: %d" % [str(current_info.get("name",info.get("name","مورد"))),int(current_info.get("tier",1)),x,y,int(current_info.get("amount",0))]
			action_button.text="إرسال قافلة للجمع"
			action_button.visible=true
			action_button.pressed.connect(_send_selected_caravan)
		"tribe":
			var tribe_id: String = str(info.get("id", object_id))
			var tribe: Dictionary = GameState.TRIBES.get(tribe_id, {})
			var cooldown: float = GameState.tribe_cooldown_left(tribe_id)
			detail_label.text="%s\nالعلاقة: %d%%  •  X:%d Y:%d\n%s" % [str(tribe.get("name", "قبيلة")),int(GameState.tribal_relations.get(tribe_id,0)),x,y,"الفزعة متاحة" if cooldown <= 0.0 else "الانتظار: " + GameState.fmt_time(cooldown)]
			action_button.text="فزعة للقبيلة"
			action_button.visible=true
			action_button.pressed.connect(_help_selected_tribe.bind(tribe_id))
		"throne":
			detail_label.text="العرش المركزي  •  X:598 Y:598  •  مساحة 4×4"


func _clear_action_connections() -> void:
	if not is_instance_valid(action_button): return
	for connection in action_button.pressed.get_connections():
		var callback: Callable = connection.get("callable", Callable())
		if callback.is_valid(): action_button.pressed.disconnect(callback)


func _send_selected_caravan() -> void:
	if selected_kind != "resource": return
	var ok: bool = GameState.gather_world_node(province_id, selected_id)
	if ok:
		detail_label.text += "\nانطلقت القافلة؛ سيُحدّث رصيد المورد عند عودتها."
		action_button.disabled = true
	_refresh_caravan_counter()
	if is_instance_valid(map): map.queue_redraw()


func _help_selected_tribe(tribe_id: String) -> void:
	GameState.help_tribe(tribe_id)
	_on_location_picked("tribe", tribe_id, selected_info)


func _process(delta: float) -> void:
	_map_audit_clock += delta
	if _map_audit_clock >= 0.5:
		_map_audit_clock = 0.0
		if is_instance_valid(hud):
			_enforce_map_minimums(hud)
	_caravan_ui_clock += delta
	if _caravan_ui_clock >= 1.0:
		_caravan_ui_clock = 0.0
		_refresh_caravan_counter()
		if GameState.active_world_caravan_count() > 0 and is_instance_valid(map): map.queue_redraw()


func _refresh_caravan_counter() -> void:
	if not is_instance_valid(caravan_label) or not is_instance_valid(map): return
	caravan_label.text="القوافل: %d/%d" % [GameState.active_world_caravan_count(), int(map.call("get_max_caravan_count"))]

func _refresh_coords() -> void:
	var c: Vector2i = map.call("get_camera_center")
	coords_label.text="#%s  X:%d  Y:%d" % [str(province_id),c.x,c.y]


func _exit_tree() -> void:
	# سكربت الخريطة يحفظ الكاميرا عند خروجه؛ هنا نحفظ قائمة المواقع فقط.
	GameState.set_world_map_saved_locations(province_id, saved_locations)
