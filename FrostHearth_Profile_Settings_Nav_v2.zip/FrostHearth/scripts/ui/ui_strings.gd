extends RefCounted
## جميع تسميات غلاف الواجهة الجديد تمر من T(key) لتسهيل الترجمة لاحقاً.
const STRINGS := {
 "profile":"الملف الشخصي", "profile_level":"مستوى الموقد: %d", "profile_survivors":"الناجون: %d", "profile_fame":"السمعة: %d", "power":"قوة الفرسان", "heroes":"الأبطال", "backpack":"الحقيبة", "alliance":"التحالف", "store":"المتجر", "section_coming_soon":"هذا القسم قيد التجهيز وسيُفعّل لاحقاً.", "city":"المدينة", "tribe":"القبيلة", "research":"البحوث", "map":"الخريطة", "city_map":"المدينة / الخريطة", "caravans":"القوافل", "more":"المزيد",
 "weather_calm":"الطقس هادئ", "storm_warning":"عاصفة قادمة", "storm_active":"عاصفة ثلجية",
 "temperature":"الحرارة", "survivors":"الناجون", "current_goal":"الهدف الحالي", "go":"اذهب",
 "claim_reward":"استلم المكافأة", "missions":"المهام", "urgent_coal":"الفحم يوشك على النفاد",
 "urgent_storm":"استعد للعاصفة", "urgent_idle":"ناجون بلا عمل", "urgent_council":"قضية مجلس تنتظر",
 "close":"رجوع", "audio_on":"الصوت: يعمل", "audio_off":"الصوت: متوقف", "confirm_reset":"تأكيد إعادة البدء؟",
 "more_missions":"المهام والإنجازات", "caravans":"القوافل النشطة", "settings":"الإعدادات", "restart":"إعادة البدء",
 "locked":"مقفل", "locked_reason":"يتطلب مستوى موقد أعلى", "automatic_assign":"وزّع تلقائياً", "details":"تفاصيل",
 "build":"ابنِ", "upgrade":"ارْقِ", "empty_plot":"أرض فارغة", "tribe_survivors":"الناجون", "tribe_council":"المجلس",
 "tribe_aid":"الفزعة", "tribe_fame":"السمعة", "advanced":"ضبط متقدم", "available":"متاح", "complete":"مكتمل",
 "not_enough":"موارد غير كافية", "goal_empty":"لا توجد مهام جديدة الآن"
}
static func T(key: String) -> String:
 return str(STRINGS.get(key, key))
