# Hearth64 — ربط نماذج GLB بأنواع المباني

## ما تغيّر
- `scripts/main.gd`: جدول `GLB_MODELS` يربط نوع المبنى بنموذجه مع `fit` (أكبر بُعد أفقي) و`max_h` (أقصى ارتفاع).
- النماذج الثلاثة السابقة (hearth / woodcutter / lodge) تعمل بلا تحجيم كما كانت.
- أنواع جديدة مربوطة: `ironmine`، `infirmary`، `stable`، `infantry_barracks`، `guard_post`، `caravan_yard`، `majlis`.
- `_add_glb_model` صارت تحسب حدود النموذج الحقيقية (مع تحويلات العقد) فتضع قاعدته على `y = G` ومركزه الأفقي عند الصفر وتحجّمه ليناسب القطعة. الحدود تُخزَّن مؤقتاً لكل مسار.
- أسطح GLB بلا خامة تأخذ خامة ألوان الرؤوس تلقائياً (محجر الحجر، الغذاء، قطع السور).
- أي فشل تحميل يرجع للمجسم الإجرائي القديم.

## غير مربوط عمداً (لا يوجد نوع مبنى مطابق في DEFS)
`coalmine`، `research_hall`، `archer_barracks` تبقى إجرائية.
نماذج بانتظار أنظمة لعب مستقبلية: citadel، city_gate، storehouse، wall (segment/corner/endcap/gate)، watchtower، artillery_tower، grand_hearth، forest_wood، food_production، stone_quarry.

## الاختبار
- `python3 tools/validate_glb.py` — فحص سلامة الملفات (جرى هنا ونجح).
- `godot --headless --path . --script res://tests/hearth64_glb_link_test.gd` — يتحقق من التحميل والقاعدة والتحجيم والخامات. **لم يُشغَّل** (لا يوجد Godot في بيئة البناء).

## يحتاج فحصاً بصرياً داخل Godot
- اتجاه الواجهة (المجسمات الإجرائية واجهتها +Z).
- شكل الإضاءة، فالنماذج بلا NORMAL وسيولّدها المستورد.
- الأداء على الجوال: النماذج تحوي 80–160 mesh، ويُنصح بدمجها لاحقاً حسب الخامة.
