#!/usr/bin/env python3
"""فحص سريع لملفات GLB: الترويسة، الطول، الـ buffers، الخامات، الألوان، الـ normals.
التشغيل من جذر المشروع:  python3 tools/validate_glb.py
"""
import glob, json, struct, sys

bad = 0
for f in sorted(glob.glob('assets/**/*.glb', recursive=True)):
    d = open(f, 'rb').read()
    magic, ver, length = struct.unpack('<4sII', d[:12])
    problems = []
    if magic != b'glTF' or ver != 2: problems.append('ترويسة غير صحيحة')
    if length != len(d): problems.append('الطول لا يطابق الملف')
    cl = struct.unpack('<I', d[12:16])[0]
    j = json.loads(d[20:20 + cl])
    prims = [p for m in j.get('meshes', []) for p in m['primitives']]
    if not prims: problems.append('لا توجد meshes')
    no_mat = sum(1 for p in prims if 'material' not in p)
    vcol = sum(1 for p in prims if 'COLOR_0' in p['attributes'])
    if no_mat and vcol < no_mat: problems.append('أسطح بلا خامة ولا ألوان رؤوس')
    if j.get('extensionsRequired'): problems.append('extensions مطلوبة: %s' % j['extensionsRequired'])
    note = []
    if no_mat: note.append('%d سطح يعتمد على vertex color' % no_mat)
    if any('NORMAL' not in p['attributes'] for p in prims): note.append('بلا NORMAL')
    print(('BAD ' if problems else 'OK  ') + f, '|', '; '.join(problems + note))
    bad += bool(problems)
sys.exit(1 if bad else 0)
