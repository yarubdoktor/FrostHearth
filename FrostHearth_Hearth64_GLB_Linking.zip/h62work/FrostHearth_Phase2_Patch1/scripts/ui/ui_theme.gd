extends RefCounted
## مصدر موحّد لألوان ومقاسات واجهة Section 18.
const NAVY := Color("0a1728")
const NAVY_LIGHT := Color("142943")
const ICE := Color("f0f6ff")
const ICE_MUTED := Color("9eb4cc")
const AMBER := Color("d98232")
const AMBER_LIGHT := Color("ffc46b")
const DANGER := Color("df625e")
const SUCCESS := Color("7cc99a")
const BORDER := Color("304b68")
const FONT_BODY := 34
const FONT_TITLE := 48
const FONT_DETAIL := 26
const BUTTON_HEIGHT := 104
const TOUCH_MIN := 88
const GAP := 16
const SAFE_FALLBACK_TOP := 64
const SAFE_FALLBACK_BOTTOM := 48
const SIDE_MARGIN := 32
const PANEL_RADIUS := 24
const ANIM_SECONDS := 0.20

# مقاسات البطاقات والرقائق والشريط السفلي في نظام الواجهة الجديد.
const ICON_SIZE := 48
const RESOURCE_ICON_SIZE := 40
const NAV_ICON_SIZE := 44
const SHEET_HEIGHT_RATIO := 0.76
const TOP_BAR_HEIGHT := 176
const GOAL_BAR_HEIGHT := 136
const NAV_BAR_HEIGHT := 144
const CARD_RADIUS := 20
const SAFE_FALLBACK_SIDE := 24
