extends Button
const UITheme = preload("res://scripts/ui/ui_theme.gd")
func _ready() -> void:
	custom_minimum_size.y = maxf(custom_minimum_size.y, UITheme.BUTTON_HEIGHT)
	add_theme_font_size_override("font_size", UITheme.FONT_BODY)
