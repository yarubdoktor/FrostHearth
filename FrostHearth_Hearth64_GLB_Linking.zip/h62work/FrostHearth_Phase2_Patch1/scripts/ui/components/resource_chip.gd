extends PanelContainer
const UITheme = preload("res://scripts/ui/ui_theme.gd")
var resource_key := "wood"
var value_label: Label
var capacity_bar: ProgressBar
func _ready() -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", UITheme.GAP)
	add_child(row)
	var icon := TextureRect.new()
	icon.texture = load("res://assets/ui/icons/%s.svg" % resource_key)
	icon.custom_minimum_size = Vector2(32, 32)
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	row.add_child(icon)
	value_label = Label.new()
	value_label.add_theme_font_size_override("font_size", UITheme.FONT_BODY)
	row.add_child(value_label)
	capacity_bar = ProgressBar.new()
	capacity_bar.max_value = 100
	capacity_bar.show_percentage = false
	capacity_bar.custom_minimum_size.y = 6
	add_child(capacity_bar)
func set_amount(amount: float, capacity: float) -> void:
	value_label.text = str(int(amount))
	capacity_bar.value = 100.0 * amount / maxf(1.0, capacity)
