extends PanelContainer
const UITheme = preload("res://scripts/ui/ui_theme.gd")
const UIStrings = preload("res://scripts/ui/ui_strings.gd")
var content: VBoxContainer
func _ready() -> void:
	content = VBoxContainer.new()
	content.add_theme_constant_override("separation", UITheme.GAP)
	add_child(content)
func add_back_button(callback: Callable) -> Button:
	var button := Button.new()
	button.text = UIStrings.T("close")
	button.custom_minimum_size = Vector2(0, UITheme.BUTTON_HEIGHT)
	button.pressed.connect(callback)
	content.add_child(button)
	return button
