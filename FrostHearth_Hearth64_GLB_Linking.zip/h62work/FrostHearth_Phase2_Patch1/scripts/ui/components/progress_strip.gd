extends ProgressBar
func _ready() -> void:
	show_percentage = false
	custom_minimum_size.y = 8
