extends Control
## خريطة المقاطعة: إحداثيات 0..1199، عرض عناصر المنطقة الظاهرة فقط.
signal location_picked(kind: String, object_id: String, info: Dictionary)
const MAP_SIZE: int = 1200
const CHUNK_SIZE: int = 40
const CHUNK_COUNT: int = 30
const DEFAULT_VISIBLE: float = 9.0
const MIN_VISIBLE: float = 6.0
const DETAIL_VISIBLE: float = 16.0
const CITY_COUNT: int = 1200
const RESOURCE_COUNT: int = 12000
const THRONE_ORIGIN: Vector2i = Vector2i(598, 598)
# مواضع القبائل حول مدينة اللاعب، بوحدات الخانات.
const TRIBE_VALLEY_OFFSET: Vector2i = Vector2i(-18, 8)
const TRIBE_PASS_OFFSET: Vector2i = Vector2i(17, 5)
const TRIBE_OASIS_OFFSET: Vector2i = Vector2i(3, -19)
# إعدادات القصور الذاتي للخريطة: الاحتكاك الأعلى يوقف الانزلاق أسرع.
const INERTIA_FRICTION: float = 4.2 # احتكاك زمني؛ انزلاق محسوس قرابة 0.6–1 ثانية
const INERTIA_MIN_VELOCITY: float = 0.8 # أقل سرعة بوحدة خانة/ثانية لبدء الانزلاق
const INERTIA_MAX_VELOCITY: float = 85.0 # الحد الأقصى للسرعة بوحدة خانة/ثانية
const INERTIA_VELOCITY_WINDOW: float = 0.10 # نافذة عينات السرعة بالثواني (~100ms)
const INERTIA_STOP_VELOCITY: float = 0.12 # تحت هذه السرعة يتوقف التحديث تماماً
const INERTIA_STALE_INPUT: float = 0.08 # إذا توقف الإصبع أكثر من 80ms فلا نبدأ انزلاقاً
var province_id: String = "north_ridge"
var province_seed: int = 74129
var camera_center: Vector2 = Vector2(600, 600)
var visible_cells: float = DEFAULT_VISIBLE
# تكبير/تصغير ناعم مع تثبيت النقطة الواقعة تحت الإصبع أو مؤشر الفأرة.
var zoom_target_cells: float = DEFAULT_VISIBLE
var zoom_anchor_screen: Vector2 = Vector2.ZERO
var zoom_anchor_world: Vector2 = Vector2.ZERO
var zoom_animating: bool = false
var selected_city: Dictionary = {}
var selected_resource: Dictionary = {}
var player_city: Dictionary = {}
var dragging := false
var drag_start := Vector2.ZERO
var drag_camera_start := Vector2.ZERO
var touch_points: Dictionary = {}
var pinch_start_distance := 0.0
var pinch_start_visible := DEFAULT_VISIBLE
var inertia_velocity: Vector2 = Vector2.ZERO # سرعة الخريطة بوحدة خانة/ثانية
var drag_samples: Array[Dictionary] = [] # عينات {pos, time} خلال آخر 100ms
var last_drag_sample_time: float = 0.0
var touch_start_time: float = 0.0
var last_screen_input_msec: int = -10000 # لمنع احتساب أحداث الفأرة المقلدة مع اللمس
var city_data: Array[Dictionary] = []
var city_chunks: Dictionary = {}
var resource_chunks: Dictionary = {}
var saved_locations: Array[Dictionary] = []
var province_palette: Array[Color] = [Color("#d85b4a"),Color("#4c88d9"),Color("#d9b44c"),Color("#7a63c9"),Color("#43a77a"),Color("#d47bc1"),Color("#cf844b"),Color("#60b9bd")]

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	set_process(false)
	# Keep the map layer hidden while its first province data batches are prepared.
	# Reveal it smoothly once the data is ready, avoiding a sudden pop-in.
	modulate.a = 0.0
	await _load_or_build_province_data()
	var saved_view: Dictionary = GameState.get_world_map_view(province_id)
	if not saved_view.is_empty():
		camera_center = Vector2(float(saved_view.get("x", 600)), float(saved_view.get("y", 600)))
		visible_cells = clampf(float(saved_view.get("zoom", DEFAULT_VISIBLE)), MIN_VISIBLE, 1200.0)
	else:
		camera_center = Vector2(float(player_city.get("x", 600)), float(player_city.get("y", 600)))
	_clamp_camera()
	zoom_target_cells = visible_cells
	zoom_animating = false
	queue_redraw()
	var reveal_tween := create_tween()
	reveal_tween.set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	reveal_tween.tween_property(self, "modulate:a", 1.0, 0.38)

func _load_or_build_province_data() -> void:
	if GameState.world_map_cache.has(province_id):
		var cached: Dictionary = GameState.world_map_cache[province_id]
		city_data.assign(cached.get("cities", []))
		city_chunks = cached.get("city_chunks", {})
		resource_chunks = cached.get("resource_chunks", {})
		player_city = cached.get("player_city", {})
		player_city["level"] = GameState.hearth_level()
		return
	await _build_cities()
	await _build_resource_index()
	GameState.world_map_cache[province_id] = {"cities":city_data,"city_chunks":city_chunks,"resource_chunks":resource_chunks,"player_city":player_city}

func set_province(id: String, seed_value: int = 74129) -> void:
	_cancel_inertia()
	_save_view()
	province_id = id
	province_seed = seed_value
	await _load_or_build_province_data()
	var saved_view: Dictionary = GameState.get_world_map_view(province_id)
	if not saved_view.is_empty():
		camera_center = Vector2(float(saved_view.get("x", player_city.get("x", 600))), float(saved_view.get("y", player_city.get("y", 600))))
		visible_cells = clampf(float(saved_view.get("zoom", DEFAULT_VISIBLE)), MIN_VISIBLE, 1200.0)
	else:
		camera_center = Vector2(float(player_city.get("x", 600)), float(player_city.get("y", 600)))
		visible_cells = DEFAULT_VISIBLE
	_clamp_camera()
	zoom_target_cells = visible_cells
	zoom_animating = false
	queue_redraw()

func _update_view_memory() -> void:
	if is_instance_valid(GameState):
		var c: Vector2i = get_camera_center()
		GameState.update_world_map_view(province_id, c.x, c.y, visible_cells)

func _save_view() -> void:
	if is_instance_valid(GameState):
		var c: Vector2i = get_camera_center()
		GameState.save_world_map_view(province_id, c.x, c.y, visible_cells)

func get_player_city_position() -> Vector2i:
	return Vector2i(int(player_city.get("x", 600)), int(player_city.get("y", 600)))

func go_to_player_city() -> void:
	_cancel_inertia()
	zoom_animating = false
	set_process(false)
	zoom_target_cells = DEFAULT_VISIBLE
	var c: Vector2i = get_player_city_position()
	camera_center = Vector2(float(c.x), float(c.y))
	visible_cells = DEFAULT_VISIBLE
	_clamp_camera()
	queue_redraw()
	_save_view()

func get_caravan_count() -> int:
	return GameState.active_world_caravan_count()

func get_max_caravan_count() -> int:
	var yard: int = GameState.building_level("caravan_yard")
	if yard <= 0: return 0
	return mini(GameState.WORLD_CARAVAN_MAX_CONCURRENT, 1 + yard)

func _tribe_positions() -> Dictionary:
	var x: int = int(player_city.get("x", 600))
	var y: int = int(player_city.get("y", 600))
	return {
		"valley": Vector2i(clampi(x + TRIBE_VALLEY_OFFSET.x, 2, MAP_SIZE - 3), clampi(y + TRIBE_VALLEY_OFFSET.y, 2, MAP_SIZE - 3)),
		"pass": Vector2i(clampi(x + TRIBE_PASS_OFFSET.x, 2, MAP_SIZE - 3), clampi(y + TRIBE_PASS_OFFSET.y, 2, MAP_SIZE - 3)),
		"oasis": Vector2i(clampi(x + TRIBE_OASIS_OFFSET.x, 2, MAP_SIZE - 3), clampi(y + TRIBE_OASIS_OFFSET.y, 2, MAP_SIZE - 3)),
	}

func _chunk_key(cx: int, cy: int) -> String:
	return "%d:%d" % [cx, cy]

func _inside_outer_region(x: int, y: int) -> bool:
	var dx := float(x - 600) / 600.0
	var dy := float(y - 600) / 600.0
	var noise := sin(float(x) * 0.037 + float(province_seed % 71)) * 0.035 + cos(float(y) * 0.029) * 0.03
	return sqrt(dx * dx + dy * dy) > 0.52 + noise

func _build_cities() -> void:
	city_data.clear()
	city_chunks.clear()
	var rng := RandomNumberGenerator.new()
	rng.seed = int(hash(province_id)) + province_seed
	var alliances := ["شمس", "ذئاب", "صقور", "لهيب", "درع", "فجر", "رعد", "نخبة"]
	# 800 مدينة تجريبية متجمعة في نطاق البداية؛ 400 مدينة إضافية للحرب.
	for i in range(CITY_COUNT):
		if i > 0 and i % 100 == 0:
			await get_tree().process_frame
		var x := 0
		var y := 0
		if i < 800:
			var cluster := i % 8
			var cx := 600 + int(cos(float(cluster) * TAU / 8.0) * 365.0)
			var cy := 600 + int(sin(float(cluster) * TAU / 8.0) * 365.0)
			x = clampi(cx + rng.randi_range(-42, 42), 4, MAP_SIZE - 5)
			y = clampi(cy + rng.randi_range(-42, 42), 4, MAP_SIZE - 5)
			if not _inside_outer_region(x, y):
				x = clampi(600 + int(cos(float(cluster) * TAU / 8.0) * 410.0) + rng.randi_range(-20,20), 4, MAP_SIZE-5)
				y = clampi(600 + int(sin(float(cluster) * TAU / 8.0) * 410.0) + rng.randi_range(-20,20), 4, MAP_SIZE-5)
		else:
			x = rng.randi_range(8, MAP_SIZE - 5)
			y = rng.randi_range(8, MAP_SIZE - 5)
			if _inside_outer_region(x, y) and i % 3 != 0:
				x = clampi(600 + int(cos(float(i) * 2.399963) * rng.randf_range(90.0, 420.0)), 4, MAP_SIZE-5)
				y = clampi(600 + int(sin(float(i) * 2.399963) * rng.randf_range(90.0, 420.0)), 4, MAP_SIZE-5)
		# reserve throne footprint
		if x >= 596 and x <= 601 and y >= 596 and y <= 601:
			x = 610 + i % 35
		var alliance_idx := int(i % alliances.size()) if i < 800 else int((float(i) / 5.0)) % alliances.size()
		var city := {"id":"city_%04d" % i, "x":x, "y":y, "owner":"قائد %03d" % (i + 1), "alliance":str(alliances[alliance_idx]), "alliance_color":province_palette[alliance_idx], "level":1 + (i * 7 % 30), "protected":i % 5 != 0, "fake":i >= 800}
		city_data.append(city)
		var key := _chunk_key(floori(float(x) / float(CHUNK_SIZE)), floori(float(y) / float(CHUNK_SIZE)))
		if not city_chunks.has(key): city_chunks[key] = []
		city_chunks[key].append(city)
	var occupied: Array = city_data
	var player_pos: Vector2i = GameState.get_or_create_player_city_position(province_id, province_seed, occupied)
	player_city = {"id":"player_city", "x":player_pos.x, "y":player_pos.y, "owner":"أنت", "name":"مدينتي", "alliance":"", "alliance_color":Color("#e6bd54"), "level":GameState.hearth_level(), "protected":true, "fake":false, "is_player":true}
	city_data.append(player_city)
	var player_key: String = _chunk_key(floori(float(player_pos.x) / float(CHUNK_SIZE)), floori(float(player_pos.y) / float(CHUNK_SIZE)))
	if not city_chunks.has(player_key): city_chunks[player_key] = []
	city_chunks[player_key].append(player_city)

func _build_resource_index() -> void:
	resource_chunks.clear()
	var rng := RandomNumberGenerator.new()
	rng.seed = int(hash(province_id)) ^ province_seed ^ 0x45127
	var occupied_coords: Dictionary = {}
	var generated: int = 0
	var attempts: int = 0
	while generated < RESOURCE_COUNT and attempts < RESOURCE_COUNT * 3:
		attempts += 1
		if attempts % 250 == 0:
			await get_tree().process_frame
		var x: int = rng.randi_range(0, MAP_SIZE - 1)
		var y: int = rng.randi_range(0, MAP_SIZE - 1)
		var coord_key: String = "%d:%d" % [x, y]
		if occupied_coords.has(coord_key) or (x >= 596 and x <= 601 and y >= 596 and y <= 601):
			continue
		occupied_coords[coord_key] = true
		var node_id: String = "node_%d_%d" % [x, y]
		var info: Dictionary = GameState.world_node_info(node_id, province_id)
		if info.is_empty(): continue
		var premium: bool = generated % 17 == 0
		var item: Dictionary = info.duplicate(true)
		item["size"] = 2 if premium else 1
		var key: String = _chunk_key(floori(float(x) / float(CHUNK_SIZE)), floori(float(y) / float(CHUNK_SIZE)))
		if not resource_chunks.has(key): resource_chunks[key] = []
		resource_chunks[key].append(item)
		generated += 1

func _resource_name(kind: String) -> String:
	var names := {"wood":"غابة خشب", "iron":"منجم حديد", "coal":"منجم فحم", "food":"مؤن", "stone":"محجر حجارة", "oil":"حقل نفط"}
	return str(names.get(kind, "مورد"))

func _cell_px() -> float:
	return size.x / maxf(visible_cells, 1.0)

func _world_to_screen(x: float, y: float) -> Vector2:
	var cell := _cell_px()
	var delta := Vector2(x - camera_center.x, (y - camera_center.y) * 0.86)
	return size * 0.5 + Vector2(delta.x, delta.y) * cell

func _screen_to_world(p: Vector2) -> Vector2:
	var cell := _cell_px()
	var d := (p - size * 0.5) / maxf(cell, 0.001)
	return Vector2(camera_center.x + d.x, camera_center.y + d.y / 0.86)

func _visible_world_rect() -> Rect2:
	var a := _screen_to_world(Vector2.ZERO)
	var b := _screen_to_world(size)
	var margin := 3.0
	return Rect2(Vector2(minf(a.x,b.x)-margin,minf(a.y,b.y)-margin), Vector2(absf(b.x-a.x)+margin*2,absf(b.y-a.y)+margin*2))

func _draw() -> void:
	# خلفية خارج حدود المقاطعة: ضباب شتوي عميق بدل الفراغ الأخضر الداكن.
	draw_rect(Rect2(Vector2.ZERO,size),Color("#172c31"),true)
	var back_band := clampf(minf(size.x, size.y) * 0.08, 28.0, 86.0)
	for band_i in range(5):
		var a := 0.025 + float(band_i) * 0.012
		var margin := float(band_i) * back_band * 0.38
		draw_rect(Rect2(margin, margin, maxf(0.0,size.x-margin*2.0), maxf(0.0,size.y-margin*2.0)), Color(0.48,0.62,0.58,a), false, maxf(1.0,back_band*0.035), true)
	# لطخات ضبابية هادئة تجعل المساحة خارج اليابسة جزءاً من العالم لا مستطيلاً فارغاً.
	for mist_i in range(12):
		var mx := fposmod(float(mist_i * 173 + province_seed % 97), maxf(size.x,1.0))
		var my := fposmod(float(mist_i * 257 + province_seed % 131), maxf(size.y,1.0))
		var mr := clampf(minf(size.x,size.y) * (0.025 + float(mist_i % 3) * 0.012), 10.0, 48.0)
		draw_circle(Vector2(mx,my),mr,Color(0.42,0.57,0.56,0.035))
	var wr := _visible_world_rect()
	var min_chunk_x := clampi(int(floor(wr.position.x / CHUNK_SIZE)),0,CHUNK_COUNT-1)
	var max_chunk_x := clampi(int(floor((wr.position.x + wr.size.x) / CHUNK_SIZE)),0,CHUNK_COUNT-1)
	var min_chunk_y := clampi(int(floor(wr.position.y / CHUNK_SIZE)),0,CHUNK_COUNT-1)
	var max_chunk_y := clampi(int(floor((wr.position.y + wr.size.y) / CHUNK_SIZE)),0,CHUNK_COUNT-1)
	var cell := _cell_px()
	# Terrain tiles are deterministic from province seed and chunk coordinate.
	for cy in range(min_chunk_y, max_chunk_y + 1):
		for cx in range(min_chunk_x, max_chunk_x + 1):
			var chunk_seed := cx * 73856093 ^ cy * 19349663 ^ province_seed
			var rng := RandomNumberGenerator.new(); rng.seed = chunk_seed
			var top_left := _world_to_screen(float(cx*CHUNK_SIZE),float(cy*CHUNK_SIZE))
			var bottom_right := _world_to_screen(float((cx+1)*CHUNK_SIZE),float((cy+1)*CHUNK_SIZE))
			# Procedural terrain palette: every chunk has a stable local character instead of one flat green fill.
			var biome_roll: int = int(abs(cx * 17 + cy * 31 + province_seed) % 11)
			var base_palette: Array[Color] = [Color("#627f49"), Color("#6b8b50"), Color("#728d55"), Color("#597649"), Color("#7a925b")]
			var base_col: Color = base_palette[biome_roll % base_palette.size()]
			draw_rect(Rect2(top_left, Vector2(bottom_right.x-top_left.x,bottom_right.y-top_left.y)), base_col, true)
			# Soft terrain shelves and low ridges add depth without expensive 3D geometry.
			if cell > 1.8:
				var ridge_center := _world_to_screen(float(cx*CHUNK_SIZE) + rng.randf_range(7.0,33.0), float(cy*CHUNK_SIZE) + rng.randf_range(7.0,33.0))
				var ridge_w := cell * rng.randf_range(5.0,12.0)
				_draw_terrain_patch(ridge_center + Vector2(0.0, cell*0.10), ridge_w, Color(0.20,0.28,0.16,0.13))
				_draw_terrain_patch(ridge_center, ridge_w*0.78, Color(0.78,0.82,0.61,0.10))
				# Short contour strokes suggest gentle elevation and break up the checkerboard look.
				for contour_i in range(3):
					var contour_y := float(cy*CHUNK_SIZE) + 8.0 + float(contour_i)*11.0 + rng.randf_range(-2.0,2.0)
					var contour_x := float(cx*CHUNK_SIZE) + rng.randf_range(4.0,19.0)
					var ca := _world_to_screen(contour_x, contour_y)
					var cb := _world_to_screen(minf(float(cx*CHUNK_SIZE+CHUNK_SIZE-3), contour_x+rng.randf_range(7.0,17.0)), contour_y+rng.randf_range(-2.0,2.0))
					draw_line(ca, cb, Color(0.86,0.91,0.70,0.10), maxf(0.7,cell*0.025), true)
			for j in range(12):
				var tx := float(cx*CHUNK_SIZE) + rng.randf_range(2.0,38.0)
				var ty := float(cy*CHUNK_SIZE) + rng.randf_range(2.0,38.0)
				var tp := _world_to_screen(tx,ty)
				var palette: Array[Color] = [Color("#78985a"), Color("#83a05e"), Color("#527244"), Color("#9aa56b"), Color("#536f43")]
				var col: Color = palette[rng.randi_range(0, palette.size()-1)]
				if cell > 2.0: _draw_terrain_patch(tp, cell * rng.randf_range(0.22,0.82), col)
			if rng.randf() < 0.18 and cell > 5.0: _draw_forest(_world_to_screen(float(cx*40+rng.randi_range(3,36)),float(cy*40+rng.randi_range(3,36))),cell)
	# Edge mountains are impassable boundary walls.
	_draw_boundary_mountains(cell)
	if visible_cells > 150.0:
		_draw_overview(wr)
	else:
		_draw_visible_resources(min_chunk_x,max_chunk_x,min_chunk_y,max_chunk_y,cell)
		_draw_visible_cities(min_chunk_x,max_chunk_x,min_chunk_y,max_chunk_y,cell)
	_draw_throne(_world_to_screen(600,600),cell)
	_draw_tribes(cell)
	_draw_active_caravans(cell)
	if visible_cells <= 16.0: _draw_coordinate_grid(cell)
	_draw_map_edge_finish()

func _draw_map_edge_finish() -> void:
	# تدرّج حواف خفيف يدمج أطراف العالم مع الواجهة من دون إخفاء المقاطعات.
	var w: float = size.x
	var h: float = size.y
	var band: float = clampf(minf(w, h) * 0.055, 22.0, 54.0)
	var edge_outer := Color(0.025, 0.035, 0.030, 0.18)
	var edge_mid := Color(0.025, 0.035, 0.030, 0.10)
	var edge_inner := Color(0.025, 0.035, 0.030, 0.045)
	# شرائط متدرجة بدل طبقة تعتيم واحدة ثقيلة.
	draw_rect(Rect2(0, 0, w, band * 0.34), edge_outer, true)
	draw_rect(Rect2(0, band * 0.34, w, band * 0.33), edge_mid, true)
	draw_rect(Rect2(0, band * 0.67, w, band * 0.33), edge_inner, true)
	draw_rect(Rect2(0, h - band, w, band * 0.33), edge_inner, true)
	draw_rect(Rect2(0, h - band * 0.67, w, band * 0.33), edge_mid, true)
	draw_rect(Rect2(0, h - band * 0.34, w, band * 0.34), edge_outer, true)
	draw_rect(Rect2(0, 0, band * 0.34, h), edge_outer, true)
	draw_rect(Rect2(band * 0.34, 0, band * 0.33, h), edge_mid, true)
	draw_rect(Rect2(band * 0.67, 0, band * 0.33, h), edge_inner, true)
	draw_rect(Rect2(w - band, 0, band * 0.33, h), edge_inner, true)
	draw_rect(Rect2(w - band * 0.67, 0, band * 0.33, h), edge_mid, true)
	draw_rect(Rect2(w - band * 0.34, 0, band * 0.34, h), edge_outer, true)
	# إطار رفيع بلون نحاسي خافت لإعطاء الخريطة حدوداً مصقولة.
	var inset: float = clampf(minf(w, h) * 0.012, 5.0, 12.0)
	var frame := Color(0.82, 0.69, 0.39, 0.24)
	draw_rect(Rect2(inset, inset, maxf(0.0, w - inset * 2.0), maxf(0.0, h - inset * 2.0)), frame, false, 1.0, true)
	var corner: float = clampf(minf(w, h) * 0.035, 18.0, 34.0)
	var bright := Color(0.93, 0.78, 0.46, 0.52)
	# زخرفة قصيرة في الزوايا فقط، حتى يبقى المشهد نظيفاً وغير مزدحم.
	for x_sign in [-1.0, 1.0]:
		for y_sign in [-1.0, 1.0]:
			var origin := Vector2(inset if x_sign < 0.0 else w - inset, inset if y_sign < 0.0 else h - inset)
			draw_line(origin, origin + Vector2(corner * x_sign, 0), bright, 2.0, true)
			draw_line(origin, origin + Vector2(0, corner * y_sign), bright, 2.0, true)

func _draw_terrain_patch(p: Vector2, r: float, c: Color) -> void:
	var pts := PackedVector2Array()
	for i in range(7):
		var a := float(i)*TAU/7.0
		pts.append(p+Vector2(cos(a)*r,sin(a)*r*0.68))
	draw_colored_polygon(pts,c)

func _draw_forest(p: Vector2, cell: float) -> void:
	var r := clampf(cell*0.32,1.2,20.0)
	for off in [Vector2(-r*0.7,0),Vector2(r*0.3,-r*0.3),Vector2(r*0.65,r*0.25)]:
		var q: Vector2 = p + Vector2(off)
		draw_colored_polygon(PackedVector2Array([q+Vector2(0,-r),q+Vector2(r*0.65,r*0.3),q+Vector2(0,r*0.52),q+Vector2(-r*0.65,r*0.3)]),Color("#315d35"))

func _draw_boundary_mountains(cell: float) -> void:
	var r := _visible_world_rect()
	for i in range(0, MAP_SIZE, 12):
		for p in [Vector2(i,2),Vector2(i,MAP_SIZE-2),Vector2(2,i),Vector2(MAP_SIZE-2,i)]:
			if not r.has_point(p): continue
			var q := _world_to_screen(p.x,p.y)
			var h := clampf(cell*0.9,2.0,32.0)
			draw_colored_polygon(PackedVector2Array([q+Vector2(-h,h*0.35),q+Vector2(0,-h),q+Vector2(h,h*0.35)]),Color("#6e7660"))

func _draw_visible_resources(minx: int,maxx: int,miny: int,maxy: int,cell: float) -> void:
	for cy in range(miny,maxy+1):
		for cx in range(minx,maxx+1):
			var key := _chunk_key(cx,cy)
			if not resource_chunks.has(key): continue
			for n in resource_chunks[key]:
				var p := _world_to_screen(float(n.x)+0.5,float(n.y)+0.5)
				if not Rect2(Vector2.ZERO,size).has_point(p): continue
				var current_info: Dictionary = GameState.world_node_info(str(n.id), province_id)
				var remaining: int = int(current_info.get("amount",0))
				if remaining <= 0:
					if cell > 12.0: draw_circle(p,clampf(cell*0.10,1.0,3.0),Color(0.42,0.45,0.42,0.65))
					continue
				if visible_cells > 85.0:
					# في العرض الواسع نستخدم نقاطاً واضحة، وعند الاقتراب تتحول إلى مواقع مرسومة.
					var dot_r := clampf(cell * 0.18, 2.2, 5.0) * (1.25 if int(n.size) > 1 else 1.0)
					draw_circle(p + Vector2(0, dot_r * 0.25), dot_r * 1.65, Color(0.03,0.08,0.06,0.34))
					draw_circle(p, dot_r, Color("#d7e7a4"))
					draw_circle(p, dot_r * 0.48, Color("#f4e6b4"))
				else:
					_draw_resource(p,str(n.resource),cell,int(n.size),int(n.tier))
				if selected_resource.get("id","") == n.id:
					draw_arc(p,clampf(cell*0.6,8.0,36.0),0.0,TAU,32,Color("#ffe47a"),3.0,true)

func _draw_visible_cities(minx: int,maxx: int,miny: int,maxy: int,cell: float) -> void:
	for cy in range(miny,maxy+1):
		for cx in range(minx,maxx+1):
			var key := _chunk_key(cx,cy)
			if not city_chunks.has(key): continue
			for city in city_chunks[key]:
				var p := _world_to_screen(float(city.x)+1.0,float(city.y)+1.0)
				var dot_color: Color = Color("#f4ca55") if bool(city.get("is_player", false)) else city.alliance_color
				if visible_cells > 150.0:
					draw_rect(Rect2(p-Vector2(1.5,1.5),Vector2(3,3)),dot_color,true)
				elif visible_cells > 40.0:
					draw_circle(p,clampf(cell*0.23,2.0,6.0),dot_color)
					if bool(city.get("is_player", false)): draw_arc(p,clampf(cell*0.4,5.0,10.0),0.0,TAU,20,Color("#fff0a0"),2.0,true)
				else:
					_draw_city(p,cell,city)

func _draw_overview(_wr: Rect2) -> void:
	# نظرة عامة خفيفة: لون التحالفات ونسيج الأرض في المستوى الأبعد.
	for city in city_data:
		var p := _world_to_screen(float(city.x)+1.0,float(city.y)+1.0)
		if Rect2(Vector2.ZERO,size).has_point(p): draw_rect(Rect2(p-Vector2(1.0,1.0),Vector2(2.0,2.0)),city.alliance_color,true)

func _draw_tribes(cell: float) -> void:
	var positions: Dictionary = _tribe_positions()
	var names: Dictionary = {"valley":"الوادي", "pass":"حراس الممر", "oasis":"الواحة"}
	var colors: Dictionary = {"valley":Color("#74c98b"), "pass":Color("#8cb7ed"), "oasis":Color("#e5c56c")}
	for tribe_id in positions:
		var pos: Vector2i = positions[tribe_id]
		var screen_pos: Vector2 = _world_to_screen(float(pos.x), float(pos.y))
		var r: float = clampf(cell * 0.34, 4.0, 18.0)
		# حماية الرسم من إحداثيات غير صالحة أثناء تغيّر التكبير/الكاميرا.
		# أي مضلع غير صالح يُتجاوز بدلاً من تمريره إلى محرك الرسم وإصدار خطأ triangulation.
		if not is_finite(screen_pos.x) or not is_finite(screen_pos.y) or not is_finite(r) or r <= 0.0:
			continue
		var triangle := PackedVector2Array([
			screen_pos + Vector2(0.0, -r),
			screen_pos + Vector2(r, r * 0.65),
			screen_pos + Vector2(-r, r * 0.65)
		])
		var twice_area := absf((triangle[1] - triangle[0]).cross(triangle[2] - triangle[0]))
		if not is_finite(twice_area) or twice_area <= 0.001:
			continue
		var tribe_color: Color = colors[tribe_id] as Color
		draw_colored_polygon(triangle, tribe_color)
		if visible_cells <= 20.0:
			draw_string(ThemeDB.fallback_font,screen_pos+Vector2(-r*2.5,-r*1.2),str(names[tribe_id]),HORIZONTAL_ALIGNMENT_CENTER, r*5.0, clampi(int(r*0.9),10,16),Color.WHITE)


func _draw_active_caravans(cell: float) -> void:
	for caravan in GameState.world_caravans:
		if str(caravan.get("province_id", "north_ridge")) != province_id: continue
		var from := Vector2(float(caravan.get("player_x", player_city.get("x",600))), float(caravan.get("player_y", player_city.get("y",600))))
		var to := Vector2(float(caravan.get("target_x",600)), float(caravan.get("target_y",600)))
		var a: Vector2 = _world_to_screen(from.x, from.y)
		var b: Vector2 = _world_to_screen(to.x, to.y)
		draw_line(a,b,Color(1.0,0.82,0.32,0.75),clampf(cell*0.10,1.5,4.0),true)
		var start: float = float(caravan.get("start", GameState.now()))
		var finish: float = float(caravan.get("finish", GameState.now()))
		var midpoint: float = clampf((GameState.now()-start)/maxf(0.01,finish-start),0.0,1.0)
		var marker: Vector2 = a.lerp(b, midpoint if midpoint <= 0.5 else 1.0-midpoint)
		draw_circle(marker,clampf(cell*0.25,3.0,10.0),Color("#fff0a0"))
		if visible_cells <= 24.0:
			draw_string(ThemeDB.fallback_font,marker+Vector2(4,-6),GameState.fmt_time(finish-GameState.now()),HORIZONTAL_ALIGNMENT_LEFT,90,12,Color.WHITE)


func _draw_coordinate_grid(cell: float) -> void:
	if cell < 18.0: return
	var wr := _visible_world_rect()
	var step := 1 if visible_cells <= 9.0 else 2
	var x0 := maxi(0,int(floor(wr.position.x/step))*step)
	var y0 := maxi(0,int(floor(wr.position.y/step))*step)
	for x in range(x0,mini(MAP_SIZE,int(wr.end.x)+step),step):
		var a := _world_to_screen(float(x),wr.position.y)
		var b := _world_to_screen(float(x),wr.end.y)
		draw_line(a,b,Color(0.9,0.97,0.76,0.11),1.0)
	for y in range(y0,mini(MAP_SIZE,int(wr.end.y)+step),step):
		var a := _world_to_screen(wr.position.x,float(y))
		var b := _world_to_screen(wr.end.x,float(y))
		draw_line(a,b,Color(0.9,0.97,0.76,0.11),1.0)

func _draw_resource(p: Vector2,kind: String,cell: float,footprint: int,tier: int) -> void:
	# مواقع الموارد عناصر مصغّرة مقروءة: قاعدة أرضية، ظل، كتلة رئيسية وتفاصيل نوعية.
	# حد أدنى بالبكسل يحافظ على وضوحها على الهاتف عند التصغير المتوسط.
	var s := clampf(cell * 0.58, 9.0, 62.0) * (1.42 if footprint > 1 else 1.0)
	var resource_colors: Dictionary = {"wood":Color("#477d3f"),"iron":Color("#a9b7c2"),"coal":Color("#4b5558"),"food":Color("#d8b86b"),"stone":Color("#b4a38c"),"oil":Color("#3f5868")}
	var c: Color = resource_colors.get(kind, Color.WHITE) as Color
	_draw_ellipse(p+Vector2(0,s*0.36),Vector2(s*1.05,s*0.43),Color(0,0,0,0.30))
	_draw_ellipse(p+Vector2(0,s*0.22),Vector2(s*0.94,s*0.38),Color(0.67,0.72,0.55,0.34))
	match kind:
		"wood":
			# غابة من أشجار صنوبر متعددة الطبقات مع جذوع وظلال منفصلة.
			for tree_i in range(7):
				var ox := (float(tree_i % 3) - 1.0) * s * 0.40 + (s * 0.16 if tree_i >= 3 else 0.0)
				var oy := (float(tree_i) / 3.0 - 0.45) * s * 0.31
				var tree_radius := s * (0.28 if tree_i == 2 else (0.20 if tree_i % 2 == 0 else 0.235))
				var tp := p + Vector2(ox,oy)
				# Ground shadow, trunk, dark silhouette, mid foliage and a lit snow-facing edge.
				_draw_ellipse(tp+Vector2(tree_radius*0.10,tree_radius*0.55),Vector2(tree_radius*0.80,tree_radius*0.26),Color(0.03,0.08,0.05,0.28))
				draw_line(tp+Vector2(0,tree_radius*0.15),tp+Vector2(0,tree_radius*0.82),Color("#6b5136"),maxf(1.0,tree_radius*0.20),true)
				draw_colored_polygon(PackedVector2Array([tp+Vector2(0,-tree_radius),tp+Vector2(tree_radius*0.72,tree_radius*0.22),tp+Vector2(tree_radius*0.35,tree_radius*0.25),tp+Vector2(0,tree_radius*0.55),tp+Vector2(-tree_radius*0.35,tree_radius*0.25),tp+Vector2(-tree_radius*0.72,tree_radius*0.22)]),Color("#203f2d"))
				draw_colored_polygon(PackedVector2Array([tp+Vector2(0,-tree_radius*0.88),tp+Vector2(tree_radius*0.43,tree_radius*0.12),tp+Vector2(0,tree_radius*0.31),tp+Vector2(-tree_radius*0.43,tree_radius*0.12)]),Color("#4f8042" if tree_i % 2 == 0 else "#628e4a"))
				draw_line(tp+Vector2(-tree_radius*0.18,-tree_radius*0.25),tp+Vector2(0,-tree_radius*0.72),Color(0.77,0.86,0.63,0.32),maxf(0.7,tree_radius*0.07),true)
		"iron", "stone", "coal":
			# كتلة صخرية غير منتظمة مع طبقات فاتحة وشقوق/بلورات مميزة.
			var pts := PackedVector2Array([p+Vector2(-s*0.78,s*0.18),p+Vector2(-s*0.61,-s*0.30),p+Vector2(-s*0.22,-s*0.67),p+Vector2(s*0.20,-s*0.53),p+Vector2(s*0.72,-s*0.20),p+Vector2(s*0.81,s*0.22),p+Vector2(s*0.25,s*0.55),p+Vector2(-s*0.36,s*0.48)])
			draw_colored_polygon(pts,Color(c.r*0.56,c.g*0.56,c.b*0.56))
			# A second overlapping rock mass gives the deposit a clustered, raised silhouette.
			var rock2 := PackedVector2Array([p+Vector2(s*0.10,s*0.24),p+Vector2(s*0.28,-s*0.22),p+Vector2(s*0.57,-s*0.34),p+Vector2(s*0.78,s*0.02),p+Vector2(s*0.62,s*0.32),p+Vector2(s*0.30,s*0.39)])
			draw_colored_polygon(rock2,c.darkened(0.18))
			draw_colored_polygon(PackedVector2Array([p+Vector2(-s*0.55,-s*0.25),p+Vector2(-s*0.18,-s*0.58),p+Vector2(s*0.17,-s*0.43),p+Vector2(-s*0.03,-s*0.08)]),c.lightened(0.28))
			draw_line(p+Vector2(-s*0.18,-s*0.05),p+Vector2(s*0.05,s*0.31),c.darkened(0.42),maxf(1.0,s*0.07),true)
			draw_line(p+Vector2(-s*0.43,-s*0.20),p+Vector2(-s*0.18,-s*0.42),Color(0.91,0.94,0.91,0.45),maxf(0.8,s*0.035),true)
			if kind == "iron":
				for crystal_i in range(3):
					var cp := p + Vector2((float(crystal_i)-1.0)*s*0.25,-s*(0.25 + float(crystal_i%2)*0.12))
					draw_colored_polygon(PackedVector2Array([cp+Vector2(-s*0.07,s*0.15),cp+Vector2(0,-s*0.28),cp+Vector2(s*0.08,s*0.12)]),Color("#dce8ef"))
			if kind == "coal":
				for coal_i in range(3): draw_circle(p+Vector2((float(coal_i)-1.0)*s*0.24,s*0.16),s*0.09,Color("#20292c"))
		"food":
			# حقل محاصيل ذهبي بخطوط صفوف واضحة.
			draw_colored_polygon(PackedVector2Array([p+Vector2(-s*0.78,s*0.20),p+Vector2(-s*0.43,-s*0.35),p+Vector2(s*0.55,-s*0.30),p+Vector2(s*0.78,s*0.20),p+Vector2(s*0.20,s*0.49)]),Color("#a88c4d"))
			for row_i in range(4):
				var yy := -s*0.19 + float(row_i)*s*0.13
				draw_line(p+Vector2(-s*0.46,yy),p+Vector2(s*0.49,yy+s*0.02),Color("#f0d58a"),maxf(1.0,s*0.055),true)
		"oil":
			# منصة نفط صغيرة: خزان داكن وبرج معدني مميز.
			draw_colored_polygon(PackedVector2Array([p+Vector2(-s*0.55,s*0.30),p+Vector2(-s*0.45,-s*0.02),p+Vector2(s*0.40,-s*0.02),p+Vector2(s*0.55,s*0.30)]),Color("#253943"))
			draw_line(p+Vector2(-s*0.20,-s*0.05),p+Vector2(0,-s*0.75),Color("#a8bbc0"),maxf(1.3,s*0.07),true)
			draw_line(p+Vector2(s*0.20,-s*0.05),p+Vector2(0,-s*0.75),Color("#a8bbc0"),maxf(1.3,s*0.07),true)
			draw_line(p+Vector2(-s*0.25,-s*0.38),p+Vector2(s*0.25,-s*0.38),Color("#d0dcde"),maxf(1.3,s*0.06),true)
	# شارة المستوى صغيرة ومحددة بصرياً، من دون نص مزدحم عند التصغير.
	if cell > 18.0:
		var badge_p := p + Vector2(s*0.62,-s*0.55)
		draw_circle(badge_p,clampf(s*0.20,4.0,8.0),Color("#202e32"))
		draw_arc(badge_p,clampf(s*0.20,4.0,8.0),0.0,TAU,16,Color("#e8cf88"),1.2,true)
		draw_string(ThemeDB.fallback_font,badge_p+Vector2(-3.5,4.0),str(tier),HORIZONTAL_ALIGNMENT_CENTER,9,clampi(int(s*0.20),9,12),Color("#fff4cf"))

func _draw_city(p: Vector2,cell: float,city: Dictionary) -> void:
	var s := clampf(cell*0.78,2.0,105.0)
	var base := Rect2(p-Vector2(cell,cell*0.86),Vector2(cell*2.0,cell*1.72))
	if visible_cells > 16.0:
		var base_color: Color = Color("#f4ca55") if bool(city.get("is_player", false)) else city.alliance_color
		draw_rect(base,base_color,true)
		if bool(city.get("is_player", false)): draw_rect(base.grow(3.0),Color("#fff0a0"),false,2.0)
		return
	if bool(city.get("is_player", false)):
		_draw_ellipse(p+Vector2(0,s*0.65),Vector2(s*1.15,s*0.38),Color(0,0,0,0.3))
		draw_rect(Rect2(p-Vector2(s*0.85,s*0.85),Vector2(s*1.7,s*1.7)),Color("#fff0a0"),false,clampf(s*0.1,2.0,5.0))
		draw_colored_polygon(PackedVector2Array([p+Vector2(-s,-s*0.1),p+Vector2(-s*0.45,-s*0.75),p+Vector2(s*0.65,-s*0.65),p+Vector2(s,s*0.05),p+Vector2(s*0.25,s*0.7)]),Color("#d5a438"))
		draw_rect(Rect2(p+Vector2(-s*0.25,-s*0.7),Vector2(s*0.5,s*0.7)),Color("#ffe7a0"),true)
		if cell > 18.0: draw_string(ThemeDB.fallback_font,p+Vector2(-s*1.8,s*1.65),"مدينتي",HORIZONTAL_ALIGNMENT_CENTER,s*3.6,clampi(int(s*0.38),12,22),Color("#fff0a0"))
		return
	_draw_ellipse(p+Vector2(0,s*0.65),Vector2(s*1.15,s*0.38),Color(0,0,0,0.3))
	var wall := Color("#c7b998") if int(city.level)%2==0 else Color("#aeb9b8")
	draw_colored_polygon(PackedVector2Array([p+Vector2(-s,-s*0.1),p+Vector2(-s*0.45,-s*0.75),p+Vector2(s*0.65,-s*0.65),p+Vector2(s,s*0.05),p+Vector2(s*0.25,s*0.7)]),wall)
	var h := s*(0.5+float(city.level)/40.0)
	draw_rect(Rect2(p+Vector2(-s*0.25,-h),Vector2(s*0.5,h)),wall,true)
	draw_colored_polygon(PackedVector2Array([p+Vector2(-s*0.35,-h),p+Vector2(0,-h-s*0.55),p+Vector2(s*0.35,-h)]),city.alliance_color)
	if bool(city.protected): draw_arc(p,clampf(cell*1.5,7.0,180.0),0,TAU,32,Color(0.45,0.86,1.0,0.72),2.0,true)
	else: draw_string(ThemeDB.fallback_font,p+Vector2(s,-s),"!",HORIZONTAL_ALIGNMENT_LEFT,-1,14,Color("#ff554a"))
	if cell > 22.0:
		var label := "[%s] %s" % [str(city.alliance),str(city.owner)]
		draw_string(ThemeDB.fallback_font,p+Vector2(-s*2.0,s*1.5),label,HORIZONTAL_ALIGNMENT_CENTER,clampi(int(cell*2.4),64,240),clampi(int(cell*0.22),10,17),Color.WHITE)
		_draw_hex_badge(p+Vector2(s*1.2,-s),int(city.level),clampf(cell*0.15,5.0,11.0))

func _draw_hex_badge(p: Vector2,level: int,r: float) -> void:
	var pts := PackedVector2Array()
	for i in range(6):
		var a := TAU*float(i)/6.0
		pts.append(p+Vector2(cos(a),sin(a))*r)
	draw_colored_polygon(pts,Color("#2a3540"))
	draw_string(ThemeDB.fallback_font,p+Vector2(-r*0.65,r*0.35),str(level),HORIZONTAL_ALIGNMENT_CENTER,int(r*1.4),clampi(int(r*1.25),8,14),Color.WHITE)

func _draw_throne(p: Vector2,cell: float) -> void:
	var s := clampf(cell*1.35,3.0,150.0)
	_draw_ellipse(p+Vector2(0,s*0.65),Vector2(s*1.9,s*0.6),Color(0,0,0,0.3))
	draw_colored_polygon(PackedVector2Array([p+Vector2(-s*1.8,0),p+Vector2(-s,-s*0.9),p,p+Vector2(s,-s*0.9),p+Vector2(s*1.8,0),p+Vector2(0,s)]),Color("#b79a57"))
	draw_rect(Rect2(p-Vector2(s*0.7,s*1.1),Vector2(s*1.4,s*1.5)),Color("#d9bd75"),true)
	draw_colored_polygon(PackedVector2Array([p+Vector2(-s*0.8,-s*1.1),p+Vector2(0,-s*2.0),p+Vector2(s*0.8,-s*1.1)]),Color("#78502d"))
	if cell > 10.0: draw_string(ThemeDB.fallback_font,p+Vector2(s*1.5,0),"العرش",HORIZONTAL_ALIGNMENT_LEFT,-1,clampi(int(cell*0.35),12,20),Color("#fff0b3"))

func _draw_ellipse(center: Vector2,radii: Vector2,color: Color) -> void:
	var pts := PackedVector2Array()
	for i in range(20):
		var a := TAU*float(i)/20.0
		pts.append(center+Vector2(cos(a)*radii.x,sin(a)*radii.y))
	draw_colored_polygon(pts,color)

func _map_local_position(viewport_position: Vector2) -> Vector2:
	# InputEvent positions are viewport-relative; convert them because this map
	# sits below the top/bottom HUD panels rather than at (0, 0).
	return get_global_transform_with_canvas().affine_inverse() * viewport_position

func _is_map_gesture_position(p: Vector2) -> bool:
	# Keep gestures inside the map viewport and leave the right-side HUD buttons clickable.
	if p.x < 0.0 or p.x > size.x or p.y < 0.0 or p.y > size.y:
		return false
	if p.x > size.x - 148.0 and p.y > 110.0 and p.y < 570.0:
		return false
	return true

func _input(event: InputEvent) -> void:
	# استخدم _input للسحب، لكن لا تستهلك أحداث اللمس/الفأرة فوق عناصر الواجهة.
	if event is InputEventScreenTouch or event is InputEventScreenDrag:
		last_screen_input_msec = Time.get_ticks_msec()
	var event_position: Vector2 = Vector2.ZERO
	var has_position: bool = false
	if event is InputEventScreenTouch or event is InputEventScreenDrag or event is InputEventMouseButton or event is InputEventMouseMotion:
		event_position = event.position
		has_position = true
	if has_position and is_instance_valid(get_parent()) and get_parent().has_method("is_map_input_blocked"):
		if bool(get_parent().call("is_map_input_blocked", event_position)):
			return # اترك الحدث يصل إلى زر البحث/المحفوظات/القافلة أو حقول الإدخال.
	if event is InputEventMouseButton or event is InputEventMouseMotion:
		# Godot قد يولّد أحداث فأرة مقلّدة من اللمس؛ تجاهلها قرب أحداث اللمس.
		if Time.get_ticks_msec() - last_screen_input_msec < 100:
			return
	if event is InputEventMouseButton:
		var mp: Vector2 = _map_local_position(event.position)
		if not _is_map_gesture_position(mp):
			return
		if event.button_index == MOUSE_BUTTON_LEFT:
			if event.pressed:
				_cancel_inertia()
				dragging = true
				drag_start = mp
				drag_camera_start = camera_center
				touch_start_time = float(Time.get_ticks_msec()) / 1000.0
				_clear_drag_samples(mp)
			else:
				if dragging and drag_start.distance_to(mp) < 12.0 and (float(Time.get_ticks_msec()) / 1000.0 - touch_start_time) <= 0.45:
					_pick(mp)
				elif dragging:
					_start_map_inertia()
				dragging = false
				_save_view()
				get_viewport().set_input_as_handled()
		elif event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_UP:
			_cancel_inertia()
			_set_zoom(visible_cells / 1.15, mp)
			get_viewport().set_input_as_handled()
		elif event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_cancel_inertia()
			_set_zoom(visible_cells * 1.15, mp)
			get_viewport().set_input_as_handled()
	elif event is InputEventMouseMotion and dragging:
		var mp: Vector2 = _map_local_position(event.position)
		if not _is_map_gesture_position(mp):
			return
		camera_center = drag_camera_start - (mp - drag_start) / maxf(_cell_px(), 0.001) * Vector2(1.0, 1.0 / 0.86)
		_record_drag_sample(mp)
		_clamp_camera()
		_update_view_memory()
		queue_redraw()
		get_viewport().set_input_as_handled()
	elif event is InputEventScreenTouch:
		var mp: Vector2 = _map_local_position(event.position)
		if not _is_map_gesture_position(mp):
			if not event.pressed:
				touch_points.erase(event.index)
			return
		if event.pressed:
			_cancel_inertia() # أي لمسة جديدة تلغي الانزلاق السابق فوراً
			touch_points[event.index] = mp
			if touch_points.size() == 1:
				dragging = true
				drag_start = mp
				drag_camera_start = camera_center
				touch_start_time = float(Time.get_ticks_msec()) / 1000.0
				_clear_drag_samples(mp)
			elif touch_points.size() == 2:
				_cancel_inertia() # بدء pinch يلغي السرعة القديمة ولا يستعيدها بعده
				dragging = false
				drag_samples.clear()
				var pts: Array = touch_points.values()
				pinch_start_distance = Vector2(pts[0]).distance_to(Vector2(pts[1]))
				pinch_start_visible = visible_cells
		else:
			var was_tap: bool = touch_points.size() == 1 and drag_start.distance_to(mp) < 18.0 and (float(Time.get_ticks_msec()) / 1000.0 - touch_start_time) <= 0.45
			var was_drag: bool = touch_points.size() == 1 and dragging
			touch_points.erase(event.index)
			dragging = touch_points.size() == 1 and not was_drag
			if touch_points.is_empty() and was_tap:
				_pick(mp)
			elif touch_points.is_empty() and was_drag:
				_start_map_inertia()
			if touch_points.size() == 1:
				var remaining: Vector2 = Vector2(touch_points.values()[0])
				drag_start = remaining
				drag_camera_start = camera_center
				_clear_drag_samples(remaining)
			else:
				pinch_start_distance = 0.0
				if touch_points.is_empty():
					dragging = false
					_save_view()
		get_viewport().set_input_as_handled()
	elif event is InputEventScreenDrag:
		var mp: Vector2 = _map_local_position(event.position)
		if not _is_map_gesture_position(mp):
			return
		touch_points[event.index] = mp
		if touch_points.size() >= 2:
			_cancel_inertia()
			var pts: Array = touch_points.values()
			var p0: Vector2 = Vector2(pts[0])
			var p1: Vector2 = Vector2(pts[1])
			var d: float = p0.distance_to(p1)
			# Anchor pinch zoom to the midpoint between both fingers, not the moving finger.
			# This prevents the map from drifting diagonally while zooming near a city.
			var pinch_center: Vector2 = (p0 + p1) * 0.5
			if pinch_start_distance > 0.0:
				_set_zoom(pinch_start_visible * pinch_start_distance / maxf(d, 1.0), pinch_center)
		else:
			if dragging:
				camera_center = drag_camera_start - (mp - drag_start) / maxf(_cell_px(), 0.001) * Vector2(1.0, 1.0 / 0.86)
				_record_drag_sample(mp)
				_clamp_camera()
				_update_view_memory()
				queue_redraw()
		get_viewport().set_input_as_handled()

func _clear_drag_samples(pos: Vector2) -> void:
	drag_samples.clear()
	var now: float = float(Time.get_ticks_msec()) / 1000.0
	drag_samples.append({"pos": pos, "time": now})
	last_drag_sample_time = now

func _record_drag_sample(pos: Vector2) -> void:
	var now: float = float(Time.get_ticks_msec()) / 1000.0
	if not drag_samples.is_empty() and (pos as Vector2).distance_to(drag_samples[-1]["pos"] as Vector2) < 0.15:
		return
	drag_samples.append({"pos": pos, "time": now})
	last_drag_sample_time = now
	while drag_samples.size() > 2 and now - float(drag_samples[0]["time"]) > INERTIA_VELOCITY_WINDOW:
		drag_samples.pop_front()

func _start_map_inertia() -> void:
	inertia_velocity = Vector2.ZERO
	if drag_samples.size() < 2:
		set_process(false)
		return
	var now: float = float(Time.get_ticks_msec()) / 1000.0
	var last: Dictionary = drag_samples[-1]
	if now - float(last["time"]) > INERTIA_STALE_INPUT:
		set_process(false)
		return
	var first: Dictionary = drag_samples[0]
	var elapsed: float = float(last["time"]) - float(first["time"])
	if elapsed <= 0.001:
		set_process(false)
		return
	# تحويل سرعة البكسل إلى خانات/ثانية مع الحفاظ على معامل المنظور 0.86.
	var screen_delta: Vector2 = (last["pos"] as Vector2) - (first["pos"] as Vector2)
	inertia_velocity = -screen_delta / maxf(_cell_px(), 0.001) / elapsed * Vector2(1.0, 1.0 / 0.86)
	if inertia_velocity.length() > INERTIA_MAX_VELOCITY:
		inertia_velocity = inertia_velocity.normalized() * INERTIA_MAX_VELOCITY
	if inertia_velocity.length() >= INERTIA_MIN_VELOCITY:
		set_process(true)
	else:
		inertia_velocity = Vector2.ZERO
		set_process(false)

func _cancel_inertia() -> void:
	inertia_velocity = Vector2.ZERO
	set_process(zoom_animating)

func _process(delta: float) -> void:
	var needs_redraw: bool = false
	# Ease zoom over a short interval; keep the world point under the gesture anchor stable.
	if zoom_animating:
		var blend: float = 1.0 - exp(-13.0 * delta)
		visible_cells = lerpf(visible_cells, zoom_target_cells, blend)
		var world_after: Vector2 = _screen_to_world(zoom_anchor_screen)
		camera_center += zoom_anchor_world - world_after
		_clamp_camera()
		if absf(visible_cells - zoom_target_cells) < 0.20:
			visible_cells = zoom_target_cells
			var final_after: Vector2 = _screen_to_world(zoom_anchor_screen)
			camera_center += zoom_anchor_world - final_after
			_clamp_camera()
			zoom_animating = false
		_update_view_memory()
		needs_redraw = true
	if inertia_velocity.length() >= INERTIA_STOP_VELOCITY:
		var before: Vector2 = camera_center
		camera_center += inertia_velocity * delta
		_clamp_camera()
		# إذا اصطدم أحد المحورين بالحد، أوقف مركبة السرعة لذلك المحور فقط.
		if not is_equal_approx(camera_center.x, before.x + inertia_velocity.x * delta):
			inertia_velocity.x = 0.0
		if not is_equal_approx(camera_center.y, before.y + inertia_velocity.y * delta):
			inertia_velocity.y = 0.0
		inertia_velocity *= exp(-INERTIA_FRICTION * delta)
		_update_view_memory()
		needs_redraw = true
		if inertia_velocity.length() < INERTIA_STOP_VELOCITY:
			inertia_velocity = Vector2.ZERO
			_save_view()
	if needs_redraw:
		queue_redraw()
	if not zoom_animating and inertia_velocity.length() < INERTIA_STOP_VELOCITY:
		set_process(false)

func _set_zoom(value: float, anchor: Vector2) -> void:
	_cancel_inertia()
	# Rebase from the current view on each gesture update so pinch remains responsive.
	zoom_anchor_screen = anchor
	zoom_anchor_world = _screen_to_world(anchor)
	zoom_target_cells = clampf(value, MIN_VISIBLE, float(MAP_SIZE))
	zoom_animating = absf(visible_cells - zoom_target_cells) >= 0.20
	if not zoom_animating:
		visible_cells = zoom_target_cells
		_clamp_camera()
		_update_view_memory()
		queue_redraw()
	else:
		set_process(true)

func _clamp_camera() -> void:
	camera_center.x=clampf(camera_center.x,visible_cells*0.48,MAP_SIZE-visible_cells*0.48)
	camera_center.y=clampf(camera_center.y,visible_cells*0.48,MAP_SIZE-visible_cells*0.48)

func _pick(p: Vector2) -> void:
	var w := _screen_to_world(p)
	# القبائل مواقع مستقلة عن المدن العادية.
	var tribes: Dictionary = _tribe_positions()
	for tribe_id in tribes:
		var tp: Vector2i = tribes[tribe_id]
		if absf(w.x-float(tp.x)) <= 2.5 and absf(w.y-float(tp.y)) <= 2.5:
			var tribe: Dictionary = GameState.TRIBES.get(tribe_id, {})
			location_picked.emit("tribe", str(tribe_id), {"id":str(tribe_id),"name":str(tribe.get("name",tribe_id)),"x":tp.x,"y":tp.y,"relation":int(GameState.tribal_relations.get(tribe_id,0)),"cooldown":GameState.tribe_cooldown_left(str(tribe_id))})
			return
	# throne has a 4x4 footprint
	if w.x>=598 and w.x<602 and w.y>=598 and w.y<602:
		location_picked.emit("throne","throne",{"name":"العرش المركزي","x":598,"y":598,"size":4})
		return
	var cell := _cell_px()
	var best_city: Dictionary = {}; var best_dist := 999999.0
	var minx:=clampi(int(floor(w.x-4)),0,MAP_SIZE-1); var maxx:=clampi(int(ceil(w.x+4)),0,MAP_SIZE-1)
	var miny:=clampi(int(floor(w.y-4)),0,MAP_SIZE-1); var maxy:=clampi(int(ceil(w.y+4)),0,MAP_SIZE-1)
	for cy in range(floori(float(miny) / float(CHUNK_SIZE)),floori(float(maxy) / float(CHUNK_SIZE))+1):
		for cx in range(floori(float(minx) / float(CHUNK_SIZE)),floori(float(maxx) / float(CHUNK_SIZE))+1):
			for city in city_chunks.get(_chunk_key(cx,cy),[]):
				if w.x>=city.x-0.5 and w.x<city.x+1.5 and w.y>=city.y-0.5 and w.y<city.y+1.5:
					best_city=city; break
	if not best_city.is_empty():
		selected_city=best_city; selected_resource={}; queue_redraw(); location_picked.emit("city",str(best_city.id),best_city.duplicate(true)); return
	var best: Dictionary={}; best_dist=999999.0
	for cy in range(floori(float(miny) / float(CHUNK_SIZE)),floori(float(maxy) / float(CHUNK_SIZE))+1):
		for cx in range(floori(float(minx) / float(CHUNK_SIZE)),floori(float(maxx) / float(CHUNK_SIZE))+1):
			for n in resource_chunks.get(_chunk_key(cx,cy),[]):
				var d := Vector2(float(n.x),float(n.y)).distance_to(w)
				if d<best_dist and d<maxf(0.8,24.0/maxf(cell,1.0)):
					best=n; best_dist=d
	if not best.is_empty():
		selected_resource=best; selected_city={}; queue_redraw(); location_picked.emit("resource",str(best.id),best.duplicate(true))

func get_visible_cells() -> float:
	return visible_cells

func get_camera_center() -> Vector2i:
	return Vector2i(roundi(camera_center.x),roundi(camera_center.y))

func go_to(x: int,y: int) -> void:
	_cancel_inertia()
	zoom_animating = false
	set_process(false)
	zoom_target_cells = visible_cells
	camera_center=Vector2(clampf(x,0,MAP_SIZE-1),clampf(y,0,MAP_SIZE-1)); _clamp_camera(); queue_redraw(); _save_view()

func go_to_overview() -> void:
	_cancel_inertia()
	zoom_animating = false
	set_process(false)
	zoom_target_cells = float(MAP_SIZE)
	# إظهار حدود المقاطعة كاملة عند النظرة العامة. مساحة الرسم أصبحت بكامل الشاشة،
	# لذا يملأ العالم العرض المتاح بدل أن يظهر داخل لوحة صغيرة في المنتصف.
	camera_center = Vector2(MAP_SIZE * 0.5, MAP_SIZE * 0.5)
	visible_cells = float(MAP_SIZE)
	_clamp_camera()
	queue_redraw()
	_save_view()

func _exit_tree() -> void:
	_save_view()

func get_city_count() -> int:
	return city_data.size()
