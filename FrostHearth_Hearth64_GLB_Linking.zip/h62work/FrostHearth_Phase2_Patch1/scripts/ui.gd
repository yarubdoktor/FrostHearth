extends CanvasLayer
## الواجهة: شريط الموارد، لوحة المباني، الإشعارات. كلها مبنية بالكود وبتخطيط RTL.

signal panel_closed
signal audio_toggled(muted: bool)

const TOP_INSET := 40
const UITheme = preload("res://scripts/ui/ui_theme.gd")
const UIStrings = preload("res://scripts/ui/ui_strings.gd")

var root: Control
var top_panel: PanelContainer
var bottom_row: HBoxContainer
var res_labels := {}
var temp_label: Label
var pop_label: Label
var storm_label: Label
var toast_panel: PanelContainer
var toast_label: Label
var toast_tween: Tween
var panel: PanelContainer
var panel_box: VBoxContainer
var exp_button: Button
var survivors_button: Button
var idle_label: Label
var selected := -1
var afford: Array = []
var progress_label: Label = null
var reset_armed := false
var fame_label: Label
var mood_label: Label
var majlis_button: Button
var fazaa_button: Button
var audio_button: Button
var missions_button: Button
var research_button: Button
var world_button: Button
var audio_muted := false
var modal_layer: Control
var modal_box: VBoxContainer
var modal_afford: Array = []
var selected_world_province := "north_ridge"
var world_map_screen: Control = null
var world_map_transition_tween: Tween = null
var goal_panel: PanelContainer
var goal_title: Label
var goal_progress: ProgressBar
var goal_button: Button
var survivor_chip: Button
var profile_button: Button
var power_strip: PanelContainer
var power_label: Label
var nav_buttons: Dictionary = {}
var safe_rect := Rect2(0, 64, 1080, 1808)
var screen_sections := ["tribe", "research", "caravans", "map"]
var profile_data := {"name":"قائد الموقد", "tribe":"قبيلة الصقيع", "emblem":"❄", "color":"#D99A45"}
var current_section := "city"
var _ui_audit_clock := 0.0

func T(key: String) -> String:
	return UIStrings.T(key)


func ltr(s: String) -> String:
	# يحمي الأرقام والإشارات من انعكاس الاتجاه داخل النص العربي
	return "\u2066" + s + "\u2069"


func _ready() -> void:
	layer = 5
	root = Control.new()
	add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.layout_direction = Control.LAYOUT_DIRECTION_RTL
	root.theme = _make_theme()
	_apply_safe_area()
	if GameState.settings.has("profile") and typeof(GameState.settings["profile"]) == TYPE_DICTIONARY: profile_data = GameState.settings["profile"].duplicate(true)
	audio_muted = bool(GameState.settings.get("muted", false))
	_apply_audio_settings()
	_apply_graphics_quality()
	_build_top()
	_build_toast()
	_build_bottom()
	_build_modal()
	GameState.changed.connect(_on_changed)
	GameState.structure_changed.connect(_rebuild_panel)
	GameState.toast.connect(show_toast)
	_on_changed()
	if GameState.pending_msg != "":
		show_toast(GameState.pending_msg, false)
		GameState.pending_msg = ""
	if not GameState.intro_seen:
		show_intro()

func _apply_safe_area() -> void:
	var viewport_size := get_viewport().get_visible_rect().size
	var fallback_top := UITheme.SAFE_FALLBACK_TOP
	var fallback_bottom := UITheme.SAFE_FALLBACK_BOTTOM
	var raw := DisplayServer.get_display_safe_area()
	if raw.size.x > 0 and raw.size.y > 0 and DisplayServer.window_get_mode() != DisplayServer.WINDOW_MODE_MINIMIZED:
		var screen_size := DisplayServer.screen_get_size()
		if screen_size.x > 0 and screen_size.y > 0:
			var sx := viewport_size.x / float(screen_size.x)
			var sy := viewport_size.y / float(screen_size.y)
			safe_rect = Rect2(raw.position.x * sx, raw.position.y * sy, raw.size.x * sx, raw.size.y * sy)
		else:
			safe_rect = Rect2(0, fallback_top, viewport_size.x, viewport_size.y - fallback_top - fallback_bottom)
	else:
		safe_rect = Rect2(0, fallback_top, viewport_size.x, viewport_size.y - fallback_top - fallback_bottom)

# ---------- ثيم ----------

func _sb(c: Color, r: int, border: Color = UITheme.BORDER, bw: int = 1) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = c
	style.set_corner_radius_all(r)
	style.set_border_width_all(bw)
	style.border_color = border
	style.set_content_margin_all(20)
	style.shadow_color = Color(0.0, 0.0, 0.0, 0.20)
	style.shadow_size = 4
	return style

func _make_theme() -> Theme:
	var th := Theme.new()
	var f := SystemFont.new()
	f.font_names = PackedStringArray(["Noto Sans Arabic", "Noto Naskh Arabic", "Droid Arabic Naskh", "Cairo", "Tajawal", "Arial", "Tahoma", "sans-serif"])
	f.allow_system_fallback = true
	th.default_font = f
	th.default_font_size = UITheme.FONT_BODY
	th.set_color("font_color", "Label", UITheme.ICE)
	th.set_stylebox("panel", "PanelContainer", _sb(UITheme.NAVY, UITheme.PANEL_RADIUS, UITheme.BORDER, 2))
	th.set_stylebox("normal", "Button", _sb(UITheme.NAVY_LIGHT, 18, UITheme.BORDER, 1))
	th.set_stylebox("hover", "Button", _sb(UITheme.NAVY_LIGHT.lightened(0.12), 18, UITheme.AMBER, 2))
	th.set_stylebox("pressed", "Button", _sb(UITheme.AMBER, 18, UITheme.AMBER_LIGHT, 3))
	th.set_stylebox("disabled", "Button", _sb(UITheme.NAVY.darkened(0.15), 18, UITheme.NAVY_LIGHT, 1))
	th.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	th.set_color("font_color", "Button", UITheme.ICE)
	th.set_color("font_hover_color", "Button", UITheme.ICE)
	th.set_color("font_pressed_color", "Button", UITheme.NAVY)
	th.set_color("font_disabled_color", "Button", UITheme.ICE_MUTED)
	return th

# ---------- بناء الواجهة ----------

func _build_top() -> void:
	top_panel = PanelContainer.new()
	root.add_child(top_panel)
	top_panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	top_panel.offset_left = UITheme.SIDE_MARGIN
	top_panel.offset_right = -UITheme.SIDE_MARGIN
	top_panel.offset_top = maxf(UITheme.SAFE_FALLBACK_TOP, safe_rect.position.y) + 8
	top_panel.offset_bottom = top_panel.offset_top + UITheme.TOP_BAR_HEIGHT
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	top_panel.add_child(row)
	profile_button = Button.new()
	profile_button.text = "👤\n" + T("profile")
	profile_button.custom_minimum_size = Vector2(100, UITheme.BUTTON_HEIGHT)
	profile_button.add_theme_font_size_override("font_size", UITheme.FONT_DETAIL)
	profile_button.pressed.connect(_show_profile)
	row.add_child(profile_button)
	for k in GameState.RES_KEYS:
		row.add_child(_chip(k))
	var weather := VBoxContainer.new()
	weather.custom_minimum_size.x = 156
	weather.alignment = BoxContainer.ALIGNMENT_CENTER
	weather.add_theme_constant_override("separation", 4)
	temp_label = Label.new()
	temp_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	temp_label.add_theme_font_size_override("font_size", UITheme.FONT_DETAIL)
	weather.add_child(temp_label)
	storm_label = Label.new()
	storm_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	storm_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	storm_label.add_theme_font_size_override("font_size", UITheme.FONT_DETAIL)
	weather.add_child(storm_label)
	row.add_child(weather)
	survivor_chip = Button.new()
	survivor_chip.custom_minimum_size = Vector2(112, UITheme.BUTTON_HEIGHT)
	survivor_chip.icon = load("res://assets/ui/icons/survivors.svg")
	survivor_chip.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
	survivor_chip.pressed.connect(show_survivors)
	row.add_child(survivor_chip)
	# عداد القوة بارز في منتصف أعلى الشاشة، أسفل شريط الموارد مباشرة.
	power_strip = PanelContainer.new()
	root.add_child(power_strip)
	power_strip.set_anchors_preset(Control.PRESET_TOP_WIDE)
	power_strip.anchor_left = 0.20
	power_strip.anchor_right = 0.80
	power_strip.offset_left = 0
	power_strip.offset_right = 0
	power_strip.offset_top = top_panel.offset_bottom + 8
	power_strip.offset_bottom = power_strip.offset_top + 66
	power_strip.add_theme_stylebox_override("panel", _sb(UITheme.NAVY.darkened(0.05), 18, UITheme.AMBER, 3))
	power_strip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	power_label = Label.new()
	power_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	power_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	power_label.add_theme_font_size_override("font_size", 25)
	power_label.add_theme_color_override("font_color", UITheme.AMBER_LIGHT)
	power_label.text = "⚔  القوة الإجمالية للمدينة  " + ltr(str(GameState.city_power()))
	power_strip.add_child(power_label)

func _chip(key: String) -> Control:
	var box := VBoxContainer.new()
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 2)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 6)
	var icon := TextureRect.new()
	icon.texture = load("res://assets/ui/icons/%s.svg" % key)
	icon.custom_minimum_size = Vector2(UITheme.RESOURCE_ICON_SIZE, UITheme.RESOURCE_ICON_SIZE)
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	row.add_child(icon)
	var value := Label.new()
	value.add_theme_font_size_override("font_size", UITheme.FONT_BODY)
	row.add_child(value)
	box.add_child(row)
	var cap := ProgressBar.new()
	cap.custom_minimum_size = Vector2(0, 6)
	cap.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cap.max_value = 100.0
	cap.show_percentage = false
	box.add_child(cap)
	res_labels[key] = {"label": value, "bar": cap}
	return box

func _build_toast() -> void:
	toast_panel = PanelContainer.new()
	root.add_child(toast_panel)
	toast_panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	toast_panel.offset_left = 40
	toast_panel.offset_right = -40
	toast_panel.offset_top = maxf(UITheme.SAFE_FALLBACK_TOP, safe_rect.position.y) + 184
	toast_panel.offset_bottom = toast_panel.offset_top + 104
	toast_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast_panel.modulate.a = 0.0
	toast_label = Label.new()
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	toast_panel.add_child(toast_label)


func _build_bottom() -> void:
	var bottom := VBoxContainer.new()
	root.add_child(bottom)
	bottom.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	bottom.offset_left = UITheme.SIDE_MARGIN
	bottom.offset_right = -UITheme.SIDE_MARGIN
	bottom.offset_top = -(UITheme.GOAL_BAR_HEIGHT + UITheme.NAV_BAR_HEIGHT + 64 + 4 * UITheme.GAP + 640)
	bottom.offset_bottom = -maxf(UITheme.SAFE_FALLBACK_BOTTOM, get_viewport().get_visible_rect().size.y - safe_rect.end.y) - UITheme.GAP
	bottom.grow_vertical = Control.GROW_DIRECTION_BEGIN
	bottom.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bottom.add_theme_constant_override("separation", UITheme.GAP)
	panel = PanelContainer.new()
	panel.visible = false
	panel.mouse_filter = Control.MOUSE_FILTER_STOP
	bottom.add_child(panel)
	panel_box = VBoxContainer.new()
	panel_box.add_theme_constant_override("separation", UITheme.GAP)
	panel.add_child(panel_box)
	goal_panel = PanelContainer.new()
	goal_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	bottom.add_child(goal_panel)
	var goal_box := VBoxContainer.new()
	goal_box.add_theme_constant_override("separation", 4)
	goal_panel.add_child(goal_box)
	var goal_row := HBoxContainer.new()
	goal_row.add_theme_constant_override("separation", UITheme.GAP)
	goal_box.add_child(goal_row)
	goal_title = Label.new()
	goal_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	goal_title.add_theme_font_size_override("font_size", UITheme.FONT_BODY)
	goal_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	goal_row.add_child(goal_title)
	goal_button = Button.new()
	goal_button.text = T("go")
	goal_button.custom_minimum_size = Vector2(176, UITheme.BUTTON_HEIGHT)
	goal_button.pressed.connect(_on_goal_pressed)
	goal_row.add_child(goal_button)
	goal_progress = ProgressBar.new()
	goal_progress.custom_minimum_size = Vector2(0, 8)
	goal_progress.show_percentage = false
	goal_box.add_child(goal_progress)
	bottom_row = HBoxContainer.new()
	bottom_row.add_theme_constant_override("separation", UITheme.GAP)
	bottom_row.mouse_filter = Control.MOUSE_FILTER_STOP
	bottom.add_child(bottom_row)
	# أربع خانات مرنة؛ المدينة/الخريطة هي الخانة المميزة عند طرف الشريط.
	var entries := [
		{"id":"tribe", "icon":"tribe", "text":"tribe", "call":Callable(self,"show_survivors")},
		{"id":"research", "icon":"research", "text":"research", "call":Callable(self,"show_research")},
		{"id":"caravans", "icon":"caravan", "text":"caravans", "call":Callable(self,"show_caravans")},
		{"id":"map", "icon":"map", "text":"city_map", "call":Callable(self,"_show_city_map")}
	]
	for entry in entries:
		var b := Button.new()
		b.custom_minimum_size = Vector2(0, UITheme.BUTTON_HEIGHT + (10 if str(entry["id"]) == "map" else 0))
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.size_flags_stretch_ratio = 1.35 if str(entry["id"]) == "map" else 1.0
		b.icon = load("res://assets/ui/icons/%s.svg" % entry["icon"])
		b.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
		b.text = T(str(entry["text"]))
		b.add_theme_font_size_override("font_size", UITheme.FONT_DETAIL)
		if str(entry["id"]) == "map":
			b.add_theme_stylebox_override("normal", _sb(UITheme.AMBER.darkened(0.45), 18, UITheme.AMBER, 2))
		b.pressed.connect(entry["call"])
		bottom_row.add_child(b)
		nav_buttons[str(entry["id"])] = b
	# عداد القوة موجود أعلى الشاشة في المنتصف.
	# متغيرات توافق قديمة يستخدمها تحديث الحالة.
	exp_button = nav_buttons["tribe"]
	majlis_button = nav_buttons["tribe"]
	fazaa_button = nav_buttons["tribe"]
	survivors_button = survivor_chip
	audio_button = Button.new()
	audio_button.text = T("audio_on")
	audio_button.pressed.connect(_toggle_audio)
	missions_button = null
	research_button = null
	world_button = nav_buttons["map"]

func _show_city() -> void:
	close_modal()
	close_world_map()
	hide_panel()
	current_section = "city"

func _show_city_map() -> void:
	# الخانة المميزة تفتح خريطة العالم؛ الرجوع يعيد المدينة كما كان.
	show_world_map()

func _show_profile() -> void:
	_clear_modal()
	modal_layer.visible = true
	modal_layer.modulate.a = 1.0
	_modal_header(T("profile"))
	var card := PanelContainer.new()
	modal_box.add_child(card)
	var info := VBoxContainer.new()
	info.add_theme_constant_override("separation", 8)
	card.add_child(info)
	_mlabel("❄  " + str(profile_data.get("name", "قائد الموقد")), 34, UITheme.AMBER_LIGHT, true)
	_mlabel(str(profile_data.get("tribe", "قبيلة الصقيع")) + "  " + str(profile_data.get("emblem", "❄")), UITheme.FONT_BODY, UITheme.ICE, true)
	_mlabel("القوة الإجمالية: " + ltr(str(GameState.city_power())), UITheme.FONT_BODY, UITheme.AMBER_LIGHT, true)
	_mlabel("المعرّف: " + ltr("FH-" + str(abs(hash(str(profile_data.get("name", "قائد الموقد")))) % 10000000)), UITheme.FONT_DETAIL, UITheme.ICE_MUTED, true)
	for item in [
		{"text":"الملف الشخصي · تعديل", "call":Callable(self,"_show_profile_card")},
		{"text":"الإحصاءات", "call":Callable(self,"_show_statistics")},
		{"text":"الإعدادات", "call":Callable(self,"_show_settings")}
	]:
		var b := Button.new()
		b.text = "◈   " + str(item["text"])
		b.custom_minimum_size = Vector2(0, 104)
		b.pressed.connect(item["call"])
		modal_box.add_child(b)
	var tw := create_tween()
	tw.tween_property(modal_layer, "modulate:a", 1.0, UITheme.ANIM_SECONDS)

func _show_profile_card() -> void:
	_clear_modal(); modal_layer.visible = true; _modal_header("بطاقة الملف")
	_mlabel("الصورة والإطار: ❄", 30, UITheme.AMBER_LIGHT)
	_mlabel("الاسم: " + str(profile_data.get("name", "قائد الموقد")), 28)
	_mlabel("القبيلة والشعار: " + str(profile_data.get("tribe", "قبيلة الصقيع")) + " " + str(profile_data.get("emblem", "❄")), 26)
	_mlabel("المعرّف: FH-" + ltr(str(abs(hash(str(profile_data.get("name", "قائد الموقد")))) % 10000000)), 24)
	_mlabel("القوة الإجمالية: " + ltr(str(GameState.city_power())) + "   •   الرتبة: حارس الموقد", 26)
	_mlabel("مدة اللعب: تُعرض عند توفر عدّاد جلسات موثوق", 22, UITheme.ICE_MUTED)
	if not GameState.claimed_achievements.is_empty():
		var badge_titles := PackedStringArray()
		for achievement in GameState.ACHIEVEMENTS:
			if str(achievement.get("id", "")) in GameState.claimed_achievements:
				badge_titles.append("🏅 " + str(achievement.get("title", "إنجاز")))
		_mlabel("الشارات المستلمة: " + "، ".join(badge_titles), 22, UITheme.AMBER_LIGHT)
	var copy_btn := Button.new(); copy_btn.text = "نسخ المعرّف"; copy_btn.custom_minimum_size.y = 88
	copy_btn.pressed.connect(func(): DisplayServer.clipboard_set("FH-" + str(abs(hash(str(profile_data.get("name", "قائد الموقد")))) % 10000000)); show_toast("تم نسخ المعرّف", false))
	modal_box.add_child(copy_btn)
	var edit := Button.new(); edit.text = "تعديل الملف"; edit.custom_minimum_size.y = 88; edit.pressed.connect(_show_profile_edit); modal_box.add_child(edit)
	var back := Button.new(); back.text = "رجوع"; back.custom_minimum_size.y = 88; back.pressed.connect(_show_profile); modal_box.add_child(back)

func _show_profile_edit() -> void:
	_clear_modal(); modal_layer.visible = true; _modal_header("تعديل الملف الشخصي")
	_mlabel("الاسم", 26)
	var name_edit := LineEdit.new(); name_edit.text = str(profile_data.get("name", "قائد الموقد")); name_edit.placeholder_text = "اكتب اسماً من 2 إلى 20 حرفاً"; name_edit.custom_minimum_size.y = 76; modal_box.add_child(name_edit)
	_mlabel("اسم القبيلة", 26)
	var tribe_edit := LineEdit.new(); tribe_edit.text = str(profile_data.get("tribe", "قبيلة الصقيع")); tribe_edit.custom_minimum_size.y = 76; modal_box.add_child(tribe_edit)
	_mlabel("الشعار", 26)
	var emblem_edit := OptionButton.new(); emblem_edit.add_item("❄ الثلج"); emblem_edit.add_item("🔥 النار"); emblem_edit.add_item("🛡 الدرع"); emblem_edit.custom_minimum_size.y = 76; modal_box.add_child(emblem_edit)
	var save := Button.new(); save.text = "حفظ التعديلات"; save.custom_minimum_size.y = 96
	save.pressed.connect(func():
		var nm := name_edit.text.strip_edges(); var tn := tribe_edit.text.strip_edges()
		if nm.length() < 2 or nm.length() > 20 or tn.length() < 2 or tn.length() > 24:
			show_toast("تحقق من الاسم والقبيلة: الاسم 2–20 والقبيلة 2–24 حرفاً", true); return
		profile_data["name"] = nm; profile_data["tribe"] = tn; profile_data["emblem"] = ["❄", "🔥", "🛡"][emblem_edit.selected]
		GameState.settings["profile"] = profile_data.duplicate(true); GameState.save_game(); show_toast("تم حفظ الملف", false); _show_profile_card())
	modal_box.add_child(save)
	var back := Button.new(); back.text = "رجوع"; back.custom_minimum_size.y = 80; back.pressed.connect(_show_profile_card); modal_box.add_child(back)

func _show_statistics() -> void:
	_clear_modal(); modal_layer.visible = true; _modal_header("إحصاءات القائد")
	for row in ["المدينة|مستوى الموقد: %d" % GameState.hearth_level(), "البحوث|أبحاث مكتملة: %d" % GameState.research_count(), "التجارة|قوافل العالم: %d" % GameState.world_caravans.size(), "السمعة|نقاط السمعة: %d" % GameState.fame]:
		var parts: PackedStringArray = row.split("|", false, 1); var card := PanelContainer.new(); modal_box.add_child(card); var vb := VBoxContainer.new(); card.add_child(vb); _mlabel(parts[0], 27, UITheme.AMBER_LIGHT); _mlabel(parts[1], 25)
	var back := Button.new(); back.text = "رجوع"; back.custom_minimum_size.y = 88; back.pressed.connect(_show_profile); modal_box.add_child(back)

func _show_heroes() -> void:
	_clear_modal(); modal_layer.visible = true; _modal_header(T("heroes")); _add_text(T("section_coming_soon"), UITheme.FONT_BODY)
func _show_backpack() -> void:
	_clear_modal(); modal_layer.visible = true; _modal_header(T("backpack")); _add_text(T("section_coming_soon"), UITheme.FONT_BODY)
func _show_store() -> void:
	_clear_modal(); modal_layer.visible = true; _modal_header(T("store")); _add_text(T("section_coming_soon"), UITheme.FONT_BODY)

func show_more() -> void:
	# توافق مؤقت للاستدعاءات القديمة؛ لم يعد هناك قسم «المزيد» في الشريط.
	_show_profile()

func _show_settings() -> void:
	_clear_modal(); modal_layer.visible = true; _modal_header("الإعدادات")
	var st: Dictionary = GameState.settings
	var section := func(title: String):
		var l := _mlabel(title, 30, UITheme.AMBER_LIGHT); l.add_theme_constant_override("outline_size", 0)
	section.call("الصوت")
	var master := CheckButton.new(); master.text = "الصوت العام"; master.button_pressed = not bool(st.get("muted", false)); master.custom_minimum_size.y = 84; modal_box.add_child(master)
	master.toggled.connect(func(v: bool): audio_muted = not v; _apply_audio_settings(); _save_settings())
	var effects := CheckButton.new(); effects.text = "المؤثرات"; effects.button_pressed = bool(st.get("effects", true)); effects.custom_minimum_size.y = 84; modal_box.add_child(effects)
	effects.toggled.connect(func(v: bool): st["effects"] = v; _set_bus_mute("SFX", not v); _save_settings())
	var ambience := CheckButton.new(); ambience.text = "أجواء الرياح والنار"; ambience.button_pressed = bool(st.get("ambience", true)); ambience.custom_minimum_size.y = 84; modal_box.add_child(ambience)
	ambience.toggled.connect(func(v: bool): st["ambience"] = v; _set_bus_mute("Ambience", not v); _save_settings())
	section.call("جودة الرسومات")
	var quality := OptionButton.new(); quality.add_item("منخفضة"); quality.add_item("متوسطة"); quality.add_item("عالية"); quality.custom_minimum_size.y = 84; quality.selected = {"low":0,"medium":1,"high":2}.get(str(st.get("graphics_quality", "medium")), 1); modal_box.add_child(quality)
	quality.item_selected.connect(func(i: int): st["graphics_quality"] = ["low","medium","high"][i]; _apply_graphics_quality(); _save_settings())
	for title in ["اللغة — قريباً", "الاهتزاز — قريباً", "الإشعارات — قريباً"]:
		var disabled := Button.new(); disabled.text = title; disabled.disabled = true; disabled.custom_minimum_size.y = 84; modal_box.add_child(disabled)
	section.call("وضع المطوّر — خاص")
	_mlabel("وضع اختبار محلي للمطوّر فقط. لا يغيّر نظام الدفع للاعبين العاديين.", 22, UITheme.ICE_MUTED)
	var dev_button := Button.new()
	dev_button.text = "فتح وضع المطوّر بكلمة السر"
	dev_button.custom_minimum_size.y = 88
	dev_button.pressed.connect(_show_developer_password)
	modal_box.add_child(dev_button)
	if GameState.developer_mode:
		var dev_panel_button := Button.new()
		dev_panel_button.text = "لوحة أدوات المطوّر — مفعّلة"
		dev_panel_button.custom_minimum_size.y = 88
		dev_panel_button.pressed.connect(_show_developer_panel)
		modal_box.add_child(dev_panel_button)
	section.call("الحساب")
	_mlabel("لعب محلي", 26); _mlabel("ربط الحساب والحفظ السحابي غير متاحين في هذه النسخة.", 22, UITheme.ICE_MUTED)
	for title in ["ربط حساب", "حفظ سحابي"]:
		var disabled := Button.new(); disabled.text = title; disabled.disabled = true; disabled.custom_minimum_size.y = 84; modal_box.add_child(disabled)
	section.call("المساعدة")
	var tutorial := Button.new(); tutorial.text = "إعادة الشرح"; tutorial.disabled = not GameState.intro_seen; tutorial.custom_minimum_size.y = 84; tutorial.pressed.connect(show_intro); modal_box.add_child(tutorial)
	_mlabel("رقم النسخة: HUD Foundation v2", 22, UITheme.ICE_MUTED)
	section.call("منطقة الخطر")
	var reset := Button.new(); reset.text = "إعادة البدء من جديد"; reset.custom_minimum_size.y = 96; reset.add_theme_stylebox_override("normal", _sb(Color(0.30,0.08,0.10),18,UITheme.DANGER,2)); reset.pressed.connect(_confirm_reset_screen); modal_box.add_child(reset)
	var back := Button.new(); back.text = "العودة إلى الملف الشخصي"; back.custom_minimum_size.y = 88; back.pressed.connect(_show_profile); modal_box.add_child(back)

func _show_developer_password() -> void:
	_clear_modal(); modal_layer.visible = true; _modal_header("دخول المطوّر")
	_mlabel("أدخل كلمة المرور لتفعيل أدوات الاختبار على هذا الجهاز.", 24, UITheme.ICE_MUTED)
	var password := LineEdit.new()
	password.placeholder_text = "كلمة المرور"
	password.secret = true
	password.custom_minimum_size.y = 84
	modal_box.add_child(password)
	var error_label := _mlabel("", 22, UITheme.DANGER)
	var enter := Button.new(); enter.text = "دخول"; enter.custom_minimum_size.y = 90; modal_box.add_child(enter)
	enter.pressed.connect(func():
		if password.text == "19983010":
			GameState.developer_mode = true
			GameState.save_game()
			show_toast("تم تفعيل وضع المطوّر على هذا الجهاز", false)
			_show_developer_panel()
		else:
			error_label.text = "كلمة المرور غير صحيحة"
	)
	var back := Button.new(); back.text = "رجوع"; back.custom_minimum_size.y = 78; back.pressed.connect(_show_settings); modal_box.add_child(back)

func _show_developer_panel() -> void:
	if not GameState.developer_mode:
		_show_settings(); return
	_clear_modal(); modal_layer.visible = true; _modal_header("لوحة المطوّر", UITheme.AMBER_LIGHT)
	_mlabel("الأدوات التالية للتجربة المحلية فقط؛ عند إيقاف الوضع تعود التكاليف والقيود العادية.", 23, UITheme.ICE_MUTED)
	var resources := Button.new(); resources.text = "منح موارد وسكان وسمعة بكميات كبيرة"; resources.custom_minimum_size.y = 88; modal_box.add_child(resources)
	resources.pressed.connect(func(): GameState.developer_grant_resources(); show_toast("تم منح موارد الاختبار", false); _show_developer_panel())
	var research := Button.new(); research.text = "فتح جميع البحوث"; research.custom_minimum_size.y = 88; modal_box.add_child(research)
	research.pressed.connect(func(): GameState.developer_unlock_research(); show_toast("تم فتح جميع البحوث", false); _show_developer_panel())
	var finish := Button.new(); finish.text = "إنهاء جميع الإنشاءات فوراً"; finish.custom_minimum_size.y = 88; modal_box.add_child(finish)
	finish.pressed.connect(func(): GameState.developer_finish_all_construction(); show_toast("اكتملت الإنشاءات الجارية", false); _show_developer_panel())
	var military := Button.new(); military.text = "فتح أعلى فئة ورتبة للفرسان للاختبار"; military.custom_minimum_size.y = 88; modal_box.add_child(military)
	military.pressed.connect(func(): GameState.developer_unlock_military(); show_toast("تم فتح الفئة والرتبة القصوى", false); _show_developer_panel())
	var disable := Button.new(); disable.text = "إيقاف وضع المطوّر"; disable.custom_minimum_size.y = 90; disable.add_theme_stylebox_override("normal", _sb(Color(0.30,0.08,0.10),18,UITheme.DANGER,2)); modal_box.add_child(disable)
	disable.pressed.connect(func(): GameState.developer_mode = false; GameState.save_game(); show_toast("تم إيقاف وضع المطوّر", false); _show_settings())
	var back := Button.new(); back.text = "العودة إلى الإعدادات"; back.custom_minimum_size.y = 78; back.pressed.connect(_show_settings); modal_box.add_child(back)

func _set_bus_mute(bus_name: String, muted: bool) -> void:
	var idx := AudioServer.get_bus_index(bus_name)
	if idx >= 0: AudioServer.set_bus_mute(idx, muted)

func _apply_audio_settings() -> void:
	var st: Dictionary = GameState.settings; st["muted"] = audio_muted
	AudioServer.set_bus_mute(0, audio_muted)
	_set_bus_mute("SFX", not bool(st.get("effects", true)))
	_set_bus_mute("Ambience", not bool(st.get("ambience", true)))
	if is_instance_valid(audio_button): audio_button.text = T("audio_off") if audio_muted else T("audio_on")
	audio_toggled.emit(audio_muted)

func _apply_graphics_quality() -> void:
	var quality := str(GameState.settings.get("graphics_quality", "medium"))
	var particles: int = int({"low": 8, "medium": 20, "high": 40}.get(quality, 20))
	# تُطبّق إعدادات الجسيمات على أي عقدة ثلج موجودة، دون تغيير منطق اللعب.
	var nodes := get_tree().get_nodes_in_group("snow_particles")
	for node in nodes:
		if node is GPUParticles3D or node is CPUParticles3D: node.amount = particles

func _save_settings() -> void:
	GameState.settings["profile"] = profile_data.duplicate(true)
	GameState.settings["muted"] = audio_muted
	GameState.save_game()

func _confirm_reset_screen() -> void:
	_clear_modal()
	modal_layer.visible = true
	_modal_header("تأكيد إعادة البدء")
	_mlabel("سيُحذف تقدم المدينة والموارد والبحوث نهائياً من هذا الجهاز. هل تريد المتابعة؟", UITheme.FONT_BODY, UITheme.DANGER)
	var confirm_button := Button.new()
	confirm_button.text = "نعم، احذف التقدم وأعد البدء"
	confirm_button.custom_minimum_size.y = 96
	modal_box.add_child(confirm_button)
	confirm_button.pressed.connect(func():
		GameState.reset_game()
		profile_data = {"name":"قائد الموقد", "tribe":"قبيلة الصقيع", "emblem":"❄", "color":"#D99A45"}
		GameState.settings = {"muted":false,"effects":true,"ambience":true,"graphics_quality":"medium","profile":profile_data.duplicate(true)}
		GameState.save_game()
		audio_muted = false
		_apply_audio_settings()
		close_modal()
		hide_panel()
	)
	var cancel := Button.new()
	cancel.text = "إلغاء — العودة للإعدادات"
	cancel.custom_minimum_size.y = 84
	cancel.pressed.connect(_show_settings)
	modal_box.add_child(cancel)

func _on_goal_pressed() -> void:
	if float(GameState.stock.get("coal", 0.0)) < 15.0:
		show_missions()
		return
	if GameState.pending_event != "":
		show_majlis()
		return
	if GameState.idle() > 0 and GameState.free_slots() > 0:
		show_survivors()
		return
	if GameState.storm_warning() or GameState.is_storm():
		show_majlis()
		return
	var mission := _current_goal_mission()
	if mission.is_empty():
		show_missions()
		return
	var mission_id := str(mission.get("id", ""))
	if GameState.mission_done(mission) and not mission_id in GameState.claimed_missions:
		GameState.claim_mission(mission_id)
		_on_changed()
	else:
		var kind := str(mission.get("kind", ""))
		if kind == "building" or kind == "hearth":
			show_missions()
		elif kind == "relation":
			show_fazaa()
		else:
			show_missions()

func _current_goal_mission() -> Dictionary:
	for mission in GameState.MISSIONS:
		if not str(mission.get("id", "")) in GameState.claimed_missions:
			return mission
	return {}

func _refresh_goal() -> void:
	if not is_instance_valid(goal_title):
		return
	var urgent := ""
	if float(GameState.stock.get("coal", 0.0)) < 15.0:
		urgent = T("urgent_coal")
	elif GameState.storm_warning() or GameState.is_storm():
		urgent = T("urgent_storm")
	elif GameState.idle() > 0 and GameState.free_slots() > 0:
		urgent = T("urgent_idle")
	elif GameState.pending_event != "":
		urgent = T("urgent_council")
	if urgent != "":
		goal_title.text = urgent
		goal_progress.value = 100.0
		goal_button.text = T("go")
		return
	var mission := _current_goal_mission()
	if mission.is_empty():
		goal_title.text = T("goal_empty")
		goal_progress.value = 100.0
		goal_button.text = T("missions")
		return
	var target := maxi(1, int(mission.get("target", 1)))
	var progress := mini(target, GameState.mission_progress(mission))
	goal_title.text = str(mission.get("title", T("current_goal")))
	goal_progress.max_value = target
	goal_progress.value = progress
	var done := GameState.mission_done(mission)
	goal_button.text = T("claim_reward") if done else T("go")

func _toggle_audio() -> void:
	audio_muted = not audio_muted
	_apply_audio_settings()
	_save_settings()
	if modal_layer.visible:
		_show_settings()


func _on_reset(btn: Button) -> void:
	if not reset_armed:
		reset_armed = true
		btn.text = "تأكيد المسح؟"
		await get_tree().create_timer(3.0).timeout
		reset_armed = false
		if is_instance_valid(btn):
			btn.text = "بدء من جديد"
	else:
		reset_armed = false
		btn.text = "بدء من جديد"
		GameState.reset_game()
		hide_panel()
		close_modal()


# ---------- تحديث ----------

func _on_changed() -> void:
	for k in GameState.RES_KEYS:
		if res_labels.has(k):
			var bundle: Dictionary = res_labels[k]
			bundle["label"].text = ltr(str(int(GameState.stock[k])))
			bundle["bar"].value = 100.0 * float(GameState.stock[k]) / maxf(1.0, float(GameState.storage_cap()))
	var tv := int(round(GameState.temp))
	temp_label.text = T("temperature") + " " + ltr("%d°" % tv)
	temp_label.add_theme_color_override("font_color", UITheme.DANGER if GameState.temp < -25.0 else (UITheme.AMBER_LIGHT if GameState.temp < -10.0 else UITheme.ICE))
	if GameState.is_storm():
		storm_label.text = T("storm_active")
		storm_label.add_theme_color_override("font_color", UITheme.DANGER)
	elif GameState.storm_warning():
		storm_label.text = T("storm_warning")
		storm_label.add_theme_color_override("font_color", UITheme.AMBER_LIGHT)
	else:
		storm_label.text = T("weather_calm")
		storm_label.add_theme_color_override("font_color", UITheme.SUCCESS)
	survivor_chip.text = ltr("%d/%d" % [GameState.pop, GameState.pop_cap()])
	if is_instance_valid(majlis_button):
		majlis_button.text = T("tribe") + (" ●" if GameState.pending_event != "" else "")
	if is_instance_valid(research_button):
		research_button.text = T("research") + " " + ltr("%d/%d" % [GameState.research_count(), GameState.RESEARCHES.size()])
	if is_instance_valid(exp_button):
		exp_button.text = T("more")
	if is_instance_valid(power_label):
		power_label.text = "⚔  القوة الإجمالية للمدينة  " + ltr(str(GameState.city_power()))
	for e in afford:
		e["btn"].disabled = not GameState.can_afford(e["cost"])
	for e2 in modal_afford:
		e2["btn"].disabled = not GameState.can_afford(e2["cost"])
	if progress_label != null and selected >= 0:
		var p: Dictionary = GameState.plots[selected]
		progress_label.text = "المتبقي: " + ltr(GameState.fmt_time(float(p["end"]) - GameState.now()))
	var hearth := GameState.hearth_level()
	if nav_buttons.has("tribe"):
		nav_buttons["tribe"].visible = hearth >= 1
	if nav_buttons.has("research"):
		nav_buttons["research"].visible = hearth >= 2
	if nav_buttons.has("map"):
		nav_buttons["map"].visible = true
	_refresh_goal()
	_enforce_ui_minimums(root)

func _enforce_ui_minimums(node: Node) -> void:
	for child in node.get_children():
		if child is Button:
			var b := child as Button
			b.custom_minimum_size = Vector2(maxf(b.custom_minimum_size.x, UITheme.TOUCH_MIN), maxf(b.custom_minimum_size.y, UITheme.BUTTON_HEIGHT))
		elif child is Label:
			var label := child as Label
			var current_size := label.get_theme_font_size("font_size")
			if current_size < UITheme.FONT_DETAIL:
				label.add_theme_font_size_override("font_size", UITheme.FONT_DETAIL)
		_enforce_ui_minimums(child)

func _process(delta: float) -> void:
	_ui_audit_clock += delta
	if _ui_audit_clock >= 0.5:
		_ui_audit_clock = 0.0
		if is_instance_valid(root):
			_enforce_ui_minimums(root)

func show_toast(msg: String, bad: bool = false) -> void:
	toast_label.text = msg
	toast_label.add_theme_color_override("font_color", UITheme.DANGER if bad else UITheme.SUCCESS)
	toast_panel.modulate.a = 1.0
	if toast_tween:
		toast_tween.kill()
	toast_tween = create_tween()
	toast_tween.tween_interval(3.5)
	toast_tween.tween_property(toast_panel, "modulate:a", 0.0, 0.6)


func is_over_ui(pos: Vector2) -> bool:
	if is_instance_valid(world_map_screen) and world_map_screen.visible:
		return true
	if modal_layer.visible and modal_layer.get_global_rect().has_point(pos):
		return true
	if top_panel.get_global_rect().has_point(pos):
		return true
	if panel.visible and panel.get_global_rect().has_point(pos):
		return true
	if is_instance_valid(goal_panel) and goal_panel.get_global_rect().has_point(pos):
		return true
	if bottom_row.get_global_rect().has_point(pos):
		return true
	return false

# ---------- لوحة المبنى ----------

func show_plot(i: int) -> void:
	selected = i
	_rebuild_panel()
	_on_changed()


func hide_panel() -> void:
	selected = -1
	_rebuild_panel()
	panel_closed.emit()


func _cost_text(cost: Dictionary) -> String:
	var parts := PackedStringArray()
	for k in GameState.RES_KEYS:
		if cost.has(k):
			parts.append("%s %d" % [GameState.RES_NAMES[k], int(cost[k])])
	return "، ".join(parts)


func _add_header(title: String) -> void:
	var row := HBoxContainer.new()
	var l := Label.new()
	l.text = title
	l.add_theme_font_size_override("font_size", 34)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(l)
	var x := Button.new()
	x.text = T("close")
	x.icon = load("res://assets/ui/icons/close.svg")
	x.custom_minimum_size = Vector2(UITheme.TOUCH_MIN, UITheme.BUTTON_HEIGHT)
	x.pressed.connect(hide_panel)
	row.add_child(x)
	panel_box.add_child(row)


func _add_text(text: String, size: int = 26, col: Color = Color(0.85, 0.9, 1.0)) -> Label:
	var l := Label.new()
	l.text = text
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	panel_box.add_child(l)
	return l


func _rebuild_panel() -> void:
	afford.clear()
	progress_label = null
	for c in panel_box.get_children():
		panel_box.remove_child(c)
		c.queue_free()
	if selected < 0:
		panel.hide()
		return
	panel.show()
	var i := selected
	var p: Dictionary = GameState.plots[i]
	var type: String = p["type"]
	var lvl := int(p["level"])
	var busy := float(p["end"]) > 0.0

	if type == "":
		if not GameState.is_plot_unlocked(i):
			_add_header("توسعة المدينة")
			_add_text("تُفتح هذه القطعة عند رفع نار الضيافة إلى المستوى %d." % GameState.plot_unlock_level(i), 28, Color(1.0, 0.82, 0.48))
			_add_text("تطوير الموقد يفتح مساحة جديدة للبناء ويسمح بتوسيع المستوطنة تدريجياً.", 23, Color(0.85, 0.9, 1.0))
			return
		_build_empty_panel()
		return

	var d: Dictionary = GameState.DEFS[type]
	if busy:
		var verb := "قيد البناء" if lvl == 0 else "قيد الترقية"
		_add_header("%s: %s" % [verb, d["name"]])
		progress_label = _add_text("", 30, Color(1.0, 0.85, 0.5))
		var sp := Button.new()
		sp.text = "تسريع (للتجربة)"
		sp.custom_minimum_size = Vector2(0, 80)
		sp.pressed.connect(func(): GameState.speed_up(i))
		panel_box.add_child(sp)
		return

	_add_header("%s — مستوى %d" % [d["name"], lvl])
	_add_text(str(d["desc"]))
	_add_text(_info_text(type, lvl), 26, Color(0.7, 1.0, 0.85))
	if type == "research_hall":
		_add_text("مستوى دار الحكمة: %d — تتيح %d أبحاث إجمالاً" % [GameState.building_level("research_hall"), GameState.building_level("research_hall") * 3], 25, Color(0.72, 0.86, 1.0))
		var research_hall_button := Button.new()
		research_hall_button.text = "🔬 فتح شجرة الأبحاث"
		research_hall_button.custom_minimum_size.y = 84
		research_hall_button.pressed.connect(Callable(self, "show_research"))
		panel_box.add_child(research_hall_button)
	if type == "stable":
		_add_text("⚔️ راية الفرسان", 30, Color(1.0, 0.78, 0.42))
		_add_text("عدد الفرسان: %d (بلا حد إجمالي)   •   دفعة التدريب: %d   •   الفئة: %s   •   الرتبة: %s / VII   •   القوة: %d" % [GameState.cavalry_count, GameState.cavalry_capacity(), GameState.military_tier_name(GameState.cavalry_tier), ["I", "II", "III", "IV", "V", "VI", "VII"][GameState.cavalry_rank - 1], GameState.cavalry_power()], 25, Color(0.86, 0.91, 1.0))
		_add_text("نظام الرتب العسكري: 4 فئات × 7 رتب. تُفتح الفئات عند مستويات اللاعب 1 و12 و25 و30؛ جميع المباني حدّها الأقصى 3.", 23)
		var recruit := Button.new()
		recruit.text = "تجهيز فارس جديد — طعام %d، خشب 12، حديد 5" % (18 + GameState.cavalry_count * 2)
		recruit.custom_minimum_size = Vector2(0, 82)
		recruit.pressed.connect(func(): GameState.recruit_cavalry(); _rebuild_panel())
		panel_box.add_child(recruit)
		var train := Button.new()
		train.text = "ترقية الفئة / تدريب الرتبة — طعام %d، خشب %d، حديد %d" % [25 * GameState.cavalry_rank, 20 * GameState.cavalry_rank, 12 * GameState.cavalry_rank]
		train.custom_minimum_size = Vector2(0, 82)
		train.pressed.connect(func(): GameState.train_cavalry(); _rebuild_panel())
		panel_box.add_child(train)
	if type == "infantry_barracks":
		_add_text("⚔️ المشاة — العدد: %d  •  الفئة: %s  •  الرتبة: %s / VII  •  القوة: %d  •  سعة التدريب: %d" % [GameState.infantry_count, GameState.military_tier_name(GameState.infantry_tier), ["I", "II", "III", "IV", "V", "VI", "VII"][GameState.infantry_rank - 1], GameState.infantry_power(), GameState.infantry_capacity()], 25, Color(0.86, 0.91, 1.0))
		_add_text("تُفتح الفئات عند مستويات اللاعب 1 و12 و25 و30. ترقية الفئة والرتبة تؤثر في قوة جميع جنود المشاة الحاليين.", 22)
		var infantry_recruit := Button.new()
		infantry_recruit.text = "تجنيد جندي مشاة — طعام %d، خشب 8، حديد 2" % (12 + GameState.infantry_count)
		infantry_recruit.custom_minimum_size.y = 82
		infantry_recruit.pressed.connect(func(): GameState.recruit_infantry(); _rebuild_panel())
		panel_box.add_child(infantry_recruit)
		var infantry_train := Button.new()
		infantry_train.text = "ترقية الفئة / تدريب الرتبة — طعام %d، خشب %d، حديد %d" % [20 * GameState.infantry_rank, 16 * GameState.infantry_rank, 10 * GameState.infantry_rank]
		infantry_train.custom_minimum_size.y = 82
		infantry_train.pressed.connect(func(): GameState.train_infantry(); _rebuild_panel())
		panel_box.add_child(infantry_train)
	if type == "archer_barracks":
		_add_text("🏹 الرماة — العدد: %d  •  الفئة: %s  •  الرتبة: %s / VII  •  القوة: %d  •  سعة التدريب: %d" % [GameState.archer_count, GameState.military_tier_name(GameState.archer_tier), ["I", "II", "III", "IV", "V", "VI", "VII"][GameState.archer_rank - 1], GameState.archer_power(), GameState.archer_capacity()], 25, Color(0.86, 0.91, 1.0))
		_add_text("تُفتح الفئات عند مستويات اللاعب 1 و12 و25 و30. ترقية الفئة والرتبة تؤثر في قوة جميع الرماة الحاليين.", 22)
		var archer_recruit := Button.new()
		archer_recruit.text = "تجنيد رامٍ — طعام %d، خشب 10، حديد 3" % (14 + GameState.archer_count)
		archer_recruit.custom_minimum_size.y = 82
		archer_recruit.pressed.connect(func(): GameState.recruit_archer(); _rebuild_panel())
		panel_box.add_child(archer_recruit)
		var archer_train := Button.new()
		archer_train.text = "ترقية الفئة / تدريب الرتبة — طعام %d، خشب %d، حديد %d" % [22 * GameState.archer_rank, 18 * GameState.archer_rank, 12 * GameState.archer_rank]
		archer_train.custom_minimum_size.y = 82
		archer_train.pressed.connect(func(): GameState.train_archers(); _rebuild_panel())
		panel_box.add_child(archer_train)

	var sl := GameState.slots_for(type, lvl)
	if sl > 0:
		_add_text("%s: %s" % [GameState.JOBS[type], ltr("%d/%d" % [GameState.workers_of(i), sl])], 26, Color(1.0, 0.85, 0.5))

	var max_lvl := GameState.MAX_HEARTH if type == "hearth" else GameState.MAX_LEVEL_OTHER
	if lvl >= max_lvl:
		_add_text("وصل إلى أقصى مستوى", 28, Color(1.0, 0.85, 0.5))
	elif type != "hearth" and lvl + 1 > GameState.hearth_level() + 1:
		_add_text("ارفع مستوى نار الضيافة لترقية هذا المبنى", 26, Color(1.0, 0.8, 0.45))
	else:
		var cost := GameState.cost_for(type, lvl + 1)
		var b := Button.new()
		b.text = "ترقية إلى مستوى %d\n%s  •  %s" % [lvl + 1, _cost_text(cost), ltr(GameState.fmt_time(GameState.time_for(type, lvl + 1)))]
		b.custom_minimum_size = Vector2(0, 100)
		b.pressed.connect(func(): GameState.start_upgrade(i))
		panel_box.add_child(b)
		afford.append({"btn": b, "cost": cost})


func _info_text(type: String, lvl: int) -> String:
	if type == "hearth":
		return "الدفء: %s ← %s" % [ltr("+%d°" % (12 + 6 * lvl)), ltr("+%d°" % (12 + 6 * (lvl + 1)))] + "\nكل حارس نار يقلل حرق الفحم 5%"
	if type == "tent":
		return "السعة: %s ناجين" % ltr("+%d" % (lvl * 4))
	if type == "majlis":
		return "السمعة: +%d كل دقيقة" % lvl
	if type == "guard_post":
		return "تقليل خطر القوافل: %d%%" % mini(28, lvl * 7)
	if type == "stable":
		return "تقليل مدة القوافل: %d%%\nسعة الفرسان: %d فارس" % [mini(45, lvl * 12), lvl * 3]
	if type == "infirmary":
		return "إبطاء تراكم أثر البرد: %d%%" % int(round(100.0 - 100.0 / (1.0 + 0.35 * lvl)))
	var d: Dictionary = GameState.DEFS[type]
	var pr: Dictionary = d["prod"]
	for key in pr:
		var now_v := float(pr[key]) * (1.0 + 0.7 * float(lvl - 1)) * 60.0
		var next_v := float(pr[key]) * (1.0 + 0.7 * float(lvl)) * 60.0
		return "الإنتاج بكامل العمال في الدقيقة: %s ← %s" % [ltr(str(int(round(now_v)))), ltr(str(int(round(next_v))))]
	return ""


func _build_empty_panel() -> void:
	_add_header("أرض فارغة — اختر مبنى")
	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(0, 430)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 8)
	sc.add_child(list)
	for bt in GameState.BUILD_ORDER:
		var building_type := str(bt)
		var d: Dictionary = GameState.DEFS[building_type]
		var cost := GameState.cost_for(building_type, 1)
		var b := Button.new()
		var required_hearth := GameState.building_unlock_level(building_type)
		var already_built := GameState.building_level(building_type) > 0
		if already_built:
			b.text = "%s — مبني بالفعل\nيمكن بناء نسخة واحدة فقط" % d["name"]
			b.disabled = true
		elif GameState.hearth_level() < required_hearth:
			b.text = "%s — مقفل\nيتطلب نار الضيافة مستوى %d" % [d["name"], required_hearth]
			b.disabled = true
		else:
			b.text = "%s — %s\n%s  •  %s" % [d["name"], d["short"], _cost_text(cost), ltr(GameState.fmt_time(GameState.time_for(building_type, 1)))]
		b.custom_minimum_size = Vector2(0, 100)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		if not already_built and GameState.hearth_level() >= required_hearth:
			var plot_index := selected
			b.pressed.connect(func(type_to_build: String = building_type, target_plot: int = plot_index): GameState.start_build(target_plot, type_to_build); _rebuild_panel())
		list.add_child(b)
		if not already_built and GameState.hearth_level() >= required_hearth:
			afford.append({"btn": b, "cost": cost})
	panel_box.add_child(sc)


# ---------- النافذة المنبثقة: القصة والمجلس ----------

func _build_modal() -> void:
	modal_layer = Control.new()
	root.add_child(modal_layer)
	modal_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	modal_layer.mouse_filter = Control.MOUSE_FILTER_STOP
	modal_layer.visible = false
	var dim := ColorRect.new()
	modal_layer.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0.02, 0.04, 0.08, 0.75)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sheet_anchor := Control.new()
	modal_layer.add_child(sheet_anchor)
	sheet_anchor.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	sheet_anchor.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var safe_bottom := maxf(UITheme.SAFE_FALLBACK_BOTTOM, get_viewport().get_visible_rect().size.y - safe_rect.end.y)
	var mp := PanelContainer.new()
	mp.name = "FullHeightBottomSheet"
	mp.anchor_left = 0.0
	mp.anchor_right = 1.0
	mp.anchor_top = 1.0 - UITheme.SHEET_HEIGHT_RATIO
	mp.anchor_bottom = 1.0
	mp.offset_left = UITheme.SIDE_MARGIN
	mp.offset_right = -UITheme.SIDE_MARGIN
	mp.offset_top = 0.0
	mp.offset_bottom = -safe_bottom - UITheme.GAP
	mp.custom_minimum_size = Vector2(0, 700)
	mp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	mp.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sheet_anchor.add_child(mp)
	var scroll := ScrollContainer.new()
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	mp.add_child(scroll)
	modal_box = VBoxContainer.new()
	modal_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	modal_box.add_theme_constant_override("separation", 14)
	scroll.add_child(modal_box)


func _clear_modal() -> void:
	modal_afford.clear()
	for c in modal_box.get_children():
		modal_box.remove_child(c)
		c.queue_free()


func close_modal() -> void:
	if is_instance_valid(modal_layer):
		var tw := create_tween()
		tw.tween_property(modal_layer, "modulate:a", 0.0, UITheme.ANIM_SECONDS)
		tw.tween_callback(func():
			modal_layer.visible = false
			modal_layer.modulate.a = 1.0
			_clear_modal())


func _mlabel(text: String, size: int = 28, col: Color = Color(0.9, 0.94, 1.0), center: bool = false) -> Label:
	var l := Label.new()
	l.text = text
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	if center:
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	modal_box.add_child(l)
	return l


func _modal_header(title: String, col: Color = Color(1.0, 0.85, 0.5)) -> void:
	var row := HBoxContainer.new()
	var l := Label.new()
	l.text = title
	l.add_theme_font_size_override("font_size", 36)
	l.add_theme_color_override("font_color", col)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	row.add_child(l)
	var x := Button.new()
	x.text = T("close")
	x.icon = load("res://assets/ui/icons/back.svg")
	x.custom_minimum_size = Vector2(UITheme.TOUCH_MIN, UITheme.BUTTON_HEIGHT)
	x.pressed.connect(close_modal)
	row.add_child(x)
	modal_box.add_child(row)


func show_world_map() -> void:
	if is_instance_valid(world_map_transition_tween):
		world_map_transition_tween.kill()
	if is_instance_valid(world_map_screen):
		world_map_screen.queue_free()
	var screen_script = load("res://scripts/world_map_screen.gd")
	world_map_screen = Control.new()
	world_map_screen.name = "WorldMapFullScreen"
	world_map_screen.set_script(screen_script)
	world_map_screen.modulate.a = 0.0
	add_child(world_map_screen)
	# انتقال سينمائي أهدأ: تداخل بصري أطول مع تكبير طفيف بدل تبديل سريع.
	# تجهيز بيانات الخريطة يجري على دفعات بين الإطارات في world_map_canvas.gd.
	root.visible = true
	root.modulate.a = 1.0
	world_map_screen.pivot_offset = get_viewport().get_visible_rect().size * 0.5
	world_map_screen.scale = Vector2(0.965, 0.965)
	world_map_transition_tween = create_tween().set_parallel(true)
	world_map_transition_tween.set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN_OUT)
	world_map_transition_tween.tween_property(world_map_screen, "modulate:a", 1.0, 0.88)
	world_map_transition_tween.tween_property(world_map_screen, "scale", Vector2.ONE, 0.88)
	world_map_transition_tween.tween_property(root, "modulate:a", 0.0, 0.58).set_delay(0.12)
	world_map_transition_tween.chain().tween_callback(func():
		if is_instance_valid(root):
			root.visible = false
			root.modulate.a = 1.0
	)

func close_world_map() -> void:
	if is_instance_valid(world_map_transition_tween):
		world_map_transition_tween.kill()
	if not is_instance_valid(world_map_screen):
		world_map_screen = null
		root.modulate.a = 1.0
		root.visible = true
		return

	# عكس الانتقال السينمائي: إظهار المدينة تدريجياً مع تراجع خريطة المقاطعة.
	# لا نحذف شاشة الخريطة قبل انتهاء التلاشي حتى لا يحدث قطع مفاجئ.
	root.visible = true
	root.modulate.a = 0.0
	world_map_screen.pivot_offset = get_viewport().get_visible_rect().size * 0.5
	world_map_transition_tween = create_tween().set_parallel(true)
	world_map_transition_tween.set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN_OUT)
	world_map_transition_tween.tween_property(root, "modulate:a", 1.0, 0.82)
	world_map_transition_tween.tween_property(world_map_screen, "modulate:a", 0.0, 0.82)
	world_map_transition_tween.tween_property(world_map_screen, "scale", Vector2(0.965, 0.965), 0.82)
	world_map_transition_tween.chain().tween_callback(func():
		if is_instance_valid(world_map_screen):
			world_map_screen.queue_free()
		world_map_screen = null
		root.modulate.a = 1.0
		root.visible = true
	)


func _on_world_map_node_picked(node_id: String) -> void:
	var info: Dictionary = GameState.world_node_info(node_id)
	if info.is_empty():
		return
	var box: VBoxContainer = modal_box.get_node_or_null("WorldMapSelection")
	if box == null:
		return
	for child in box.get_children():
		if child.name != "WorldMapHint": child.queue_free()
	var hint: Label = box.get_node("WorldMapHint")
	var key := str(info.get("resource", "wood"))
	var ready_now := GameState.world_node_ready(node_id, selected_world_province)
	var coords := Vector2i(0, 0)
	var map_canvas: Control = modal_box.get_node_or_null("WorldMapCanvas")
	if map_canvas != null and map_canvas.has_method("get_node_info"):
		var map_info: Dictionary = map_canvas.call("get_node_info", node_id)
		coords = Vector2i(int(map_info.get("coord_x", 0)), int(map_info.get("coord_y", 0)))
	hint.text = "%s — المستوى %d\nالمقاطعة: %s\nالإحداثيات: X: %d  •  Y: %d\nالمخزون المتاح: %s %d\nزمن الرحلة ذهابًا وإيابًا: قرابة %d ثانية%s" % [str(info.get("name","موقع موارد")), int(info.get("tier",1)), str(GameState.province_name(selected_world_province)), coords.x, coords.y, str(GameState.RES_NAMES.get(key,key)), int(info.get("amount",0)), int(info.get("distance",20))*4, "\nالموقع قيد التجدد" if not ready_now else ""]
	var send := Button.new()
	send.text = "إرسال قافلة لجمع المورد والعودة تلقائيًا"
	send.custom_minimum_size = Vector2(0, 76)
	send.disabled = not ready_now or GameState.world_caravans.size() >= 3
	send.pressed.connect(func():
		GameState.send_world_caravan(node_id, selected_world_province)
		show_world_map()
	)
	box.add_child(send)


func show_intro() -> void:
	_clear_modal()
	modal_layer.visible = true
	_mlabel("حكاية موقد الصقيع", 42, Color(1.0, 0.85, 0.5), true)
	_mlabel("قيل إن الصحراء كانت تعرف دفء الشمس وكرم أهلها، حتى جاء شتاء لا يشبه الشتاء. تجمدت الكثبان، وطُمرت الواحات تحت الثلج، وتفرّق الناس في الدروب.", 28)
	_mlabel("بقي على تلّة بعيدة موقد قديم لم ينطفئ: نار الضيافة، نار الأجداد التي لا تُطفأ للغريب.", 28)
	_mlabel("أنت الآن شيخ ما تبقى من القبيلة. حولك ثلاثة تستشيرهم في المجلس: الشيخ والحكيم والفارس. أكرم الضيف تعلُ سمعتك، واسمع مجلسك يزد ولاؤهم، وحيث تُوقد نار الضيافة تعود الحياة.", 28, Color(0.8, 1.0, 0.9))
	var b := Button.new()
	b.text = "أوقد النار"
	b.custom_minimum_size = Vector2(0, 96)
	b.pressed.connect(func():
		GameState.mark_intro_seen()
		close_modal())
	modal_box.add_child(b)


func _add_tribe_tabs(active: String) -> void:
	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", UITheme.GAP)
	var definitions := [
		{"id":"survivors", "text":"tribe_survivors", "call":Callable(self,"show_survivors")},
		{"id":"council", "text":"tribe_council", "call":Callable(self,"show_majlis")},
		{"id":"aid", "text":"tribe_aid", "call":Callable(self,"show_fazaa")},
		{"id":"fame", "text":"tribe_fame", "call":Callable(self,"show_tribe_fame")}
	]
	for definition in definitions:
		var tab := Button.new()
		tab.text = T(str(definition["text"]))
		tab.custom_minimum_size = Vector2(0, UITheme.BUTTON_HEIGHT)
		tab.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		if str(definition["id"]) == active:
			tab.add_theme_color_override("font_color", UITheme.AMBER_LIGHT)
		tab.pressed.connect(definition["call"])
		tabs.add_child(tab)
	modal_box.add_child(tabs)

func show_tribe_fame() -> void:
	_clear_modal()
	modal_layer.visible = true
	_modal_header(T("tribe_fame"))
	_add_tribe_tabs("fame")
	_mlabel("السمعة: %s %s" % [GameState.fame_title(), ltr(str(GameState.fame))], UITheme.FONT_TITLE, UITheme.AMBER_LIGHT, true)
	_mlabel("تؤثر السمعة في بركة الإنتاج وتفتح مكانة القبيلة بين الجيران.", UITheme.FONT_BODY)
	_mlabel("بركة الإنتاج الحالية: %s" % ltr("+%d%%" % int(round((GameState.fame_mult() - 1.0) * 100.0))), UITheme.FONT_BODY, UITheme.SUCCESS)

func show_majlis() -> void:
	_clear_modal()
	modal_layer.visible = true
	if GameState.pending_event != "":
		_event_view()
	else:
		_status_view()


func _fx_text(fx: Dictionary) -> String:
	var parts := PackedStringArray()
	for k in GameState.RES_KEYS:
		if fx.has(k):
			parts.append("%s %s" % [GameState.RES_NAMES[k], ltr("%+d" % int(fx[k]))])
	if fx.has("fame"):
		parts.append("السمعة " + ltr("%+d" % int(fx["fame"])))
	if parts.is_empty():
		return "بلا تكلفة"
	return "، ".join(parts)


func _event_view() -> void:
	var ev: Dictionary = GameState.EVENTS[GameState.pending_event]
	var who: Dictionary = GameState.ADVISORS[ev["who"]]
	_modal_header(str(ev["title"]))
	_add_tribe_tabs("council")
	_mlabel("%s يقول:" % who["name"], 26, who["color"])
	_mlabel(str(ev["text"]), 30)
	var choices: Array = ev["choices"]
	for idx in choices.size():
		var ch: Dictionary = choices[idx]
		var fx: Dictionary = ch["fx"]
		var cost := {}
		for k in GameState.RES_KEYS:
			if float(fx.get(k, 0)) < 0.0:
				cost[k] = -float(fx[k])
		var b := Button.new()
		b.text = "%s\n%s" % [ch["text"], _fx_text(fx)]
		b.custom_minimum_size = Vector2(0, 100)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(func():
			if GameState.decide(idx):
				close_modal())
		modal_box.add_child(b)
		modal_afford.append({"btn": b, "cost": cost})
	_on_changed()


func _status_view() -> void:
	_modal_header("مجلس القبيلة")
	_add_tribe_tabs("council")
	_mlabel("لا قضايا عاجلة الآن. المجلس يراقب أحوال القبيلة.", 28)
	for a in GameState.ADVISOR_ORDER:
		var d: Dictionary = GameState.ADVISORS[a]
		var v := int(GameState.loyalty[a])
		_mlabel("%s — ولاؤه %s" % [d["role"], ltr("%d%%" % v)], 28, d["color"])
		var bar := ProgressBar.new()
		bar.min_value = 0.0
		bar.max_value = 100.0
		bar.value = float(v)
		bar.show_percentage = false
		bar.custom_minimum_size = Vector2(0, 20)
		modal_box.add_child(bar)
	var bonus := int(round((GameState.fame_mult() - 1.0) * 100.0))
	_mlabel("السمعة: %s — بركة الإنتاج %s" % [GameState.fame_title(), ltr("+%d%%" % bonus)], 28, Color(1.0, 0.85, 0.5))
	var rb := Button.new()
	rb.text = "بدء من جديد"
	rb.custom_minimum_size = Vector2(0, 80)
	rb.pressed.connect(func(): _on_reset(rb))
	modal_box.add_child(rb)
	var lm := GameState.loy_mult()
	if lm > 1.0:
		_mlabel("المجلس راضٍ: إنتاجكم يزيد 10%.", 26, Color(0.7, 1.0, 0.8))
	elif lm < 1.0:
		_mlabel("المجلس ساخط: إنتاجكم ينقص 15%. أصلح الأمر في القضايا القادمة.", 26, Color(1.0, 0.6, 0.55))


# ---------- الفزعة بين القبائل ----------

func show_fazaa() -> void:
	_clear_modal()
	modal_layer.visible = true
	_modal_header("الفزعة بين القبائل", UITheme.AMBER_LIGHT)
	_add_tribe_tabs("aid")
	_mlabel("القبيلة لا تقف وحدها في شتاء أبدي. أرسل المؤن إلى الجيران، واكسب السمعة وثقتهم. لكل قبيلة مهلة قبل طلب فزعة جديدة.", 27)
	for tribe_id in GameState.TRIBES:
		var tribe: Dictionary = GameState.TRIBES[tribe_id]
		var relation := int(GameState.tribal_relations.get(tribe_id, 0))
		_mlabel("%s — العلاقة %s" % [str(tribe["name"]), ltr("%d%%" % relation)], 27, Color(0.78, 0.9, 1.0))
		_mlabel(str(tribe["desc"]), 23, Color(0.82, 0.86, 0.92))
		var left := GameState.tribe_cooldown_left(tribe_id)
		var cost: Dictionary = tribe["cost"]
		var gift: Dictionary = tribe["gift"]
		var cost_parts := PackedStringArray()
		var gift_parts := PackedStringArray()
		for key in cost:
			cost_parts.append("%s %s" % [GameState.RES_NAMES[key], ltr(str(int(cost[key])))])
		for key in gift:
			gift_parts.append("%s +%s" % [GameState.RES_NAMES[key], ltr(str(int(gift[key])))])
		var b := Button.new()
		if left > 0.0:
			b.text = "%s — عودوا بعد %s" % [str(tribe["name"]), GameState.fmt_time(left)]
			b.disabled = true
		else:
			b.text = "إغاثة %s\nالتكلفة: %s | هدية الجيران: %s | سمعة +%d" % [str(tribe["name"]), "، ".join(cost_parts), "، ".join(gift_parts), int(tribe["fame"])]
			for key in cost:
				if float(GameState.stock.get(key, 0.0)) < float(cost[key]):
					b.disabled = true
		b.custom_minimum_size = Vector2(0, 100)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(_on_fazaa_pressed.bind(tribe_id))
		modal_box.add_child(b)
	var close_btn := Button.new()
	close_btn.text = "العودة" 
	close_btn.custom_minimum_size = Vector2(0, 78)
	close_btn.pressed.connect(close_modal)
	modal_box.add_child(close_btn)


func _on_fazaa_pressed(tribe_id: String) -> void:
	if GameState.help_tribe(tribe_id):
		show_fazaa()


# ---------- القوافل ----------

func show_research() -> void:
	_clear_modal()
	modal_layer.visible = true
	_modal_header("مركز البحوث وشجرة التطوير")
	_mlabel("اختر الأبحاث التي تناسب خطتك. كل بحث يستهلك موارداً مرة واحدة، ويفتح مزايا دائمة محفوظة. المتطلبات تظهر تحت كل تقنية.", 23, Color(0.75, 0.88, 1.0))
	var branches := ["الإعمار والإنتاج", "العتاد والفرسان", "التجارة والإمداد"]
	var branch_colors := [Color(0.66, 0.9, 0.76), Color(1.0, 0.76, 0.48), Color(0.65, 0.82, 1.0)]
	for bi in range(branches.size()):
		_mlabel("━━ %s ━━" % branches[bi], 28, branch_colors[bi], true)
		for tech_id in GameState.RESEARCHES:
			var tech: Dictionary = GameState.RESEARCHES[tech_id]
			if str(tech["branch"]) != branches[bi]:
				continue
			var status := GameState.research_status(str(tech_id))
			var done := status == "مكتملة"
			var research_ready := status == "جاهزة للبحث"
			var col: Color = Color(0.58, 1.0, 0.72) if done else (branch_colors[bi] if research_ready else Color(0.65, 0.7, 0.78))
			_mlabel(("✓ " if done else ("◆ " if research_ready else "🔒 ")) + str(tech["name"]), 26, col)
			_mlabel(str(tech["desc"]), 21, Color(0.83, 0.87, 0.93))
			var cost: Dictionary = tech["cost"]
			var cost_parts := PackedStringArray()
			for key in cost:
				cost_parts.append("%s %d" % [GameState.RES_NAMES[key], int(cost[key])])
			_mlabel("التكلفة: %s\nالحالة: %s" % ["، ".join(cost_parts), status], 20, Color(0.72, 0.8, 0.9))
			var btn := Button.new()
			btn.custom_minimum_size = Vector2(0, 70)
			btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			if done:
				btn.text = "بحث مكتمل"
				btn.disabled = true
			elif research_ready:
				btn.text = "بدء البحث"
				btn.disabled = not GameState.can_afford(cost)
				btn.pressed.connect(func(id: String = str(tech_id)): GameState.start_research(id); show_research())
			else:
				btn.text = "المتطلبات غير مكتملة"
				btn.disabled = true
			modal_box.add_child(btn)
		var sep := HSeparator.new()
		modal_box.add_child(sep)
	_mlabel("التقدم العلمي: %d / %d بحثاً" % [GameState.research_count(), GameState.RESEARCHES.size()], 24, Color(1.0, 0.84, 0.48), true)
	var close_btn := Button.new()
	close_btn.text = "العودة إلى المدينة"
	close_btn.custom_minimum_size = Vector2(0, 78)
	close_btn.pressed.connect(close_modal)
	modal_box.add_child(close_btn)


func show_missions() -> void:
	_clear_modal()
	modal_layer.visible = true
	_modal_header("مهام القبيلة وتقدّمها")
	var tabs := HBoxContainer.new(); tabs.add_theme_constant_override("separation", UITheme.GAP); modal_box.add_child(tabs)
	var missions_tab := Button.new(); missions_tab.text = "المهام"; missions_tab.size_flags_horizontal = Control.SIZE_EXPAND_FILL; missions_tab.custom_minimum_size.y = 80; missions_tab.disabled = true; tabs.add_child(missions_tab)
	var achievements_tab := Button.new(); achievements_tab.text = "الإنجازات"; achievements_tab.size_flags_horizontal = Control.SIZE_EXPAND_FILL; achievements_tab.custom_minimum_size.y = 80; achievements_tab.pressed.connect(show_achievements); tabs.add_child(achievements_tab)
	_mlabel("كل مهمة تمنحك موارد تساعدك على النجاة. تقدّمك يُحفظ تلقائياً، والمكافأة تُستلم مرة واحدة فقط.", 24, Color(0.75, 0.88, 1.0))
	var completed := 0
	for mission in GameState.MISSIONS:
		var mission_id := str(mission.get("id", ""))
		var claimed := mission_id in GameState.claimed_missions
		var done := GameState.mission_done(mission)
		var progress := GameState.mission_progress(mission)
		var target := maxi(1, int(mission.get("target", 1)))
		if done:
			completed += 1
		var card := VBoxContainer.new()
		card.add_theme_constant_override("separation", 5)
		var title_color := Color(0.58, 1.0, 0.72) if claimed else (Color(1.0, 0.84, 0.48) if done else Color(0.9, 0.94, 1.0))
		_mlabel(("✓ " if claimed else ("★ " if done else "• ")) + str(mission.get("title", "مهمة")), 28, title_color)
		_mlabel(str(mission.get("desc", "")), 22, Color(0.78, 0.84, 0.92))
		var reward: Dictionary = mission.get("reward", {})
		var reward_parts := PackedStringArray()
		for key in reward:
			reward_parts.append("%s %d" % [GameState.RES_NAMES[key], int(reward[key])])
		_mlabel("التقدّم: %d / %d     •     المكافأة: %s" % [mini(progress, target), target, "، ".join(reward_parts)], 21, Color(0.68, 0.82, 0.96))
		var claim := Button.new()
		claim.custom_minimum_size = Vector2(0, 68)
		claim.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		if claimed:
			claim.text = "تم استلام المكافأة"
			claim.disabled = true
		elif done:
			claim.text = "استلام المكافأة"
			claim.pressed.connect(func():
				GameState.claim_mission(mission_id)
				show_missions()
			)
		else:
			claim.text = "تابع التقدّم"
			claim.disabled = true
		card.add_child(claim)
		modal_box.add_child(card)
		var sep := HSeparator.new()
		modal_box.add_child(sep)
	_mlabel("أنجزت شروط %d من %d مهام" % [completed, GameState.MISSIONS.size()], 23, Color(1.0, 0.84, 0.48), true)
	var achievements_btn := Button.new()
	achievements_btn.text = "سجل الإنجازات والمكافآت الدائمة"
	achievements_btn.custom_minimum_size = Vector2(0, 78)
	achievements_btn.pressed.connect(show_achievements)
	modal_box.add_child(achievements_btn)
	var close_btn := Button.new()
	close_btn.text = "العودة إلى المدينة"
	close_btn.custom_minimum_size = Vector2(0, 78)
	close_btn.pressed.connect(close_modal)
	modal_box.add_child(close_btn)


func show_achievements() -> void:
	_clear_modal()
	modal_layer.visible = true
	_modal_header("إنجازات القبيلة")
	_mlabel("إنجازات طويلة الأمد تمنح موارد إضافية. كل مكافأة تُستلم مرة واحدة وتبقى محفوظة.", 23, Color(0.75, 0.88, 1.0))
	var completed := 0
	for achievement in GameState.ACHIEVEMENTS:
		var achievement_id := str(achievement.get("id", ""))
		var claimed := achievement_id in GameState.claimed_achievements
		var done := GameState.achievement_done(achievement)
		var progress := GameState.achievement_progress(achievement)
		var target := maxi(1, int(achievement.get("target", 1)))
		if done:
			completed += 1
		var title_color := Color(0.58, 1.0, 0.72) if claimed else (Color(1.0, 0.84, 0.48) if done else Color(0.9, 0.94, 1.0))
		_mlabel(("✓ " if claimed else ("★ " if done else "• ")) + str(achievement.get("title", "إنجاز")), 27, title_color)
		_mlabel(str(achievement.get("desc", "")), 22, Color(0.78, 0.84, 0.92))
		var reward: Dictionary = achievement.get("reward", {})
		var reward_parts := PackedStringArray()
		for key in reward:
			if GameState.RES_NAMES.has(key):
				reward_parts.append("%s %d" % [GameState.RES_NAMES[key], int(reward[key])])
		_mlabel("التقدّم: %d / %d  •  المكافأة: %s" % [mini(progress, target), target, "، ".join(reward_parts)], 21, Color(0.68, 0.82, 0.96))
		var claim := Button.new()
		claim.custom_minimum_size = Vector2(0, 68)
		claim.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		if claimed:
			claim.text = "تم استلام المكافأة"
			claim.disabled = true
		elif done:
			claim.text = "استلام مكافأة الإنجاز"
			claim.pressed.connect(func():
				GameState.claim_achievement(achievement_id)
				show_achievements())
		else:
			claim.text = "تابع التقدّم"
			claim.disabled = true
		modal_box.add_child(claim)
		modal_box.add_child(HSeparator.new())
	_mlabel("اكتملت شروط %d من %d إنجازات" % [completed, GameState.ACHIEVEMENTS.size()], 23, Color(1.0, 0.84, 0.48), true)
	var back := Button.new()
	back.text = "العودة إلى المهام"
	back.custom_minimum_size = Vector2(0, 78)
	back.pressed.connect(show_missions)
	modal_box.add_child(back)


func show_caravans() -> void:
	_clear_modal()
	modal_layer.visible = true
	_modal_header("مرسى القوافل")
	var has_yard := false
	for plot in GameState.plots:
		if str(plot.get("type", "")) == "caravan_yard" and int(plot.get("level", 0)) > 0:
			has_yard = true
			break
	if not has_yard:
		_mlabel("تحتاج أولاً إلى بناء «مرسى القوافل» من قطعة أرض فارغة. سيصبح مركز تجهيز الجمال والمؤن، ويفتح لك ثلاثة طرق تجارية مختلفة.", 30, Color(1.0, 0.85, 0.5))
		var build_tip := Button.new()
		build_tip.text = "فهمت — العودة إلى المدينة"
		build_tip.custom_minimum_size = Vector2(0, 86)
		build_tip.pressed.connect(close_modal)
		modal_box.add_child(build_tip)
		return
	_mlabel("تختار الطريق وتجهّز المؤونة والمرافقين. الطرق الأخطر تستغرق وقتاً أطول، لكنها قد تعود بغنائم أكبر.", 26)
	if GameState.caravan_end > 0.0:
		var route_name := str(GameState.CARAVAN_ROUTES.get(GameState.caravan_route, {}).get("name", "قافلة"))
		_mlabel("القافلة في طريق %s" % route_name, 32, Color(1.0, 0.85, 0.5), true)
		_mlabel("العودة المتوقعة خلال %s" % ltr(GameState.fmt_time(GameState.caravan_end - GameState.now())), 28, Color(0.75, 0.95, 1.0), true)
		_mlabel("المرافقون: %d — مؤونة الطعام: %d" % [GameState.caravan_companions, GameState.caravan_food], 25)
		var close_btn := Button.new()
		close_btn.text = "متابعة المدينة"
		close_btn.custom_minimum_size = Vector2(0, 82)
		close_btn.pressed.connect(close_modal)
		modal_box.add_child(close_btn)
		return
	var chosen := {"companions": 1}
	var team_row := HBoxContainer.new()
	var team_info := Label.new()
	team_info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	team_info.text = "المرافقون: 1"
	team_info.add_theme_font_size_override("font_size", 28)
	team_row.add_child(team_info)
	var minus := Button.new()
	minus.text = "−"
	minus.custom_minimum_size = Vector2(78, 78)
	minus.pressed.connect(func():
		chosen["companions"] = maxi(0, int(chosen["companions"]) - 1)
		team_info.text = "المرافقون: %d" % int(chosen["companions"])
	)
	team_row.add_child(minus)
	var plus := Button.new()
	plus.text = "+"
	plus.custom_minimum_size = Vector2(78, 78)
	plus.pressed.connect(func():
		chosen["companions"] = mini( mini(3, maxi(0, GameState.pop - 1)), int(chosen["companions"]) + 1)
		team_info.text = "المرافقون: %d" % int(chosen["companions"])
	)
	team_row.add_child(plus)
	modal_box.add_child(team_row)
	_mlabel("كل مرافق يزيد فرصة الغنائم، لكنه يخفض الإنتاج مؤقتاً حتى عودة القافلة.", 22, Color(0.72, 0.85, 0.96))
	for route_id in GameState.CARAVAN_ROUTES:
		var route: Dictionary = GameState.CARAVAN_ROUTES[route_id]
		var b := Button.new()
		b.text = "%s\n%s\nالمدة %s  •  مؤونة %d + 4 لكل مرافق  •  مخاطرة %d%%" % [route["name"], route["desc"], GameState.fmt_time(float(route["time"])), int(route["food"]), int(float(route["risk"]) * 100.0)]
		b.custom_minimum_size = Vector2(0, 150)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(func():
			if GameState.start_caravan(route_id, int(chosen["companions"])):
				show_caravans()
		)
		modal_box.add_child(b)
		if float(GameState.stock["food"]) < float(route["food"]):
			b.disabled = true


# ---------- القوافل ----------

# ---------- الناجون ----------

func show_survivors() -> void:
	_clear_modal()
	modal_layer.visible = true
	_modal_header("الناجون")
	_add_tribe_tabs("survivors")
	_mlabel("العدد %s — عاطلون %s. كل ناجٍ يستهلك طعاماً حتى لو لم يعمل." % [ltr("%d/%d" % [GameState.pop, GameState.pop_cap()]), ltr(str(GameState.idle()))], 26)
	var any := false
	for i in GameState.PLOT_COUNT:
		var p: Dictionary = GameState.plots[i]
		var type := str(p["type"])
		var lvl := int(p["level"])

		var sl := GameState.slots_for(type, lvl)
		if sl <= 0:
			continue
		any = true
		var idx := i
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		var info := VBoxContainer.new()
		info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		info.add_theme_constant_override("separation", -2)
		var t1 := Label.new()
		t1.text = "%s — %s" % [GameState.JOBS[type], GameState.DEFS[type]["name"]]
		t1.add_theme_font_size_override("font_size", 28)
		info.add_child(t1)
		var t2 := Label.new()
		t2.text = _job_effect(i, type)
		t2.add_theme_font_size_override("font_size", 22)
		t2.add_theme_color_override("font_color", Color(0.7, 1.0, 0.85))
		info.add_child(t2)
		row.add_child(info)
		var minus := Button.new()
		minus.text = "−"
		minus.custom_minimum_size = Vector2(88, 88)
		minus.pressed.connect(func():
			GameState.assign(idx, -1)
			show_survivors())
		row.add_child(minus)
		var cnt := Label.new()
		cnt.text = ltr("%d/%d" % [GameState.workers_of(i), sl])
		cnt.custom_minimum_size = Vector2(110, 0)
		cnt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		cnt.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		cnt.add_theme_font_size_override("font_size", 30)
		row.add_child(cnt)
		var plus := Button.new()
		plus.text = "+"
		plus.custom_minimum_size = Vector2(88, 88)
		plus.pressed.connect(func():
			GameState.assign(idx, 1)
			show_survivors())
		row.add_child(plus)
		modal_box.add_child(row)
	if not any:
		_mlabel("ابنِ مباني إنتاج لتوظّف الناجين فيها.", 28, Color(1.0, 0.8, 0.45))
	var auto := Button.new()
	auto.text = "توزيع تلقائي"
	auto.custom_minimum_size = Vector2(0, 88)
	auto.pressed.connect(func():
		GameState.auto_assign()
		show_survivors())
	modal_box.add_child(auto)


func _job_effect(i: int, type: String) -> String:
	if type == "hearth":
		return "يخفض حرق الفحم %s" % ltr("%d%%" % int(round((1.0 - GameState.keeper_factor()) * 100.0)))
	var pr: Dictionary = GameState.DEFS[type]["prod"]
	for key in pr:
		var per_min := GameState.plot_rate(i, key) * 60.0
		return "%s %s في الدقيقة" % [GameState.RES_NAMES[key], ltr("+%.1f" % per_min)]
	return ""
