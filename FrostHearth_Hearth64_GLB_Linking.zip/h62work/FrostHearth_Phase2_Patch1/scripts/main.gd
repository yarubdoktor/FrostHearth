extends Node3D
## العالم ثلاثي الأبعاد: البيئة، الجبال، الأشجار، الكاميرا، قطع الأرض والمباني.
## كل المجسمات هنا مصنوعة بالكود (أشكال أولية) وتُستبدل لاحقاً بنماذج GLB.

const PLOT_RADIUS := 10.5
const PICK_RADIUS := 4.6
const G := 0.12 # ارتفاع سطح الأساس

# ربط نماذج GLB بأنواع المباني (Hearth64).
# fit   = أكبر بُعد أفقي مستهدف بوحدات العالم (0 = بدون تحجيم).
# max_h = أقصى ارتفاع مسموح (0 = بدون حد).
# أي نوع غير موجود هنا (أو فشل تحميل نموذجه) يبقى على المجسم الإجرائي الاحتياطي.
const GLB_MODELS := {
	"hearth": {"path": "res://assets/models/royal_hearth.glb", "fit": 0.0, "max_h": 0.0},
	"woodcutter": {"path": "res://assets/models/timber_storehouse.glb", "fit": 0.0, "max_h": 0.0},
	"lodge": {"path": "res://assets/models/arabian_winter_lodge.glb", "fit": 0.0, "max_h": 0.0},
	"ironmine": {"path": "res://assets/models/resources/iron_mine_winter_premium.glb", "fit": 4.4, "max_h": 3.5},
	"infirmary": {"path": "res://assets/models/buildings/frosthaven_healer_hall_premium.glb", "fit": 4.6, "max_h": 5.0},
	"stable": {"path": "res://assets/models/buildings/frostmane_cavalry_barracks_premium.glb", "fit": 4.6, "max_h": 4.5},
	"infantry_barracks": {"path": "res://assets/models/buildings/frostguard_barracks_premium.glb", "fit": 5.0, "max_h": 5.0},
	"guard_post": {"path": "res://assets/models/buildings/frostwatch_defense_tower_premium.glb", "fit": 3.8, "max_h": 6.5},
	"caravan_yard": {"path": "res://assets/models/buildings/frostroad_caravan_exchange_premium.glb", "fit": 5.2, "max_h": 5.0},
	"majlis": {"path": "res://assets/models/buildings/frostclan_council_hall_premium.glb", "fit": 5.0, "max_h": 6.0},
}

static var _glb_bounds_cache: Dictionary = {}
static var _glb_vertex_color_material: StandardMaterial3D = null
# إعدادات القصور الذاتي لسحب المدينة: الاحتكاك الأعلى يعني انزلاقاً أقصر.
const CITY_INERTIA_FRICTION: float = 4.2 # احتكاك زمني مناسب لانزلاق 0.6–1 ثانية
const CITY_INERTIA_MIN_VELOCITY: float = 0.35 # أقل سرعة بالعالم/ثانية لبدء الانزلاق
const CITY_INERTIA_MAX_VELOCITY: float = 32.0 # الحد الأقصى لسرعة الكاميرا بالعالم/ثانية
const CITY_INERTIA_VELOCITY_WINDOW: float = 0.10 # نافذة عينات آخر ~100ms
const CITY_INERTIA_STOP_VELOCITY: float = 0.08 # سرعة الإيقاف النهائي
const CITY_INERTIA_STALE_INPUT: float = 0.08 # توقف الإصبع أكثر من 80ms يلغي الانزلاق

var cam: Camera3D
var pivot: Node3D
var zoom := 30.0
var env: Environment
var sun: DirectionalLight3D
var snow: GPUParticles3D
var snow_root: Node3D
var snow_mat: ParticleProcessMaterial
var font: SystemFont
var ui
var ring: MeshInstance3D

var plot_nodes: Array = []
var plot_content: Array = []
var plot_labels: Array = []
var plot_sig: Array = []
var plot_pos: Array = []

var fire_light: OmniLight3D = null
var fire_mesh: MeshInstance3D = null

# طبقة صوتية خفيفة مصممة خصيصاً للعبة، مع مزج ديناميكي للطقس.
var wind_player: AudioStreamPlayer
var storm_player: AudioStreamPlayer
var hearth_player: AudioStreamPlayer
var cue_player: AudioStreamPlayer
var audio_muted := false

var touches := {}
var touch_start := {}
var ignored := {}
var multi := false
var moved_far := false
var pinch_prev := 0.0
var t_acc := 0.0
var storm_f := 0.0
var city_inertia_velocity: Vector2 = Vector2.ZERO # سرعة العالم على محوري X/Z بوحدة العالم/ثانية
var city_drag_samples: Array[Dictionary] = [] # عينات {pos, time} خلال آخر 100ms
var city_last_drag_sample_time: float = 0.0


func _ready() -> void:
	font = SystemFont.new()
	font.font_names = PackedStringArray(["Noto Sans Arabic", "Noto Naskh Arabic", "Droid Arabic Naskh", "Cairo", "Tajawal", "Arial", "Tahoma", "sans-serif"])
	font.allow_system_fallback = true

	_build_environment()
	_build_ground()
	_build_winter_ground_accents()
	_build_scenery()
	_build_frozen_lake()
	_build_world_details()
	_build_premium_details()
	_build_camera()
	_build_snow()
	_build_plots()
	_build_audio()

	ui = load("res://scripts/ui.gd").new()
	add_child(ui)
	ui.panel_closed.connect(_on_panel_closed)
	ui.audio_toggled.connect(_set_audio_muted)
	GameState.toast.connect(_play_ui_cue)
	GameState.structure_changed.connect(_refresh_plots)
	GameState.changed.connect(_update_labels)
	_refresh_plots()


# ---------- الصوت والهوية السمعية ----------

func _loop_audio(path: String, level_db: float) -> AudioStreamPlayer:
	var player := AudioStreamPlayer.new()
	var stream := load(path) as AudioStreamWAV
	if stream != null:
		stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
		player.stream = stream
	player.volume_db = level_db
	player.bus = "Master"
	add_child(player)
	if stream != null:
		player.play()
	return player


func _build_audio() -> void:
	# الأصوات ملفات محلية صغيرة، ولا تحتاج اتصالاً بالإنترنت.
	wind_player = _loop_audio("res://audio/winter_wind.wav", -22.0)
	storm_player = _loop_audio("res://audio/blizzard_wind.wav", -30.0)
	hearth_player = _loop_audio("res://audio/hearth_fire.wav", -29.0)
	cue_player = AudioStreamPlayer.new()
	cue_player.volume_db = -12.0
	add_child(cue_player)


func _set_audio_muted(muted: bool) -> void:
	audio_muted = muted
	for player in [wind_player, storm_player, hearth_player, cue_player]:
		if is_instance_valid(player):
			player.volume_db = -80.0 if muted else ( -22.0 if player == wind_player else (-30.0 if player == storm_player else (-29.0 if player == hearth_player else -12.0)))


func _play_ui_cue(_msg: String, bad: bool = false) -> void:
	if audio_muted or not is_instance_valid(cue_player):
		return
	var path := "res://audio/ui_alert.wav" if bad else "res://audio/ui_confirm.wav"
	var stream := load(path) as AudioStreamWAV
	if stream != null:
		cue_player.stream = stream
		cue_player.play()


# ---------- مساعدات المجسمات ----------

func _mat(c: Color, emit: float = 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.85
	if emit > 0.0:
		m.emission_enabled = true
		m.emission = c
		m.emission_energy_multiplier = emit
	return m


func _part(parent: Node3D, mesh: Mesh, col: Color, pos: Vector3, rot: Vector3 = Vector3.ZERO, scl: Vector3 = Vector3.ONE, emit: float = 0.0) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = _mat(col, emit)
	mi.position = pos
	mi.rotation_degrees = rot
	mi.scale = scl
	parent.add_child(mi)
	return mi


func _add_glb_for_type(parent: Node3D, type: String) -> bool:
	if not GLB_MODELS.has(type):
		return false
	var e: Dictionary = GLB_MODELS[type]
	return _add_glb_model(parent, str(e["path"]), float(e["fit"]), float(e["max_h"]))


func _add_glb_model(parent: Node3D, path: String, fit: float = 0.0, max_h: float = 0.0) -> bool:
	# GLB models are optional fallbacks: if import/load fails, the original procedural building remains available.
	if not ResourceLoader.exists(path):
		return false
	var packed := load(path) as PackedScene
	if packed == null:
		return false
	var model := packed.instantiate() as Node3D
	if model == null:
		return false
	model.name = "PremiumGLBModel"
	_fix_glb_materials(model)
	var info := glb_fit_info(model, path, fit, max_h)
	model.scale = Vector3.ONE * float(info["scale"])
	model.position = info["position"]
	parent.add_child(model)
	return true


## يحسب التحجيم والموضع: قاعدة النموذج على سطح الأساس (y = G) ومركزه الأفقي عند الصفر.
## static ليُستخدم من الاختبارات دون إنشاء المشهد كاملاً.
static func glb_fit_info(model: Node3D, path: String, fit: float, max_h: float) -> Dictionary:
	var bb: AABB
	if _glb_bounds_cache.has(path):
		bb = _glb_bounds_cache[path]
	else:
		var acc: Array = []
		_collect_glb_bounds(model, model.transform.affine_inverse(), acc)
		bb = acc[0] if not acc.is_empty() else AABB(Vector3(-1, 0, -1), Vector3(2, 2, 2))
		_glb_bounds_cache[path] = bb
	var s := 1.0
	if fit > 0.0:
		var foot := maxf(bb.size.x, bb.size.z)
		if foot > 0.001:
			s = fit / foot
	if max_h > 0.0 and bb.size.y * s > max_h and bb.size.y > 0.001:
		s = max_h / bb.size.y
	s = clampf(s, 0.25, 2.0)
	var c := bb.get_center()
	return {
		"scale": s,
		"position": Vector3(-c.x * s, G - bb.position.y * s, -c.z * s),
		"size": bb.size * s,
		"bounds": bb,
	}


static func _collect_glb_bounds(node: Node, xf: Transform3D, acc: Array) -> void:
	var t := xf
	if node is Node3D:
		t = xf * (node as Node3D).transform
	if node is MeshInstance3D:
		var mi := node as MeshInstance3D
		if mi.mesh != null:
			var bb: AABB = t * mi.get_aabb()
			if acc.is_empty():
				acc.append(bb)
			else:
				acc[0] = (acc[0] as AABB).merge(bb)
	for c in node.get_children():
		_collect_glb_bounds(c, t, acc)


## بعض النماذج (محجر الحجر، الغذاء، قطع السور) بلا خامات وتعتمد على ألوان الرؤوس فقط.
static func _fix_glb_materials(node: Node) -> void:
	if node is MeshInstance3D:
		var mi := node as MeshInstance3D
		if mi.mesh != null:
			for i in mi.mesh.get_surface_count():
				if mi.mesh.surface_get_material(i) == null and mi.get_surface_override_material(i) == null:
					mi.set_surface_override_material(i, _get_glb_vertex_color_material())
	for c in node.get_children():
		_fix_glb_materials(c)


static func _get_glb_vertex_color_material() -> StandardMaterial3D:
	if _glb_vertex_color_material == null:
		var m := StandardMaterial3D.new()
		m.vertex_color_use_as_albedo = true
		m.roughness = 0.85
		_glb_vertex_color_material = m
	return _glb_vertex_color_material


func _box(s: Vector3) -> BoxMesh:
	var m := BoxMesh.new()
	m.size = s
	return m


func _cyl(rt: float, rb: float, h: float, seg: int = 16) -> CylinderMesh:
	var m := CylinderMesh.new()
	m.top_radius = rt
	m.bottom_radius = rb
	m.height = h
	m.radial_segments = seg
	m.rings = 1
	return m


func _dome(r: float) -> SphereMesh:
	# نصف كرة: قاعدتها عند y=0 وقمتها عند y=r
	var m := SphereMesh.new()
	m.radius = r
	m.height = r
	m.is_hemisphere = true
	m.radial_segments = 24
	m.rings = 12
	return m


func _sphere(r: float) -> SphereMesh:
	var m := SphereMesh.new()
	m.radius = r
	m.height = r * 2.0
	m.radial_segments = 16
	m.rings = 8
	return m


# ---------- البيئة ----------

func _build_environment() -> void:
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var psm := ProceduralSkyMaterial.new()
	psm.sky_top_color = Color(0.075, 0.12, 0.23)
	psm.sky_horizon_color = Color(0.78, 0.43, 0.31)
	psm.ground_horizon_color = Color(0.39, 0.43, 0.53)
	psm.ground_bottom_color = Color(0.67, 0.72, 0.82)
	psm.sky_energy_multiplier = 1.0
	psm.ground_curve = 0.18
	psm.sky_curve = 0.18
	sky.sky_material = psm
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.9
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.adjustment_enabled = true
	env.adjustment_brightness = 1.02
	env.adjustment_contrast = 1.08
	env.adjustment_saturation = 1.08
	env.fog_enabled = true
	env.fog_light_color = Color(0.72, 0.8, 0.9)
	env.fog_density = 0.0065
	env.glow_enabled = true
	env.glow_intensity = 0.72
	env.glow_strength = 1.05
	env.glow_bloom = 0.08
	env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SOFTLIGHT
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-28, -32, 0)
	sun.light_color = Color(1.0, 0.72, 0.56)
	sun.light_energy = 1.05
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 85.0
	sun.shadow_bias = 0.035
	sun.shadow_normal_bias = 1.5
	add_child(sun)


func _build_ground() -> void:
	var pm := PlaneMesh.new()
	pm.size = Vector2(400, 400)
	var mi := MeshInstance3D.new()
	mi.mesh = pm
	var snow_ground := _mat(Color(0.78, 0.85, 0.94))
	snow_ground.roughness = 0.74
	snow_ground.metallic = 0.035
	snow_ground.metallic_specular = 0.42
	mi.material_override = snow_ground
	add_child(mi)


# طبقة تضاريس ثلجية منخفضة حول القرية: تكسر فراغ الأرض المسطحة دون تغيير مسارات اللعب.
func _build_winter_ground_accents() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 6102026
	# رقع جليد مزرقة شبه شفافة بصرياً (خامة صلبة خافتة لتناسب أجهزة الهاتف).
	for i in range(18):
		var angle := rng.randf_range(0.0, TAU)
		var radius := rng.randf_range(64.0, 112.0)
		var width := rng.randf_range(4.0, 9.0)
		var depth := rng.randf_range(2.5, 6.0)
		var patch := _part(self, _dome(1.0), Color(0.64, 0.78, 0.91) if i % 3 == 0 else Color(0.79, 0.87, 0.95), Vector3(cos(angle) * radius, -0.035, sin(angle) * radius), Vector3(0, rad_to_deg(angle) + rng.randf_range(-30.0, 30.0), 0), Vector3(width, 0.035, depth))
		patch.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	# حواف انجرافات ثلجية ناعمة على أطراف المنطقة، موزعة ببذرة ثابتة.
	for i in range(22):
		var angle := TAU * float(i) / 22.0 + rng.randf_range(-0.09, 0.09)
		var radius := rng.randf_range(91.0, 119.0)
		var width := rng.randf_range(3.0, 7.0)
		var height := rng.randf_range(0.25, 0.7)
		var drift := _part(self, _dome(width), Color(0.88, 0.93, 0.99) if i % 3 else Color(0.77, 0.85, 0.94), Vector3(cos(angle) * radius, -0.06, sin(angle) * radius), Vector3(0, rad_to_deg(angle), 0), Vector3(1.0, height / width, rng.randf_range(0.55, 1.15)))
		drift.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF


func _scatter(mesh: Mesh, col: Color, xs: Array) -> void:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.instance_count = xs.size()
	mm.mesh = mesh
	for i in xs.size():
		mm.set_instance_transform(i, xs[i])
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	mmi.material_override = _mat(col)
	add_child(mmi)


func _build_scenery() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 11

	# أشجار صنوبر مغطاة بالثلج
	var trunks := []
	var cones := []
	var caps := []
	for i in 120:
		var a := rng.randf() * TAU
		var r := rng.randf_range(19.0, 70.0)
		var pos := Vector3(cos(a) * r, 0.0, sin(a) * r)
		# Leave a clear shoreline around the frozen lake.
		if Vector2(pos.x + 62.0, pos.z + 56.0).length() < 16.5:
			continue
		var s := rng.randf_range(0.8, 1.7)
		var b := Basis().scaled(Vector3(s, s, s))
		trunks.append(Transform3D(b, pos + Vector3(0, 0.7 * s, 0)))
		cones.append(Transform3D(b, pos + Vector3(0, 2.9 * s, 0)))
		caps.append(Transform3D(b, pos + Vector3(0, 4.0 * s, 0)))
	_scatter(_cyl(0.25, 0.3, 1.4, 6), Color(0.3, 0.2, 0.13), trunks)
	_scatter(_cyl(0.0, 1.5, 3.6, 7), Color(0.12, 0.3, 0.24), cones)
	_scatter(_cyl(0.0, 0.64, 1.4, 7), Color(0.96, 0.98, 1.0), caps)

	# تلال ثلجية
	for i in 36:
		var a2 := rng.randf() * TAU
		var r2 := rng.randf_range(20.0, 80.0)
		var rad := rng.randf_range(5.0, 12.0)
		var mound := _dome(rad)
		_part(self, mound, Color(0.9, 0.94, 1.0), Vector3(cos(a2) * r2, -0.2, sin(a2) * r2), Vector3.ZERO, Vector3(1, 0.22, 1))

	# جبال بعيدة
	for i in 16:
		var a3 := float(i) * TAU / 16.0 + rng.randf() * 0.2
		var r3 := rng.randf_range(95.0, 125.0)
		var h := rng.randf_range(28.0, 55.0)
		var w := h * rng.randf_range(0.7, 1.0)
		var rot := Vector3(0, rng.randf() * 60.0, 0)
		var px := cos(a3) * r3
		var pz := sin(a3) * r3
		_part(self, _cyl(0.0, w, h, 6), Color(0.42, 0.5, 0.62), Vector3(px, h * 0.5 - 1.0, pz), rot)
		var ch := h * 0.35
		_part(self, _cyl(0.0, w * 0.35 * 1.05, ch, 6), Color(0.97, 0.98, 1.0), Vector3(px, h - 1.0 - ch * 0.5, pz), rot)


# بحيرة متجمدة بعيدة عن مركز البناء؛ مع ضفاف ثلجية وشقوق جليدية خفيفة.
# عنصر بصري فقط: لا يغيّر الحركة أو اقتصاد الموارد أو انتقال الخرائط.
func _build_frozen_lake() -> void:
	var center := Vector3(-62.0, 0.0, -56.0)
	var bank := _part(self, _cyl(15.8, 16.6, 0.24, 48), Color(0.78, 0.85, 0.93), center + Vector3(0, -0.12, 0), Vector3.ZERO, Vector3(1.08, 1.0, 0.82))
	bank.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var ice := _part(self, _cyl(13.7, 14.4, 0.12, 64), Color(0.48, 0.69, 0.83), center + Vector3(0, 0.025, 0), Vector3.ZERO, Vector3(1.08, 1.0, 0.82))
	ice.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	# طبقة مركزية فاتحة تعطي انكساراً لونياً من دون خامات شفافة مكلفة.
	var sheen := _part(self, _cyl(9.2, 10.1, 0.035, 48), Color(0.69, 0.83, 0.92), center + Vector3(-1.0, 0.105, -0.4), Vector3.ZERO, Vector3(1.08, 1.0, 0.78))
	sheen.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var rng := RandomNumberGenerator.new()
	rng.seed = 610622
	# شقوق فاتحة رفيعة موزعة فوق سطح الجليد.
	for i in range(9):
		var a := rng.randf_range(0.0, TAU)
		var r := rng.randf_range(2.0, 9.5)
		var crack_pos := center + Vector3(cos(a) * r, 0.135, sin(a) * r * 0.78)
		var crack := _part(self, _box(Vector3(rng.randf_range(1.5, 4.0), 0.018, 0.045)), Color(0.82, 0.93, 0.98), crack_pos, Vector3(0, rng.randf_range(-45.0, 45.0), 0))
		crack.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	# صخور منخفضة على الضفة، مع إبقاء خط الشاطئ مقروءاً من الكاميرا البعيدة.
	for i in range(14):
		var a2 := TAU * float(i) / 14.0 + rng.randf_range(-0.12, 0.12)
		var r2 := rng.randf_range(14.6, 16.4)
		var rock := _part(self, _dome(rng.randf_range(0.55, 1.15)), Color(0.55, 0.63, 0.73) if i % 3 == 0 else Color(0.87, 0.92, 0.98), center + Vector3(cos(a2) * r2, -0.03, sin(a2) * r2 * 0.82), Vector3(0, rng.randf_range(0.0, 360.0), 0), Vector3(1.0, 0.32, 0.85))
		rock.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF


# ---------- تفاصيل العالم: طرق، فوانيس، أعلام وصخور جليدية ----------

func _build_world_details() -> void:
	# طريق حجري مدفون جزئياً بالثلج يصل إلى كل قطعة بناء.
	for i in range(1, GameState.PLOT_COUNT):
		var target: Vector3 = Vector3.ZERO
		var a := deg_to_rad(22.5 + float((i - 1) % 8) * 45.0)
		var route_radius: float = PLOT_RADIUS - 2.0 if i <= 8 else (PLOT_RADIUS + 6.0 if i <= 12 else PLOT_RADIUS + 15.0)
		target = Vector3(cos(a) * route_radius, 0.0, sin(a) * route_radius)
		var direction := target.normalized()
		var angle_y := rad_to_deg(atan2(direction.x, direction.z))
		var steps := int(target.length() / 1.35)
		for j in range(2, steps):
			var p := direction * (float(j) * 1.35)
			var slab := _part(self, _box(Vector3(1.35, 0.16, 0.88)), Color(0.38, 0.42, 0.49), Vector3(p.x, 0.045, p.z), Vector3(0, angle_y, 0))
			slab.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			if j % 2 == 0:
				_part(self, _box(Vector3(0.9, 0.045, 0.5)), Color(0.88, 0.92, 0.98), Vector3(p.x, 0.14, p.z), Vector3(0, angle_y, 0))

	# إطار حجري رفيع حول كل منصة، ليعطي إحساساً بمخيم مبني وليس قطعاً طافية.
	for i in range(GameState.PLOT_COUNT):
		var p := Vector3.ZERO
		if i > 0 and i <= 8:
			p = Vector3(cos(deg_to_rad(22.5 + float(i - 1) * 45.0)) * PLOT_RADIUS, 0.0, sin(deg_to_rad(22.5 + float(i - 1) * 45.0)) * PLOT_RADIUS)
		elif i > 8:
			p = Vector3(cos(deg_to_rad(45.0 + float(i - 9) * 90.0)) * (PLOT_RADIUS + 8.0), 0.0, sin(deg_to_rad(45.0 + float(i - 9) * 90.0)) * (PLOT_RADIUS + 8.0))
		var tor := TorusMesh.new()
		tor.inner_radius = 3.34 if i != 0 else 3.78
		tor.outer_radius = 3.48 if i != 0 else 3.92
		tor.rings = 8
		tor.ring_segments = 36
		_part(self, tor, Color(0.54, 0.59, 0.68), p + Vector3(0, 0.02, 0))

	# فوانيس طريق منخفضة: خامة مضيئة بدلاً من عدد كبير من الأضواء الحقيقية حفاظاً على أداء الهاتف.
	for i: int in range(GameState.PLOT_COUNT):
		var a: float = deg_to_rad(22.5 + float(i) * 45.0)
		var dir: Vector3 = Vector3(cos(a), 0.0, sin(a))
		for side_value: float in [-1.0, 1.0]:
			var side_vec: Vector3 = Vector3(-float(dir.z), 0.0, float(dir.x)) * side_value
			var lp: Vector3 = (dir * 7.0) + (side_vec * 2.6)
			_part(self, _cyl(0.12, 0.17, 1.35, 8), Color(0.22, 0.17, 0.15), lp + Vector3(0, 0.68, 0))
			_part(self, _sphere(0.25), Color(1.0, 0.58, 0.23), lp + Vector3(0, 1.48, 0), Vector3.ZERO, Vector3.ONE, 2.2)
			_part(self, _cyl(0.34, 0.34, 0.12, 10), Color(0.25, 0.2, 0.18), lp + Vector3(0, 1.75, 0))

	# أعلام قبيلة بلون خمري ونحاسي عند المدخل؛ تفاصيل بسيطة مقروءة من الكاميرا البعيدة.
	for side_value: float in [-1.0, 1.0]:
		var x: float = float(side_value) * 5.8
		var z: float = 10.8
		_part(self, _cyl(0.09, 0.12, 4.2, 8), Color(0.34, 0.24, 0.16), Vector3(x, 2.1, z))
		_part(self, _box(Vector3(1.15, 0.82, 0.08)), Color(0.38, 0.075, 0.075), Vector3(x + side_value * 0.52, 3.35, z), Vector3(0, side_value * 8.0, -4.0))
		_part(self, _box(Vector3(0.82, 0.08, 0.1)), Color(0.83, 0.61, 0.29), Vector3(x + side_value * 0.52, 3.35, z - 0.05), Vector3(0, side_value * 8.0, -4.0))

	# نتوءات جليدية صغيرة وصخور داكنة تكسر المساحات البيضاء، مع توزيع ثابت بين مرات التشغيل.
	var rng := RandomNumberGenerator.new()
	rng.seed = 20261024
	for i in range(46):
		var angle := rng.randf_range(0.0, TAU)
		var radius := rng.randf_range(25.0, 58.0)
		var size := rng.randf_range(0.55, 1.7)
		var pos := Vector3(cos(angle) * radius, 0.0, sin(angle) * radius)
		var rock_color := Color(0.49, 0.55, 0.65) if i % 3 == 0 else Color(0.76, 0.82, 0.91)
		_part(self, _dome(size), rock_color, pos + Vector3(0, -0.12, 0), Vector3(0, rng.randf_range(0, 360), 0), Vector3(1.0, rng.randf_range(0.25, 0.62), rng.randf_range(0.7, 1.3)))
		if i % 4 == 0:
			_part(self, _cyl(0.0, size * 0.42, size * 1.8, 5), Color(0.77, 0.88, 0.97), pos + Vector3(size * 0.3, size * 0.42, size * 0.2), Vector3(0, rng.randf_range(0, 360), rng.randf_range(-8, 8)))


# ---------- ترقية بصرية سينمائية للقرية ----------

func _build_premium_details() -> void:
	# طبقات ثلجية منخفضة حول ساحة المركز لتكسر السطح المسطح وتلتقط ضوء النار.
	var rng := RandomNumberGenerator.new()
	rng.seed = 42061024
	for i in range(24):
		var a := TAU * float(i) / 24.0
		var r := rng.randf_range(5.1, 7.0)
		var sx := rng.randf_range(1.0, 2.3)
		var sz := rng.randf_range(0.65, 1.35)
		var drift := _part(self, _dome(rng.randf_range(0.55, 1.05)), Color(0.72, 0.81, 0.92), Vector3(cos(a) * r, -0.08, sin(a) * r), Vector3(0, rad_to_deg(a), 0), Vector3(sx, 0.18, sz))
		drift.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

	# أحجار رصف أكبر متباينة اللون على المدخل الرئيسي.
	for j in range(9):
		var z := 12.0 + float(j) * 1.45
		for side in [-1.0, 1.0]:
			var stone_col := Color(0.38, 0.44, 0.54) if j % 3 == 0 else Color(0.55, 0.61, 0.7)
			var stone := _part(self, _box(Vector3(1.05, 0.13, 1.05)), stone_col, Vector3(side * (1.25 + float(j % 2) * 0.12), 0.035, z), Vector3(0, float(j % 2) * 7.0, 0))
			stone.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

	# أوتاد قبلية مزخرفة بحلقات نحاسية وفوانيس دافئة؛ خامات مضيئة بدل أضواء كثيرة.
	for i in range(8):
		var a := TAU * float(i) / 8.0 + deg_to_rad(22.5)
		var pos := Vector3(cos(a) * 16.5, 0.0, sin(a) * 16.5)
		if pos.length() < 14.0:
			continue
		_part(self, _cyl(0.12, 0.18, 2.2, 8), Color(0.28, 0.19, 0.13), pos + Vector3(0, 1.1, 0))
		_part(self, _cyl(0.2, 0.2, 0.09, 12), Color(0.79, 0.52, 0.25), pos + Vector3(0, 1.55, 0))
		_part(self, _sphere(0.22), Color(1.0, 0.49, 0.18), pos + Vector3(0, 1.83, 0), Vector3.ZERO, Vector3.ONE, 2.4)
		_part(self, _cyl(0.3, 0.3, 0.09, 10), Color(0.2, 0.17, 0.16), pos + Vector3(0, 2.08, 0))

	# شظايا جليدية شفافة اللون عند أطراف القرية لإضافة عمق بصري، مع عدد محدود من المضلعات.
	for i in range(20):
		var a2 := rng.randf_range(0.0, TAU)
		var r2 := rng.randf_range(29.0, 48.0)
		var h := rng.randf_range(1.0, 3.8)
		var w := rng.randf_range(0.28, 0.7)
		var pos2 := Vector3(cos(a2) * r2, h * 0.5 - 0.1, sin(a2) * r2)
		var crystal := _part(self, _cyl(0.0, w, h, 5), Color(0.58, 0.76, 0.91), pos2, Vector3(0, rng.randf_range(0.0, 360.0), rng.randf_range(-8.0, 8.0)))
		crystal.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

	# ألواح جليد رقيقة متفرقة على الأرض؛ انعكاس ناعم من دون مؤثرات ثقيلة على الهاتف.
	for i in range(12):
		var a3 := rng.randf_range(0.0, TAU)
		var r3 := rng.randf_range(22.0, 42.0)
		var patch := _part(self, _dome(rng.randf_range(1.4, 2.6)), Color(0.66, 0.78, 0.91), Vector3(cos(a3) * r3, -0.16, sin(a3) * r3), Vector3(0, rng.randf_range(0.0, 360.0), 0), Vector3(1.5, 0.035, 0.85))
		patch.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF


# ---------- الكاميرا والثلج ----------

func _build_camera() -> void:
	pivot = Node3D.new()
	pivot.rotation_degrees = Vector3(-52, 25, 0)
	add_child(pivot)
	cam = Camera3D.new()
	cam.fov = 50.0
	cam.far = 400.0
	cam.position = Vector3(0, 0, zoom)
	pivot.add_child(cam)
	cam.current = true

	var tm := TorusMesh.new()
	tm.inner_radius = 3.6
	tm.outer_radius = 3.9
	ring = _part(self, tm, Color(1.0, 0.8, 0.3), Vector3.ZERO, Vector3.ZERO, Vector3.ONE, 1.5)
	ring.visible = false


func _build_snow() -> void:
	snow_root = Node3D.new()
	add_child(snow_root)
	snow = GPUParticles3D.new()
	snow.amount = 1450
	snow.lifetime = 5.5
	snow.preprocess = 5.5
	snow.visibility_aabb = AABB(Vector3(-40, -25, -40), Vector3(80, 30, 80))
	snow.position = Vector3(0, 14, 0)
	snow_mat = ParticleProcessMaterial.new()
	snow_mat.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	snow_mat.emission_box_extents = Vector3(28, 0.5, 28)
	snow_mat.direction = Vector3(0.15, -1.0, 0.1)
	snow_mat.spread = 12.0
	snow_mat.initial_velocity_min = 2.0
	snow_mat.initial_velocity_max = 3.5
	snow_mat.gravity = Vector3(0, -0.5, 0)
	snow_mat.scale_min = 0.6
	snow_mat.scale_max = 1.4
	snow.process_material = snow_mat
	var q := SphereMesh.new()
	q.radius = 0.045
	q.height = 0.09
	q.radial_segments = 6
	q.rings = 3
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = Color(1, 1, 1, 0.9)
	q.material = m
	snow.draw_pass_1 = q
	snow.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	snow_root.add_child(snow)


# ---------- قطع الأرض والمباني ----------

func _build_plots() -> void:
	for i in GameState.PLOT_COUNT:
		var pos := Vector3.ZERO
		if i > 0 and i <= 8:
			var a := deg_to_rad(22.5 + float(i - 1) * 45.0)
			pos = Vector3(cos(a) * PLOT_RADIUS, 0.0, sin(a) * PLOT_RADIUS)
		elif i > 8 and i <= 12:
			var a2 := deg_to_rad(45.0 + float(i - 9) * 90.0)
			pos = Vector3(cos(a2) * (PLOT_RADIUS + 8.0), 0.0, sin(a2) * (PLOT_RADIUS + 8.0))
		elif i > 12:
			# حلقة ثالثة من ثماني قطع لتوفير مساحة للمباني العسكرية الجديدة.
			var a3 := deg_to_rad(22.5 + float(i - 13) * 45.0)
			pos = Vector3(cos(a3) * (PLOT_RADIUS + 17.0), 0.0, sin(a3) * (PLOT_RADIUS + 17.0))
		plot_pos.append(pos)
		var n := Node3D.new()
		n.position = pos
		add_child(n)
		var fs := 1.15 if i == 0 else 1.0
		_part(n, _cyl(3.3, 3.5, 0.24, 32), Color(0.62, 0.66, 0.74), Vector3.ZERO, Vector3.ZERO, Vector3(fs, 1, fs))
		var content := Node3D.new()
		n.add_child(content)
		var lab := Label3D.new()
		lab.font = font
		lab.font_size = 56
		lab.outline_size = 14
		lab.pixel_size = 0.012
		lab.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		lab.no_depth_test = true
		lab.modulate = Color(1, 1, 1)
		lab.outline_modulate = Color(0.05, 0.1, 0.2)
		n.add_child(lab)
		plot_nodes.append(n)
		plot_content.append(content)
		plot_labels.append(lab)
		plot_sig.append("")


func _refresh_plots() -> void:
	for i in plot_nodes.size():
		var p: Dictionary = GameState.plots[i]
		var sig := "%s_%d_%d" % [p["type"], int(p["level"]), int(p["to"])]
		if sig == plot_sig[i]:
			continue
		plot_sig[i] = sig
		var content: Node3D = plot_content[i]
		for c in content.get_children():
			content.remove_child(c)
			c.queue_free()
		_build_content(content, p)
		if i == 0:
			fire_light = content.find_child("Fire", true, false) as OmniLight3D
			fire_mesh = content.find_child("FireMesh", true, false) as MeshInstance3D
	_update_labels()


func _build_content(content: Node3D, p: Dictionary) -> void:
	var type: String = p["type"]
	var lvl := int(p["level"])
	var busy := float(p["end"]) > 0.0
	if type != "" and lvl > 0:
		_make_building(content, type, lvl)
	if busy:
		_make_scaffold(content, lvl == 0)


func _make_building(parent: Node3D, type: String, lvl: int) -> void:
	var b := Node3D.new()
	# حجم ثابت لجميع المباني؛ الترقية لا تكبّر المجسم ولا تسبب تداخل المباني.
	b.scale = Vector3.ONE
	parent.add_child(b)
	var g := G
	# Hearth64: أنواع المباني المربوطة بنموذج GLB تُبنى منه مباشرة؛ الفشل يعيدها للمجسم الإجرائي.
	if type != "hearth" and type != "woodcutter" and type != "lodge" and _add_glb_for_type(b, type):
		return
	match type:
		"hearth":
			if _add_glb_for_type(b, "hearth"):
				# Keep the fire animated and lit by the existing gameplay light system.
				var fh := 2.0 + 0.15 * float(lvl)
				var fire := _part(b, _cyl(0.0, 1.0, fh, 10), Color(1.0, 0.5, 0.12), Vector3(0, g + 1.0 + fh * 0.5, 0), Vector3.ZERO, Vector3.ONE, 3.0)
				fire.name = "FireMesh"
				_part(b, _cyl(0.0, 0.55, fh * 0.7, 10), Color(1.0, 0.85, 0.3), Vector3(0, g + 1.0 + fh * 0.35, 0), Vector3.ZERO, Vector3.ONE, 4.0)
				var light := OmniLight3D.new()
				light.name = "Fire"
				light.light_color = Color(1.0, 0.6, 0.28)
				light.light_energy = 3.4
				light.omni_range = 20.0
				light.position = Vector3(0, g + 2.2, 0)
				b.add_child(light)
			else:
				# قاعدة الموقد متعددة الطبقات مع حافة نحاسية محفورة بصرياً.
				_part(b, _cyl(2.1, 2.5, 0.8, 32), Color(0.43, 0.47, 0.54), Vector3(0, g + 0.4, 0))
				_part(b, _cyl(2.16, 2.2, 0.12, 32), Color(0.72, 0.53, 0.28), Vector3(0, g + 0.82, 0))
				_part(b, _cyl(1.7, 1.9, 0.25, 32), Color(0.16, 0.17, 0.2), Vector3(0, g + 0.9, 0))
				# حلقة حجارة داكنة حول النار وجذوع وقود مرئية من الكاميرا.
				var hearth_ring := TorusMesh.new()
				hearth_ring.inner_radius = 2.45
				hearth_ring.outer_radius = 2.62
				hearth_ring.rings = 10
				hearth_ring.ring_segments = 36
				_part(b, hearth_ring, Color(0.31, 0.34, 0.4), Vector3(0, g + 0.08, 0))
				for log_i in range(6):
					var log_a: float = TAU * float(log_i) / 6.0
					var log_p := Vector3(cos(log_a) * 1.18, g + 1.05, sin(log_a) * 1.18)
					_part(b, _cyl(0.12, 0.15, 1.45, 8), Color(0.25, 0.14, 0.08), log_p, Vector3(0, -rad_to_deg(log_a), 78))
				var fh := 2.0 + 0.15 * float(lvl)
				var fire := _part(b, _cyl(0.0, 1.0, fh, 10), Color(1.0, 0.5, 0.12), Vector3(0, g + 1.0 + fh * 0.5, 0), Vector3.ZERO, Vector3.ONE, 3.0)
				fire.name = "FireMesh"
				_part(b, _cyl(0.0, 0.55, fh * 0.7, 10), Color(1.0, 0.85, 0.3), Vector3(0, g + 1.0 + fh * 0.35, 0), Vector3.ZERO, Vector3.ONE, 4.0)
				var ph := 2.3 + 0.1 * float(lvl)
				for k in 4:
					var a := deg_to_rad(45.0 + 90.0 * float(k))
					var px := cos(a) * 2.9
					var pz := sin(a) * 2.9
					_part(b, _cyl(0.2, 0.26, ph, 12), Color(0.86, 0.76, 0.58), Vector3(px, g + ph * 0.5, pz))
					_part(b, _dome(0.6), Color(0.08, 0.45, 0.55), Vector3(px, g + ph, pz))
					_part(b, _sphere(0.12), Color(0.95, 0.78, 0.25), Vector3(px, g + ph + 0.65, pz), Vector3.ZERO, Vector3.ONE, 0.8)
				# دلّة القهوة: رمز الضيافة
				_part(b, _cyl(0.22, 0.34, 0.5, 14), Color(0.85, 0.65, 0.2), Vector3(1.25, g + 1.275, 0.4))
				_part(b, _cyl(0.1, 0.12, 0.25, 12), Color(0.85, 0.65, 0.2), Vector3(1.25, g + 1.65, 0.4))
				_part(b, _sphere(0.12), Color(0.95, 0.78, 0.25), Vector3(1.25, g + 1.8, 0.4), Vector3.ZERO, Vector3.ONE, 0.6)
				_part(b, _cyl(0.03, 0.07, 0.55, 8), Color(0.85, 0.65, 0.2), Vector3(1.6, g + 1.45, 0.4), Vector3(0, 0, -50))
				var light := OmniLight3D.new()
				light.name = "Fire"
				light.light_color = Color(1.0, 0.6, 0.28)
				light.light_energy = 3.4
				light.omni_range = 20.0
				light.position = Vector3(0, g + 2.2, 0)
				b.add_child(light)
		"tent":
			var h := 2.0 + 0.1 * float(lvl)
			_part(b, _cyl(0.0, 2.4, h, 10), Color(0.28, 0.21, 0.17), Vector3(0, g + h * 0.5, 0))
			var ch := 0.8
			_part(b, _cyl(0.0, 2.4 * ch / h * 1.06, ch, 10), Color(0.95, 0.97, 1.0), Vector3(0, g + h - ch * 0.5, 0))
			_part(b, _sphere(0.14), Color(0.95, 0.78, 0.25), Vector3(0, g + h + 0.05, 0), Vector3.ZERO, Vector3.ONE, 0.6)
			_part(b, _box(Vector3(0.9, 1.2, 0.3)), Color(0.1, 0.08, 0.07), Vector3(0, g + 0.6, 1.7))
			_part(b, _box(Vector3(1.05, 0.12, 0.18)), Color(0.72, 0.54, 0.32), Vector3(0, g + 1.25, 1.86))
			for rope_side in [-1.0, 1.0]:
				_part(b, _cyl(0.035, 0.035, 2.5, 6), Color(0.63, 0.49, 0.35), Vector3(rope_side * 1.8, g + 0.85, 1.95), Vector3(0, 0, rope_side * 34.0))
		"woodcutter":
			if not _add_glb_for_type(b, "woodcutter"):
				_part(b, _box(Vector3(3.0, 1.6, 3.0)), Color(0.55, 0.4, 0.27), Vector3(0, g + 0.8, 0))
				_part(b, _cyl(0.0, 2.7, 1.3, 4), Color(0.4, 0.27, 0.18), Vector3(0, g + 1.6 + 0.65, 0), Vector3(0, 45, 0))
				_part(b, _cyl(0.0, 1.1, 0.5, 4), Color(0.95, 0.97, 1.0), Vector3(0, g + 2.9 - 0.25, 0), Vector3(0, 45, 0))
				_part(b, _box(Vector3(0.9, 1.1, 0.12)), Color(0.15, 0.1, 0.07), Vector3(0, g + 0.55, 1.52))
				_part(b, _cyl(0.28, 0.28, 2.2, 10), Color(0.5, 0.33, 0.18), Vector3(-2.3, g + 0.28, 0.0), Vector3(90, 0, 0))
				_part(b, _cyl(0.28, 0.28, 2.2, 10), Color(0.5, 0.33, 0.18), Vector3(-2.85, g + 0.28, 0.0), Vector3(90, 0, 0))
				_part(b, _cyl(0.28, 0.28, 2.2, 10), Color(0.5, 0.33, 0.18), Vector3(-2.58, g + 0.75, 0.0), Vector3(90, 0, 0))
				# ألواح خشبية متقاطعة على الواجهة وعوارض سقف واضحة.
				_part(b, _box(Vector3(3.15, 0.14, 0.16)), Color(0.31, 0.19, 0.11), Vector3(0, g + 1.55, 1.57))
				_part(b, _box(Vector3(0.14, 1.35, 0.16)), Color(0.31, 0.19, 0.11), Vector3(-1.25, g + 0.95, 1.57))
				_part(b, _box(Vector3(0.14, 1.35, 0.16)), Color(0.31, 0.19, 0.11), Vector3(1.25, g + 0.95, 1.57))
				for pile_i in range(3):
					_part(b, _cyl(0.19, 0.19, 1.1, 10), Color(0.63, 0.43, 0.25), Vector3(-2.65 + float(pile_i) * 0.42, g + 0.22, -1.55), Vector3(90, 0, 0))
		"coalmine":
			_part(b, _dome(2.5), Color(0.2, 0.2, 0.23), Vector3(0, g, 0), Vector3.ZERO, Vector3(1, 0.7, 1))
			_part(b, _dome(1.2), Color(0.95, 0.97, 1.0), Vector3(0.4, g + 1.55, -0.5), Vector3.ZERO, Vector3(1, 0.35, 1))
			_part(b, _box(Vector3(1.2, 1.1, 0.2)), Color(0.02, 0.02, 0.03), Vector3(0, g + 0.55, 2.15))
			_part(b, _cyl(0.18, 0.2, 1.4, 8), Color(0.5, 0.33, 0.18), Vector3(-0.8, g + 0.7, 2.3))
			_part(b, _cyl(0.18, 0.2, 1.4, 8), Color(0.5, 0.33, 0.18), Vector3(0.8, g + 0.7, 2.3))
			_part(b, _box(Vector3(2.1, 0.25, 0.35)), Color(0.5, 0.33, 0.18), Vector3(0, g + 1.45, 2.3))
			_part(b, _sphere(0.5), Color(0.05, 0.05, 0.06), Vector3(-2.6, g + 0.3, 1.4))
			_part(b, _sphere(0.4), Color(0.05, 0.05, 0.06), Vector3(-2.1, g + 0.25, 2.0))
			_part(b, _sphere(0.35), Color(0.05, 0.05, 0.06), Vector3(-2.9, g + 0.25, 0.7))
		"lodge":
			if not _add_glb_for_type(b, "lodge"):
				_part(b, _box(Vector3(3.4, 1.7, 3.4)), Color(0.8, 0.7, 0.52), Vector3(0, g + 0.85, 0))
				_part(b, _dome(1.9), Color(0.08, 0.45, 0.55), Vector3(0, g + 1.7, 0))
				_part(b, _sphere(0.14), Color(0.95, 0.78, 0.25), Vector3(0, g + 1.7 + 1.95, 0), Vector3.ZERO, Vector3.ONE, 0.6)
				_part(b, _cyl(0.18, 0.22, 3.0, 10), Color(0.86, 0.76, 0.58), Vector3(1.5, g + 1.5, 1.5))
				_part(b, _dome(0.3), Color(0.08, 0.45, 0.55), Vector3(1.5, g + 3.0, 1.5))
				_part(b, _box(Vector3(0.9, 1.1, 0.12)), Color(0.12, 0.08, 0.06), Vector3(0, g + 0.55, 1.72))
				# نوافذ دافئة بإطارات خشبية لتظهر الحياة داخل المبنى.
				for wx in [-1.05, 1.05]:
					_part(b, _box(Vector3(0.62, 0.62, 0.10)), Color(0.24, 0.13, 0.08), Vector3(wx, g + 1.0, 1.76))
					_part(b, _box(Vector3(0.42, 0.42, 0.06)), Color(1.0, 0.57, 0.22), Vector3(wx, g + 1.0, 1.69), Vector3.ZERO, Vector3.ONE, 1.3)
		"ironmine":
			_part(b, _dome(2.3), Color(0.36, 0.4, 0.48), Vector3(0, g, 0), Vector3.ZERO, Vector3(1, 0.6, 1))
			_part(b, _box(Vector3(0.5, 1.4, 0.5)), Color(0.55, 0.72, 0.9), Vector3(1.0, g + 1.0, -0.8), Vector3(10, 20, 15), Vector3.ONE, 0.4)
			_part(b, _box(Vector3(0.4, 1.1, 0.4)), Color(0.55, 0.72, 0.9), Vector3(-0.6, g + 1.0, -1.0), Vector3(-12, 40, -10), Vector3.ONE, 0.4)
			_part(b, _box(Vector3(0.1, 0.1, 2.4)), Color(0.3, 0.3, 0.33), Vector3(-0.4, g + 0.1, 2.5))
			_part(b, _box(Vector3(0.1, 0.1, 2.4)), Color(0.3, 0.3, 0.33), Vector3(0.4, g + 0.1, 2.5))
			_part(b, _box(Vector3(0.9, 0.5, 0.7)), Color(0.25, 0.27, 0.32), Vector3(0, g + 0.45, 3.0))
			_part(b, _sphere(0.28), Color(0.75, 0.82, 0.9), Vector3(0.1, g + 0.8, 3.0))
		"majlis":
			# مجلس قبلي دائري مفتوح مع أعمدة خشبية وسقف قماشي مزخرف.
			_part(b, _cyl(2.5, 2.7, 0.28, 20), Color(0.43, 0.45, 0.48), Vector3(0, g + 0.14, 0))
			_part(b, _cyl(2.1, 2.25, 0.12, 20), Color(0.63, 0.43, 0.24), Vector3(0, g + 0.34, 0))
			for k in range(8):
				var a := TAU * float(k) / 8.0
				var pp := Vector3(cos(a) * 2.05, g + 1.25, sin(a) * 2.05)
				_part(b, _cyl(0.09, 0.12, 2.2, 8), Color(0.34, 0.2, 0.12), pp)
				_part(b, _sphere(0.12), Color(0.78, 0.58, 0.3), Vector3(pp.x, pp.y + 1.15, pp.z), Vector3.ZERO, Vector3.ONE, 0.15)
			_part(b, _cyl(0.0, 2.55, 0.7, 12), Color(0.35, 0.18, 0.14), Vector3(0, g + 2.55, 0))
			_part(b, _cyl(0.0, 1.05, 0.12, 12), Color(0.72, 0.53, 0.3), Vector3(0, g + 2.92, 0))
			for k in range(6):
				var a := TAU * float(k) / 6.0
				_part(b, _box(Vector3(0.85, 0.38, 0.52)), Color(0.42, 0.24, 0.14), Vector3(cos(a) * 1.35, g + 0.48, sin(a) * 1.35), Vector3(0, -rad_to_deg(a), 0))
		"guard_post":
			# برج مراقبة على قوائم متقاطعة مع منصة وحاجز علوي.
			_part(b, _box(Vector3(2.8, 0.25, 2.8)), Color(0.36, 0.24, 0.15), Vector3(0, g + 2.35, 0))
			for sx in [-1.0, 1.0]:
				for sz in [-1.0, 1.0]:
					_part(b, _box(Vector3(0.2, 4.6, 0.2)), Color(0.35, 0.22, 0.13), Vector3(sx * 1.05, g + 2.3, sz * 1.05), Vector3(0, 0, sx * sz * 7.0))
			for yy in [3.0, 3.55]:
				_part(b, _box(Vector3(3.0, 0.15, 0.15)), Color(0.55, 0.37, 0.2), Vector3(0, g + yy, 1.35))
				_part(b, _box(Vector3(3.0, 0.15, 0.15)), Color(0.55, 0.37, 0.2), Vector3(0, g + yy, -1.35))
				_part(b, _box(Vector3(0.15, 0.15, 2.7)), Color(0.55, 0.37, 0.2), Vector3(1.35, g + yy, 0))
				_part(b, _box(Vector3(0.15, 0.15, 2.7)), Color(0.55, 0.37, 0.2), Vector3(-1.35, g + yy, 0))
			_part(b, _cyl(0.0, 2.0, 0.8, 4), Color(0.4, 0.26, 0.16), Vector3(0, g + 4.35, 0), Vector3(0, 45, 0))
			_part(b, _cyl(0.0, 0.7, 0.45, 4), Color(0.95, 0.96, 1.0), Vector3(0, g + 4.95, 0), Vector3(0, 45, 0))
		"stable":
			# إسطبل خشبي مع ثلاث فتحات ومخازن علف.
			_part(b, _box(Vector3(4.1, 2.3, 3.2)), Color(0.42, 0.29, 0.18), Vector3(0, g + 1.15, 0))
			_part(b, _cyl(0.0, 2.8, 1.35, 4), Color(0.31, 0.2, 0.13), Vector3(0, g + 2.55, 0), Vector3(0, 45, 0))
			_part(b, _cyl(0.0, 1.2, 0.45, 4), Color(0.93, 0.95, 0.98), Vector3(0, g + 3.35, 0), Vector3(0, 45, 0))
			for k in range(3):
				var xx := -1.25 + float(k) * 1.25
				_part(b, _box(Vector3(0.86, 1.25, 0.12)), Color(0.18, 0.11, 0.07), Vector3(xx, g + 0.72, 1.66))
				_part(b, _box(Vector3(0.9, 0.12, 0.16)), Color(0.72, 0.5, 0.28), Vector3(xx, g + 1.38, 1.72))
			for sx in [-1.0, 1.0]:
				_part(b, _cyl(0.18, 0.18, 0.75, 10), Color(0.58, 0.39, 0.22), Vector3(sx * 2.25, g + 0.38, -1.1), Vector3(90, 0, 0))
		"infirmary":
			# مضافة الحكيم: بناء حجري صغير مع سقف وقبة وفانوس دافئ.
			_part(b, _box(Vector3(3.6, 2.0, 3.2)), Color(0.58, 0.56, 0.52), Vector3(0, g + 1.0, 0))
			_part(b, _box(Vector3(3.9, 0.18, 3.5)), Color(0.37, 0.26, 0.18), Vector3(0, g + 2.05, 0))
			_part(b, _dome(1.65), Color(0.12, 0.39, 0.47), Vector3(0, g + 2.45, 0), Vector3.ZERO, Vector3(1.0, 0.58, 1.0))
			_part(b, _sphere(0.12), Color(0.95, 0.75, 0.28), Vector3(0, g + 3.45, 0), Vector3.ZERO, Vector3.ONE, 0.8)
			_part(b, _box(Vector3(0.82, 1.25, 0.12)), Color(0.19, 0.12, 0.08), Vector3(0, g + 0.62, 1.67))
			for wx in [-1.1, 1.1]:
				_part(b, _box(Vector3(0.55, 0.55, 0.12)), Color(0.31, 0.2, 0.13), Vector3(wx, g + 1.1, 1.68))
				_part(b, _box(Vector3(0.36, 0.36, 0.06)), Color(1.0, 0.56, 0.22), Vector3(wx, g + 1.1, 1.61), Vector3.ZERO, Vector3.ONE, 1.0)
		"research_hall":
			# دار الحكمة: مبنى حجري واضح بقبة زرقاء، أعمدة، ومدخل مضاء.
			_part(b, _box(Vector3(3.8, 2.0, 3.4)), Color(0.58, 0.54, 0.45), Vector3(0, g + 1.0, 0))
			_part(b, _box(Vector3(4.0, 0.18, 3.6)), Color(0.32, 0.24, 0.17), Vector3(0, g + 2.05, 0))
			_part(b, _dome(1.8), Color(0.08, 0.34, 0.48), Vector3(0, g + 2.45, 0), Vector3.ZERO, Vector3(1.0, 0.72, 1.0))
			_part(b, _cyl(0.08, 0.12, 0.7, 10), Color(0.78, 0.61, 0.31), Vector3(0, g + 4.0, 0))
			_part(b, _sphere(0.15), Color(1.0, 0.78, 0.32), Vector3(0, g + 4.4, 0), Vector3.ZERO, Vector3.ONE, 0.9)
			_part(b, _box(Vector3(0.85, 1.25, 0.12)), Color(0.15, 0.1, 0.07), Vector3(0, g + 0.62, 1.77))
			for wx in [-1.25, 1.25]:
				_part(b, _cyl(0.13, 0.16, 2.1, 10), Color(0.77, 0.67, 0.48), Vector3(wx, g + 1.05, 1.78))
				_part(b, _box(Vector3(0.55, 0.62, 0.08)), Color(0.2, 0.64, 0.78), Vector3(wx, g + 1.2, 1.77), Vector3.ZERO, Vector3.ONE, 0.45)
		"infantry_barracks":
			# ثكنة مشاة خشبية ذات بوابة تدريب وسياج وأهداف تدريب.
			_part(b, _box(Vector3(3.8, 1.9, 3.2)), Color(0.42, 0.28, 0.17), Vector3(0, g + 0.95, 0))
			_part(b, _cyl(0.0, 2.55, 1.25, 4), Color(0.29, 0.18, 0.12), Vector3(0, g + 2.25, 0), Vector3(0, 45, 0))
			_part(b, _cyl(0.0, 1.05, 0.32, 4), Color(0.88, 0.91, 0.92), Vector3(0, g + 2.98, 0), Vector3(0, 45, 0))
			_part(b, _box(Vector3(1.0, 1.3, 0.14)), Color(0.12, 0.09, 0.07), Vector3(0, g + 0.65, 1.66))
			for sx in [-1.0, 1.0]:
				_part(b, _box(Vector3(0.14, 1.3, 0.14)), Color(0.7, 0.5, 0.27), Vector3(sx * 1.45, g + 0.65, 1.78))
				_part(b, _cyl(0.07, 0.07, 1.8, 8), Color(0.7, 0.55, 0.34), Vector3(sx * 2.25, g + 0.9, -0.4), Vector3(0, 0, 8.0))
				_part(b, _sphere(0.22), Color(0.72, 0.25, 0.16), Vector3(sx * 2.25, g + 1.85, -0.4))
		"archer_barracks":
			# ثكنة الرماة بسقف قماشي أخضر وأهداف دائرية مرئية.
			_part(b, _box(Vector3(3.5, 1.75, 3.0)), Color(0.5, 0.37, 0.22), Vector3(0, g + 0.88, 0))
			_part(b, _cyl(0.0, 2.35, 1.15, 4), Color(0.16, 0.32, 0.24), Vector3(0, g + 2.15, 0), Vector3(0, 45, 0))
			_part(b, _cyl(0.0, 0.95, 0.3, 4), Color(0.91, 0.9, 0.79), Vector3(0, g + 2.8, 0), Vector3(0, 45, 0))
			_part(b, _box(Vector3(0.82, 1.15, 0.12)), Color(0.16, 0.1, 0.07), Vector3(0, g + 0.58, 1.56))
			for tx in [-1.7, 1.7]:
				_part(b, _cyl(0.08, 0.08, 2.3, 8), Color(0.45, 0.28, 0.15), Vector3(tx, g + 1.15, -1.55))
				_part(b, _cyl(0.58, 0.58, 0.12, 20), Color(0.83, 0.73, 0.53), Vector3(tx, g + 1.7, -1.55), Vector3(90, 0, 0))
				_part(b, _cyl(0.38, 0.38, 0.14, 20), Color(0.69, 0.22, 0.17), Vector3(tx, g + 1.7, -1.63), Vector3(90, 0, 0))
				_part(b, _cyl(0.17, 0.17, 0.16, 20), Color(0.95, 0.83, 0.48), Vector3(tx, g + 1.7, -1.72), Vector3(90, 0, 0))
		"caravan_yard":
			# مرسى قوافل صحراوي: بوابة خشبية، مظلة سميكة، أكياس مؤن وصناديق.
			_part(b, _box(Vector3(4.8, 0.28, 4.2)), Color(0.34, 0.25, 0.18), Vector3(0, g + 0.14, 0))
			for sx in [-1.0, 1.0]:
				for sz in [-1.0, 1.0]:
					_part(b, _cyl(0.13, 0.17, 3.6, 10), Color(0.36, 0.23, 0.14), Vector3(sx * 2.0, g + 1.8, sz * 1.65))
			_part(b, _box(Vector3(4.7, 0.22, 3.9)), Color(0.56, 0.38, 0.24), Vector3(0, g + 3.55, 0))
			_part(b, _box(Vector3(4.2, 0.12, 3.4)), Color(0.72, 0.57, 0.37), Vector3(0, g + 3.72, 0))
			for j in 3:
				_part(b, _box(Vector3(0.95, 0.85, 0.8)), Color(0.48, 0.31, 0.18), Vector3(-1.1 + float(j) * 1.05, g + 0.7, 2.15))
				_part(b, _box(Vector3(0.99, 0.12, 0.84)), Color(0.82, 0.67, 0.43), Vector3(-1.1 + float(j) * 1.05, g + 1.16, 2.15))
			_part(b, _cyl(0.38, 0.38, 0.65, 12), Color(0.32, 0.23, 0.16), Vector3(-2.7, g + 0.48, -1.8), Vector3(90, 0, 0))
			_part(b, _cyl(0.38, 0.38, 0.65, 12), Color(0.32, 0.23, 0.16), Vector3(-1.8, g + 0.48, -1.8), Vector3(90, 0, 0))


func _make_scaffold(parent: Node3D, is_new: bool) -> void:
	var s := Node3D.new()
	parent.add_child(s)
	var wood := Color(0.55, 0.4, 0.25)
	for sx in [-1.0, 1.0]:
		for sz in [-1.0, 1.0]:
			_part(s, _box(Vector3(0.18, 3.0, 0.18)), wood, Vector3(sx * 2.2, G + 1.5, sz * 2.2))
	for yy in [1.0, 2.2]:
		for sgn in [-1.0, 1.0]:
			_part(s, _box(Vector3(4.4, 0.14, 0.14)), wood, Vector3(0, G + yy, sgn * 2.2))
			_part(s, _box(Vector3(0.14, 0.14, 4.4)), wood, Vector3(sgn * 2.2, G + yy, 0))
	if is_new:
		_part(s, _box(Vector3(1.2, 0.9, 1.2)), Color(0.5, 0.36, 0.22), Vector3(-0.6, G + 0.45, 0.4))
		_part(s, _box(Vector3(0.9, 0.7, 0.9)), Color(0.45, 0.32, 0.2), Vector3(0.7, G + 0.35, -0.5), Vector3(0, 25, 0))
		_part(s, _box(Vector3(2.0, 0.1, 0.5)), wood, Vector3(0.2, G + 1.0, 1.4), Vector3(0, 15, 8))


func _update_labels() -> void:
	for i in plot_labels.size():
		var p: Dictionary = GameState.plots[i]
		var lab: Label3D = plot_labels[i]
		var txt := ""
		var y := 4.2
		if p["type"] == "":
			if not GameState.is_plot_unlocked(i):
				txt = "مقفلة\nموقد %d" % GameState.plot_unlock_level(i)
				y = 2.8
			else:
				txt = "+"
				y = 1.8
		else:
			var nm: String = GameState.DEFS[p["type"]]["name"]
			var lv := int(p["level"])
			txt = nm if lv == 0 else "%s (%d)" % [nm, lv]
			if p["type"] == "hearth":
				y = 5.4
			elif p["type"] == "tent":
				y = 3.9
			if float(p["end"]) > 0.0:
				txt += "\n" + GameState.fmt_time(float(p["end"]) - GameState.now())
				y = maxf(y, 4.4)
		lab.text = txt
		lab.position = Vector3(0, y, 0)


# ---------- التحديث كل إطار ----------

func _process(delta: float) -> void:
	t_acc += delta
	var storm := GameState.is_storm()
	storm_f = move_toward(storm_f, 1.0 if storm else 0.0, delta * 0.5)
	if not audio_muted:
		if is_instance_valid(wind_player):
			wind_player.volume_db = lerpf(-22.0, -37.0, storm_f)
		if is_instance_valid(storm_player):
			storm_player.volume_db = lerpf(-34.0, -23.0, storm_f)
	env.fog_density = lerpf(0.008, 0.028, storm_f)
	env.ambient_light_energy = lerpf(0.9, 0.55, storm_f)
	sun.light_energy = lerpf(1.15, 0.45, storm_f)
	snow.speed_scale = lerpf(1.0, 2.2, storm_f)
	snow_mat.direction = Vector3(lerpf(0.15, 1.1, storm_f), -1.0, 0.1)
	snow_root.position = Vector3(pivot.position.x, 0.0, pivot.position.z)
	cam.position.z = lerpf(cam.position.z, zoom, 0.2)
	_update_city_inertia(delta)

	if is_instance_valid(fire_light):
		var lit := 1.0 if float(GameState.stock["coal"]) > 0.0 else 0.15
		fire_light.light_energy = (3.0 + sin(t_acc * 9.0) * 0.35 + sin(t_acc * 23.0) * 0.2) * lit
	if is_instance_valid(fire_mesh):
		var lit2 := 1.0 if float(GameState.stock["coal"]) > 0.0 else 0.25
		fire_mesh.scale = Vector3(1.0, (1.0 + 0.08 * sin(t_acc * 11.0)) * lit2, 1.0)


# ---------- اللمس ----------

func _pinch_dist() -> float:
	var pts := touches.values()
	if pts.size() < 2:
		return 0.0
	return (pts[0] as Vector2).distance_to(pts[1] as Vector2)


func _clamp_pivot() -> void:
	var flat := Vector2(pivot.position.x, pivot.position.z)
	if flat.length() > 28.0:
		flat = flat.normalized() * 28.0
	pivot.position = Vector3(flat.x, 0.0, flat.y)


func _pan_world_delta(rel: Vector2) -> Vector2:
	# نفس تحويل _pan الأصلي، بما فيه معامل الاتجاه 1.25 وعلاقته بمستوى zoom.
	var vh := get_viewport().get_visible_rect().size.y
	var s := zoom * 2.0 * tan(deg_to_rad(cam.fov * 0.5)) / vh
	var right := pivot.global_transform.basis.x
	right.y = 0.0
	right = right.normalized()
	var fwd := -pivot.global_transform.basis.z
	fwd.y = 0.0
	fwd = fwd.normalized()
	var world_delta: Vector3 = (-right * rel.x + fwd * rel.y * 1.25) * s
	return Vector2(world_delta.x, world_delta.z)


func _pan(rel: Vector2) -> void:
	pivot.position += Vector3(_pan_world_delta(rel).x, 0.0, _pan_world_delta(rel).y)
	_clamp_pivot()


func _clear_city_drag_samples(pos: Vector2) -> void:
	city_drag_samples.clear()
	var now: float = float(Time.get_ticks_msec()) / 1000.0
	city_drag_samples.append({"pos": pos, "time": now})
	city_last_drag_sample_time = now


func _record_city_drag_sample(pos: Vector2) -> void:
	var now: float = float(Time.get_ticks_msec()) / 1000.0
	if not city_drag_samples.is_empty() and pos.distance_to(city_drag_samples[-1]["pos"] as Vector2) < 0.15:
		return
	city_drag_samples.append({"pos": pos, "time": now})
	city_last_drag_sample_time = now
	while city_drag_samples.size() > 2 and now - float(city_drag_samples[0]["time"]) > CITY_INERTIA_VELOCITY_WINDOW:
		city_drag_samples.pop_front()


func _start_city_inertia() -> void:
	city_inertia_velocity = Vector2.ZERO
	if city_drag_samples.size() < 2:
		return
	var now: float = float(Time.get_ticks_msec()) / 1000.0
	var last: Dictionary = city_drag_samples[-1]
	if now - float(last["time"]) > CITY_INERTIA_STALE_INPUT:
		return
	var first: Dictionary = city_drag_samples[0]
	var elapsed: float = float(last["time"]) - float(first["time"])
	if elapsed <= 0.001:
		return
	var screen_delta: Vector2 = (last["pos"] as Vector2) - (first["pos"] as Vector2)
	city_inertia_velocity = _pan_world_delta(screen_delta) / elapsed
	if city_inertia_velocity.length() > CITY_INERTIA_MAX_VELOCITY:
		city_inertia_velocity = city_inertia_velocity.normalized() * CITY_INERTIA_MAX_VELOCITY
	if city_inertia_velocity.length() < CITY_INERTIA_MIN_VELOCITY:
		city_inertia_velocity = Vector2.ZERO


func _cancel_city_inertia() -> void:
	city_inertia_velocity = Vector2.ZERO
	city_drag_samples.clear()


func _update_city_inertia(delta: float) -> void:
	if city_inertia_velocity.length() < CITY_INERTIA_STOP_VELOCITY:
		city_inertia_velocity = Vector2.ZERO
		return
	var before: Vector2 = Vector2(pivot.position.x, pivot.position.z)
	var proposed: Vector2 = before + city_inertia_velocity * delta
	pivot.position = Vector3(proposed.x, 0.0, proposed.y)
	_clamp_pivot()
	var after: Vector2 = Vector2(pivot.position.x, pivot.position.z)
	if not after.is_equal_approx(proposed):
		# عند اصطدام حد نصف القطر، أزل فقط مركبة السرعة المتجهة إلى الخارج.
		var normal: Vector2 = after.normalized()
		var outward: float = city_inertia_velocity.dot(normal)
		if outward > 0.0:
			city_inertia_velocity -= normal * outward
	city_inertia_velocity *= exp(-CITY_INERTIA_FRICTION * delta)
	if city_inertia_velocity.length() < CITY_INERTIA_STOP_VELOCITY:
		city_inertia_velocity = Vector2.ZERO


func _input(e: InputEvent) -> void:
	# يوقف الانزلاق قبل أن تستهلك الواجهة الحدث، بما في ذلك فتح أي نافذة.
	if e is InputEventScreenTouch and e.pressed:
		_cancel_city_inertia()
	elif e is InputEventMouseButton and e.pressed and e.button_index == MOUSE_BUTTON_LEFT:
		_cancel_city_inertia()


func _unhandled_input(e: InputEvent) -> void:
	if e is InputEventScreenTouch:
		var idx: int = e.index
		if e.pressed:
			_cancel_city_inertia() # أي لمسة جديدة، حتى على الواجهة، توقف الانزلاق
			ignored.erase(idx)
			if ui.is_over_ui(e.position):
				ignored[idx] = true
				return
			touches[idx] = e.position
			touch_start[idx] = {"pos": e.position, "t": Time.get_ticks_msec()}
			if touches.size() == 1:
				multi = false
				moved_far = false
				_clear_city_drag_samples(e.position)
			else:
				multi = true
				_cancel_city_inertia() # pinch يلغي أي سرعة سابقة ولا يستعيدها
				city_drag_samples.clear()
				pinch_prev = _pinch_dist()
		else:
			if ignored.has(idx):
				ignored.erase(idx)
				return
			var info = touch_start.get(idx)
			var single := touches.size() == 1 and not multi
			touches.erase(idx)
			touch_start.erase(idx)
			if info != null and single and not moved_far and Time.get_ticks_msec() - int(info["t"]) < 450:
				_tap(e.position)
			if touches.is_empty():
				if single and moved_far:
					_start_city_inertia()
				multi = false
	elif e is InputEventScreenDrag:
		var di: int = e.index
		if ignored.has(di) or not touches.has(di):
			return
		touches[di] = e.position
		if touches.size() == 1:
			var inf = touch_start.get(di)
			if inf != null and (e.position - (inf["pos"] as Vector2)).length() > 18.0:
				moved_far = true
			if moved_far:
				_pan(e.relative)
				_record_city_drag_sample(e.position)
		else:
			var d := _pinch_dist()
			if pinch_prev > 1.0 and d > 1.0:
				zoom = clampf(zoom * pinch_prev / d, 14.0, 48.0)
			pinch_prev = d
	elif e is InputEventMouseButton and e.pressed:
		if e.button_index == MOUSE_BUTTON_LEFT:
			_cancel_city_inertia()
		elif e.button_index == MOUSE_BUTTON_WHEEL_UP:
			zoom = clampf(zoom * 0.92, 14.0, 48.0)
		elif e.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			zoom = clampf(zoom * 1.08, 14.0, 48.0)


func _tap(pos: Vector2) -> void:
	var o := cam.project_ray_origin(pos)
	var n := cam.project_ray_normal(pos)
	if absf(n.y) < 0.001:
		return
	var t := -o.y / n.y
	if t < 0.0:
		return
	var hit := o + n * t
	var best := -1
	var bd := PICK_RADIUS
	for i in plot_pos.size():
		var pp: Vector3 = plot_pos[i]
		var d := Vector2(hit.x - pp.x, hit.z - pp.z).length()
		if d < bd:
			bd = d
			best = i
	if best >= 0:
		_select(best)
	else:
		ui.hide_panel()


func _select(i: int) -> void:
	var pp: Vector3 = plot_pos[i]
	ring.position = pp + Vector3(0, 0.2, 0)
	ring.visible = true
	ui.show_plot(i)


func _on_panel_closed() -> void:
	ring.visible = false
