extends Node
## حالة اللعبة: الموارد، المباني، الحرارة، العواصف، الاستكشاف، الحفظ.

signal changed
signal structure_changed
signal toast(msg: String, bad: bool)

const SAVE_PATH := "user://frost_save_v1.json"
const RES_KEYS := ["wood", "coal", "food", "iron"]
const RES_NAMES := {"wood": "خشب", "coal": "فحم", "food": "طعام", "iron": "حديد"}
const RES_COLORS := {
	"wood": Color(0.75, 0.5, 0.25),
	"coal": Color(0.42, 0.42, 0.47),
	"food": Color(0.88, 0.38, 0.35),
	"iron": Color(0.58, 0.69, 0.8),
}
const PLOT_COUNT := 21 # 0 = الموقد، 1-8 الحلقة الأولى، 9-12 التوسعة الأولى، 13-20 التوسعة الثانية
const MAX_HEARTH := 30
const MAX_LEVEL_OTHER := 30
const MILITARY_TIER_LEVELS := [1, 12, 25, 30]
const MILITARY_TIER_NAMES := ["مبتدئ", "قوي", "نخبة", "أسطوري"]
const MILITARY_RANKS_PER_TIER := 7
const MAX_BUILDERS := 2
const STORM_CYCLE := 200.0
const STORM_LEN := 45.0
const EXP_FOOD_COST := 25
const EXP_TIME := 30.0 # توافق مع الحفظ القديم
const EVENT_INTERVAL := 100.0

# القسم 14: نموذج خريطة العالم المحلي. لا يمثل لاعبين حقيقيين؛ التوزيع الشبكي الفعلي مؤجل للسيرفر.
const PROVINCE_CAPACITY := 500
const PROVINCE_OPEN_THRESHOLD := 0.70
const INITIAL_PROVINCES := 5
const WORLD_NODE_RESPAWN := 300.0
# ثوابت ربط خريطة المقاطعة: عدّلها لتغيير أرصدة الموارد والقوافل.
const WORLD_MAP_SIZE := 1200 # عدد الخانات على كل ضلع من خريطة المقاطعة.
const WORLD_MAP_CENTER := 600 # إحداثي مركز الخريطة والعرش.
const WORLD_RESOURCE_DISTANCE_NORMALIZER := 849.0 # تطبيع المسافة من المركز عند تحديد مستوى المورد.
const WORLD_RESOURCE_OUTER_TIER_THRESHOLD := 0.72 # حد المنطقة الخارجية للموارد منخفضة المستوى.
const WORLD_RESOURCE_MIDDLE_TIER_THRESHOLD := 0.43 # حد المنطقة الوسطى للموارد متوسطة المستوى.
const WORLD_RESOURCE_SEED_MODULUS := 97 # مقدار بذرة المقاطعة المستخدمة في ضوضاء مستوى المورد.
const WORLD_RESOURCE_X_NOISE_FREQUENCY := 0.021 # تردد الضوضاء على محور X.
const WORLD_RESOURCE_Y_NOISE_FREQUENCY := 0.027 # تردد الضوضاء على محور Y.
const WORLD_RESOURCE_X_NOISE_AMPLITUDE := 0.035 # قوة الضوضاء على محور X.
const WORLD_RESOURCE_Y_NOISE_AMPLITUDE := 0.03 # قوة الضوضاء على محور Y.
const WORLD_RESOURCE_TYPE_X_MULTIPLIER := 17 # معامل X لتوزيع نوع المورد.
const WORLD_RESOURCE_TYPE_Y_MULTIPLIER := 31 # معامل Y لتوزيع نوع المورد.
const WORLD_CARAVAN_FOOD_DISTANCE_UNIT := 100.0 # وحدة المسافة التي تُحسب عليها مؤونة الطعام.
const WORLD_CARAVAN_CAVALRY_REDUCTION_CAP := 0.12 # الحد الأعلى لخفض الخطر بواسطة الفرسان.
const WORLD_NODE_BASE_STOCK := 500 # الرصيد الأساسي للمورد قبل تطبيق المستوى.
const WORLD_NODE_REGEN_FRACTION := 0.25 # نسبة الرصيد الأقصى التي تتجدد كل دورة.
const WORLD_CARAVAN_STABLE_TIME_REDUCTION_PER_LEVEL := 0.12 # خفض مدة الرحلة لكل مستوى إسطبل.
const WORLD_CARAVAN_MIN_TIME_MULTIPLIER := 0.55 # أقل مضاعف مدة بعد ترقية الإسطبل.
const WORLD_CARAVAN_ROUND_TRIP_MULTIPLIER := 2.0 # الذهاب والإياب.
const WORLD_CARAVAN_MIN_TRIP_SECONDS := 30.0 # أقل مدة رحلة بالثواني.
const WORLD_CARAVAN_LOSS_MIN_FRACTION := 0.25 # أقل نسبة حمولة معرضة للفقد عند وقوع الخطر.
const WORLD_CARAVAN_LOSS_MAX_FRACTION := 0.65 # أعلى نسبة حمولة معرضة للفقد عند وقوع الخطر.
const WORLD_CARAVAN_TIME_PER_CELL := 4.0 # ثواني الرحلة لكل خانة باتجاه واحد.
const WORLD_CARAVAN_BASE_CAPACITY := 80 # حمولة القافلة الأساسية.
const WORLD_CARAVAN_YARD_CAPACITY := 60 # حمولة إضافية لكل مستوى من مرسى القوافل.
const WORLD_CARAVAN_MAX_CONCURRENT := 4 # الحد الأعلى للقوافل النشطة بالتزامن.
const WORLD_CARAVAN_FOOD_PER_100_CELLS := 25.0 # مؤونة الطعام لكل 100 خانة من المسافة.
const WORLD_CARAVAN_MIN_FOOD_COST := 1 # أقل مؤونة طعام لكل إرسال.
const WORLD_CARAVAN_MAX_RISK := 0.75 # الحد الأعلى لخطر الطريق.
const WORLD_CARAVAN_STORM_TIME_MULTIPLIER := 1.35 # زيادة مدة الرحلة أثناء العاصفة.
const WORLD_CARAVAN_STORM_RISK := 0.18 # زيادة خطر الطريق أثناء العاصفة.
const WORLD_CARAVAN_STORM_LOSS_MULTIPLIER := 1.25 # زيادة الجزء المعرض للفقد أثناء العاصفة.
const WORLD_CARAVAN_MIN_RISK := 0.02 # أقل احتمال لخطر الطريق.
const WORLD_CARAVAN_BASE_RISK := 0.08 # الخطر الأساسي قبل احتساب المسافة.
const WORLD_CARAVAN_RISK_PER_CELL_DIVISOR := 1800.0 # كلما انخفض المقسوم زاد خطر المسافة.
const WORLD_CARAVAN_GUARD_REDUCTION := 0.07 # خفض الخطر لكل مستوى من برج الحراسة.
const WORLD_CARAVAN_CAVALRY_REDUCTION := 0.01 # خفض الخطر لكل نقطة من قوة الفرسان.
const WORLD_CARAVAN_MEDICINE_REDUCTION := 0.05 # خفض الخطر عند بحث طب الميدان.
const WORLD_PLAYER_CITY_MIN_RADIUS := 440.0 # أقل بعد عن مركز العرش لتوزيع مدينة اللاعب.
const WORLD_PLAYER_CITY_MAX_RADIUS := 545.0 # أكبر بعد عن مركز العرش لتوزيع مدينة اللاعب.
const WORLD_PLAYER_CITY_PLACEMENT_ATTEMPTS := 500 # محاولات إيجاد موقع خالٍ للمدينة.
const WORLD_PROVINCES := [
	{"id": "north_ridge", "name": "مرتفعات الشمال", "desc": "ممرات جبلية غنية بالحديد والفحم.", "nodes": [{"id":"iron_1","name":"منجم الحديد القديم","resource":"iron","amount":18},{"id":"coal_1","name":"شق الفحم","resource":"coal","amount":28}]},
	{"id": "frozen_oasis", "name": "الواحة المتجمدة", "desc": "بقايا بساتين ومخازن مؤن مدفونة تحت الثلج.", "nodes": [{"id":"food_1","name":"بستان الواحة","resource":"food","amount":35},{"id":"wood_1","name":"أشجار الواحة","resource":"wood","amount":22}]},
	{"id": "pine_forest", "name": "غابة الصنوبر", "desc": "غابة قاسية تمنح الخشب وموارد التدفئة.", "nodes": [{"id":"wood_2","name":"أحراج الصنوبر","resource":"wood","amount":35},{"id":"coal_2","name":"موقد الفحم المهجور","resource":"coal","amount":20}]},
	{"id": "old_pass", "name": "الممر العتيق", "desc": "طريق قوافل قديم ومواقع حديد متناثرة.", "nodes": [{"id":"iron_2","name":"حطام المنجم","resource":"iron","amount":14},{"id":"food_2","name":"مخزن القافلة","resource":"food","amount":22}]},
	{"id": "white_plains", "name": "السهول البيضاء", "desc": "أرض مفتوحة فيها مؤن قليلة وموارد متناثرة.", "nodes": [{"id":"food_3","name":"مؤن مدفونة","resource":"food","amount":25},{"id":"wood_3","name":"حطام العربات","resource":"wood","amount":18}]},
]

# طرق القوافل: مدة الرحلة، مؤونة الطعام، المخاطرة، ومضاعف الغنائم.
const CARAVAN_ROUTES := {
	"buried_oasis": {"name": "الواحة المدفونة", "desc": "طريق قصير بين الكثبان المتجمدة. مخاطرة منخفضة وغنائم متواضعة.", "time": 45.0, "food": 12, "risk": 0.10, "reward": 0.85},
	"traders_camp": {"name": "مخيم التجار", "desc": "تجارة ومقايضة في مخيم بعيد. عائد متوازن مع خطر متوسط.", "time": 75.0, "food": 20, "risk": 0.20, "reward": 1.35},
	"mountain_pass": {"name": "ممر الجبل", "desc": "ممر غني بالحديد والفحم، لكنه قاسٍ أثناء العواصف.", "time": 110.0, "food": 28, "risk": 0.32, "reward": 1.9},
}

const ADVISOR_ORDER := ["sheikh", "hakim", "faris"]
const ADVISORS := {
	"sheikh": {"name": "الشيخ", "role": "شيخ القبيلة", "color": Color(1.0, 0.85, 0.5)},
	"hakim": {"name": "الحكيم", "role": "حكيم القبيلة", "color": Color(0.6, 0.9, 1.0)},
	"faris": {"name": "الفارس", "role": "فارس القبيلة", "color": Color(1.0, 0.6, 0.55)},
}

# رتب السمعة: [الحد الأدنى, الاسم]. كل رتبة تزيد الإنتاج 4%
const FAME_RANKS := [[0, "مجهولة"], [20, "معروفة"], [50, "مشهورة"], [100, "ذائعة الصيت"], [200, "أسطورية"]]

# الفزعة بين القبائل: تكلفة الإغاثة، هدية الجيران، ومقدار السمعة والعلاقة.
const TRIBES := {
	"valley": {"name": "قبيلة الوادي", "desc": "أصاب الصقيع مخازنهم الخشبية، ويحتاجون إلى الخشب والطعام.", "cost": {"wood": 25, "food": 15}, "gift": {"food": 20}, "fame": 5, "relation": 8},
	"pass": {"name": "حراس الممر", "desc": "أغلق الجليد ممرهم الجبلي، ويحتاجون إلى الوقود والحديد لإصلاح العتاد.", "cost": {"coal": 20, "iron": 5}, "gift": {"iron": 8}, "fame": 7, "relation": 10},
	"oasis": {"name": "أهل الواحة", "desc": "تضررت مؤونتهم تحت الثلج، ويطلبون الطعام والفحم.", "cost": {"food": 30, "coal": 5}, "gift": {"wood": 20}, "fame": 5, "relation": 8},
}
const FAZAA_COOLDOWN := 180.0

# قضايا المجلس. fx: تغيّر الموارد (سالب = تكلفة)، fame، pop مع احتمال pop_p، loy للولاء (all = الجميع)
# قاعدة: في كل قضية خيار واحد على الأقل بلا تكلفة موارد حتى لا يعلق اللاعب.
const EVENTS := {
	"guest": {
		"who": "sheikh", "cond": "", "title": "ضيف على أطراف النار",
		"text": "وصل مسافر متجمد إلى حدود المخيم يطلب الدفء. قال الشيخ: النار لا تُوقد لأهلها وحدهم. ماذا تفعل؟",
		"choices": [
			{"text": "أكرمه بالقهوة والطعام", "fx": {"food": -15, "coal": -5, "fame": 6, "pop": 1, "pop_p": 0.5, "loy": {"sheikh": 8}},
				"result": "شرب الضيف القهوة ودعا لكم بالخير، وشاع كرمكم في الدروب."},
			{"text": "دعه يكمل طريقه", "fx": {"fame": -4, "loy": {"sheikh": -6}},
				"result": "مضى الغريب في الثلج، وعبس الشيخ من القرار."},
		],
	},
	"caravan": {
		"who": "faris", "cond": "", "title": "قافلة تجار عابرة",
		"text": "قافلة جمال محمّلة بالبضائع تعرض المقايضة قبل أن تواصل رحلتها.",
		"choices": [
			{"text": "بادلهم خشباً بحديد", "fx": {"wood": -60, "iron": 25, "loy": {"faris": 3}},
				"result": "عقدتم صفقة رابحة وغادرت القافلة راضية."},
			{"text": "اشتر طعاماً بالفحم", "fx": {"coal": -30, "food": 50},
				"result": "امتلأ المخزن بالطعام."},
			{"text": "اصرفهم بلطف", "fx": {"fame": -1},
				"result": "ودّعتم التجار بالسلامة."},
		],
	},
	"wolves": {
		"who": "faris", "cond": "", "title": "ذئاب تحوم حول المخيم",
		"text": "سمع الحرّاس عواء ذئاب قريبة، والناس خائفون. الفارس يطلب إذنك.",
		"choices": [
			{"text": "أرسل الفرسان لصدّها", "fx": {"food": -10, "iron": -5, "fame": 3, "loy": {"faris": 10}},
				"result": "تصدّى الفرسان للذئاب وعادوا فخورين."},
			{"text": "أشعل نيراناً حول المخيم", "fx": {"coal": -25, "loy": {"hakim": 5}},
				"result": "أبعد الضوء الذئاب، لكن الفحم نقص."},
			{"text": "تجاهل الأمر", "fx": {"fame": -2, "loy": {"faris": -8}},
				"result": "مرّت الليلة بسلام، لكن الفرسان تذمّروا."},
		],
	},
	"dispute": {
		"who": "sheikh", "cond": "", "title": "خلاف على الحصص",
		"text": "اختلف رجلان على حصة الطعام ووصل الخلاف إلى مجلسك.",
		"choices": [
			{"text": "اقسم بالعدل بين الجميع", "fx": {"food": -20, "loy": {"all": 4}},
				"result": "رضي الجميع بحكمك العادل."},
			{"text": "احكم لصاحب الجهد", "fx": {"loy": {"faris": 6, "hakim": -4}},
				"result": "رضي العاملون، وتحفّظ الحكيم على الحكم."},
			{"text": "أجّل القضية", "fx": {"loy": {"sheikh": -5}},
				"result": "بقي الخلاف معلقاً، وقلق الشيخ."},
		],
	},
	"poetry": {
		"who": "hakim", "cond": "", "title": "ليلة شعر",
		"text": "طلب الحكيم أن يقيم الناس أمسية شعر حول النار ليرفع الهمم في هذا البرد.",
		"choices": [
			{"text": "أقيموا الأمسية", "fx": {"coal": -10, "food": -10, "fame": 5, "loy": {"hakim": 8}},
				"result": "ارتفعت الأصوات بالشعر وسرى الدفء في القلوب."},
			{"text": "لا وقت للشعر", "fx": {"loy": {"hakim": -5}},
				"result": "نام الناس مبكراً، وصمت الحكيم."},
		],
	},
	"fazaa": {
		"who": "sheikh", "cond": "", "title": "نداء فزعة",
		"text": "قبيلة مجاورة أضرّ بها الصقيع وأرسلت تطلب الفزعة.",
		"choices": [
			{"text": "لبِّ النداء", "fx": {"food": -30, "wood": -30, "fame": 10, "loy": {"faris": 5, "sheikh": 4}},
				"result": "وصلت فزعتكم، وصار اسم القبيلة على كل لسان."},
			{"text": "اعتذر عن الفزعة", "fx": {"fame": -5, "loy": {"sheikh": -5}},
				"result": "اعتذرتم، وسُجّل ذلك في ذاكرة الدروب."},
		],
	},
	"omen": {
		"who": "hakim", "cond": "", "title": "نبوءة الحكيم",
		"text": "نظر الحكيم إلى النجوم وحذّر من شتاء أقسى، وطلب ادخار الفحم.",
		"choices": [
			{"text": "ادّخروا الفحم", "fx": {"wood": -40, "coal": 40, "loy": {"hakim": 6}},
				"result": "وفّرتم فحماً إضافياً لليالي الباردة."},
			{"text": "تجاهل التحذير", "fx": {"loy": {"hakim": -3}},
				"result": "هزّ الحكيم رأسه وانصرف."},
		],
	},
	"orphan": {
		"who": "sheikh", "cond": "pop_room", "title": "طفل ضائع في الثلج",
		"text": "عثر الحرّاس على طفل ضائع يرتجف عند أطراف المخيم.",
		"choices": [
			{"text": "آوِه وأطعمه", "fx": {"food": -10, "pop": 1, "fame": 4, "loy": {"sheikh": 4}},
				"result": "صار الطفل واحداً منكم."},
			{"text": "أرسله مع أول قافلة", "fx": {"loy": {"sheikh": -3}},
				"result": "غادر الطفل مع القافلة، وبقي الحزن في وجه الشيخ."},
		],
	},
}

# وظائف الناجين: اسم الوظيفة لكل مبنى
const JOBS := {
	"hearth": "حرّاس النار", "woodcutter": "حطّابون", "coalmine": "عمّال المنجم",
	"lodge": "صيّادون", "ironmine": "حدّادون",
}
# ترتيب التوزيع التلقائي (الأهم أولاً)
const AUTO_ORDER := ["coalmine", "lodge", "woodcutter", "ironmine", "hearth"]

const BUILD_ORDER := ["tent", "woodcutter", "coalmine", "lodge", "ironmine", "caravan_yard", "majlis", "guard_post", "stable", "infirmary", "research_hall", "infantry_barracks", "archer_barracks"]
# متطلبات فتح المباني: التقدم مرتبط بمستوى نار الضيافة، مع إبقاء المباني الموجودة كما هي.
const BUILDING_UNLOCKS := {
    "tent": 1, "woodcutter": 1, "coalmine": 1, "lodge": 1,
    "ironmine": 2, "caravan_yard": 2, "majlis": 2,
    "guard_post": 3, "stable": 3, "infirmary": 4, "research_hall": 2, "infantry_barracks": 3, "archer_barracks": 4
}
# تُفتح المساحات الإضافية مبكراً بما يكفي للمباني الأساسية، ثم تتوسع تدريجياً.
const EXTRA_PLOT_HEARTH_LEVELS := {9: 2, 10: 2, 11: 3, 12: 3, 13: 3, 14: 4, 15: 4, 16: 4, 17: 5, 18: 5, 19: 6, 20: 6}

const DEFS := {
	"hearth": {
		"name": "نار الضيافة", "short": "قلب القبيلة",
		"desc": "نار الأجداد التي لا تُطفأ للضيف. تدفئ الناجين وتحرق الفحم، وترقيتها ترفع الدفء وتفتح مستويات أعلى لكل المباني.",
		"cost": {"wood": 80, "coal": 40, "iron": 10}, "time": 25.0, "prod": {},
	},
	"tent": {
		"name": "بيت الشعر", "short": "يؤوي الناجين",
		"desc": "خيمة دافئة تؤوي ٤ ناجين إضافيين لكل مستوى.",
		"cost": {"wood": 40, "food": 20}, "time": 10.0, "prod": {},
	},
	"woodcutter": {
		"name": "مقطع الأخشاب", "short": "إنتاج الخشب",
		"desc": "حطابون يقطعون الأشجار ويجلبون الخشب.",
		"cost": {"wood": 30}, "time": 8.0, "prod": {"wood": 0.5},
	},
	"coalmine": {
		"name": "منجم الفحم", "short": "وقود الموقد",
		"desc": "الفحم يُبقي الموقد مشتعلاً. بدونه تتجمد المدينة.",
		"cost": {"wood": 50, "food": 10}, "time": 12.0, "prod": {"coal": 0.4},
	},
	"lodge": {
		"name": "بيت الصيد", "short": "إنتاج الطعام",
		"desc": "صيادون يجلبون الطعام من الجبال.",
		"cost": {"wood": 40}, "time": 10.0, "prod": {"food": 0.7},
	},
	"ironmine": {
		"name": "منجم الحديد", "short": "إنتاج الحديد",
		"desc": "الحديد لترقية الموقد وبناء القوة.",
		"cost": {"wood": 70, "coal": 30}, "time": 15.0, "prod": {"iron": 0.25},
	},
	"caravan_yard": {
		"name": "مرسى القوافل", "short": "تجهيز القوافل وفتح طرق التجارة",
		"desc": "ساحة تجمع الجمال والمؤن قبل الانطلاق. بناء هذا المرسى يفتح طرق القوافل الثلاث ويتيح إرسال المرافقين لاستعادة الموارد والناجين.",
		"cost": {"wood": 90, "food": 25, "iron": 10}, "time": 30.0, "prod": {},
	},
	"majlis": {
		"name": "مجلس القبيلة", "short": "يرفع السمعة ويقوّي الروابط",
		"desc": "مجلس يجتمع فيه الشيوخ والوجهاء. كل مستوى يمنح سمعة إضافية مع مرور الوقت.",
		"cost": {"wood": 75, "food": 35, "iron": 8}, "time": 22.0, "prod": {},
	},
	"guard_post": {
		"name": "برج الحراسة", "short": "يحمي القوافل",
		"desc": "نقطة مراقبة مرتفعة. كل مستوى يقلل خطر القوافل ويحد من خسائر الرحلات.",
		"cost": {"wood": 65, "iron": 18}, "time": 20.0, "prod": {},
	},
	"stable": {
		"name": "إسطبل القوافل", "short": "يسرّع الرحلات التجارية",
		"desc": "إسطبل مجهز للدواب ومؤن السفر. كل مستوى يقلل مدة القوافل العائدة.",
		"cost": {"wood": 85, "food": 25}, "time": 24.0, "prod": {},
	},
	"infirmary": {
		"name": "مضافة الحكيم", "short": "رعاية الناجين في البرد",
		"desc": "مأوى للعلاج والراحة. يقلل تراكم أثر البرد القارس على الناجين.",
		"cost": {"wood": 70, "food": 35, "iron": 6}, "time": 23.0, "prod": {},
	},
	"research_hall": {
		"name": "دار الحكمة", "short": "شجرة الأبحاث والتطوير",
		"desc": "مركز مستقل للبحوث. يفتح شجرة التطوير، وكل مستوى يسمح بإكمال ثلاثة أبحاث إضافية.",
		"cost": {"wood": 110, "food": 55, "iron": 15}, "time": 32.0, "prod": {},
	},
	"infantry_barracks": {
		"name": "ثكنة المشاة", "short": "تجنيد جنود المشاة",
		"desc": "تدريب جنود المشاة لحماية القبيلة. كل مستوى يزيد حجم دفعة التدريب.",
		"cost": {"wood": 100, "food": 60, "iron": 18}, "time": 30.0, "prod": {},
	},
	"archer_barracks": {
		"name": "ثكنة الرماة", "short": "تجنيد الرماة",
		"desc": "تدريب الرماة للدعم من مسافة بعيدة. كل مستوى يزيد حجم دفعة التدريب.",
		"cost": {"wood": 90, "food": 70, "iron": 22}, "time": 32.0, "prod": {},
	},
}

var stock := {}
var plots: Array = []
# وقت آخر جمع لكل عقدة؛ يحفظ محلياً حتى لا تتكرر المكافأة عند إعادة فتح اللعبة.
var world_gathered: Dictionary = {} # سجل قديم محفوظ للتوافق.
var world_caravans: Array = []
# بيانات الخريطة الدائمة؛ مفاتيح المدن والأرصدة منفصلة حسب المقاطعة.
var world_player_cities: Dictionary = {}
var world_node_balances: Dictionary = {}
var world_node_regen_times: Dictionary = {}
var world_map_views: Dictionary = {}
var world_map_saved_locations: Dictionary = {}
# ذاكرة مؤقتة داخل الجلسة لتجنب إعادة توليد المدن والموارد عند فتح الخريطة.
var world_map_cache: Dictionary = {}
var pop := 6
var exp_end := 0.0 # بيانات قديمة تحفظ للتوافق مع النسخ السابقة
var caravan_end := 0.0
var caravan_route := ""
var caravan_companions := 0
var caravan_food := 0
# منظومة الفرسان: عدد الفرسان ورتبتهم محفوظان مستقلين عن مستوى الإسطبل.
var cavalry_count := 0
var infantry_count := 0
var archer_count := 0
var cavalry_rank := 1 # رتبة التدريب داخل الفئة الحالية: I–VII
var cavalry_tier := 0 # فئة الوحدة العسكرية: مبتدئ، قوي، نخبة، أسطوري
# للمشاة والرماة منظومة رتب مستقلة؛ العدد الحالي كله يتبع الفئة والرتبة المسجلتين.
var infantry_rank := 1
var infantry_tier := 0
var archer_rank := 1
var archer_tier := 0
var developer_mode := false # وضع اختبار محلي محمي بكلمة مرور من واجهة اللعبة
var storm_clock := 0.0
var temp := -7.0
var pending_msg := ""
var fame := 0
var loyalty := {"sheikh": 50, "hakim": 50, "faris": 50}
var pending_event := ""
var event_clock := 0.0
var event_count := 0
var last_event := ""
var intro_seen := false
var tribal_relations := {"valley": 0, "pass": 0, "oasis": 0}
var tribal_cooldowns := {"valley": 0.0, "pass": 0.0, "oasis": 0.0}
var claimed_missions: Array = []
var claimed_achievements: Array = []

const MISSIONS := [
	{"id": "first_upgrade", "title": "تقوية نار الأجداد", "desc": "ارفع مستوى نار الضيافة إلى المستوى الثاني.", "kind": "hearth", "target": 2, "reward": {"wood": 35, "coal": 20}},
	{"id": "wood_supply", "title": "خشب للشتاء", "desc": "ابنِ مقطع الأخشاب وابدأ إنتاج الخشب.", "kind": "building", "target_id": "woodcutter", "target": 1, "reward": {"wood": 25, "food": 10}},
	{"id": "coal_supply", "title": "لا تدع النار تنطفئ", "desc": "ابنِ منجم الفحم لتأمين الوقود.", "kind": "building", "target_id": "coalmine", "target": 1, "reward": {"coal": 30, "food": 10}},
	{"id": "growing_tribe", "title": "قبيلة تكبر", "desc": "ارفع عدد الناجين إلى 8 أو أكثر.", "kind": "population", "target": 8, "reward": {"food": 35, "wood": 20}},
	{"id": "trade_route", "title": "افتح دروب التجارة", "desc": "أنشئ مرسى القوافل.", "kind": "building", "target_id": "caravan_yard", "target": 1, "reward": {"food": 25, "iron": 8}},
	{"id": "good_neighbors", "title": "الجيرة الطيبة", "desc": "قدّم الفزعة لإحدى القبائل وارفع علاقتكم بها إلى 8%.", "kind": "relation", "target": 8, "reward": {"wood": 25, "food": 25}},
	{"id": "known_name", "title": "اسمٌ يُعرف", "desc": "اجمع 20 نقطة سمعة.", "kind": "fame", "target": 20, "reward": {"iron": 10, "coal": 25}}
]

# إنجازات طويلة الأمد؛ مكافآتها مستقلة عن مكافآت المهام وتُحفظ بعد الاستلام.
const ACHIEVEMENTS := [
	{"id": "hearth_keeper", "title": "حارس الشعلة", "desc": "ارفع نار الضيافة إلى المستوى الثاني.", "kind": "hearth", "target": 2, "reward": {"wood": 25, "coal": 15}},
	{"id": "hearth_heart", "title": "قلب الواحة", "desc": "ارفع نار الضيافة إلى المستوى الخامس.", "kind": "hearth", "target": 5, "reward": {"wood": 60, "coal": 45, "iron": 10}},
	{"id": "famous_tribe", "title": "صيتٌ في الدروب", "desc": "اجمع 50 نقطة سمعة.", "kind": "fame", "target": 50, "reward": {"food": 45, "iron": 10}},
	{"id": "growing_people", "title": "أهلٌ ودار", "desc": "اجمع 12 ناجياً في القبيلة.", "kind": "population", "target": 12, "reward": {"food": 60, "wood": 35}},
	{"id": "good_neighbours", "title": "جارٌ لا يُخذل", "desc": "ارفع علاقتك بإحدى القبائل إلى 25%.", "kind": "relation", "target": 25, "reward": {"food": 30, "coal": 25}},
	{"id": "settlement_builder", "title": "عمران الشتاء", "desc": "أكمل بناء خمسة مبانٍ غير الموقد.", "kind": "buildings", "target": 5, "reward": {"wood": 55, "iron": 15}}
]

var _cold_t := 0.0
var _starve_t := 0.0
var _grow_t := 0.0
# منظومة البحوث: تسع تقنيات في ثلاثة فروع، مع شروط ومكافآت فعلية.
const RESEARCHES := {
	"woodcraft": {"name":"هندسة الأخشاب", "branch":"الإعمار والإنتاج", "desc":"زيادة إنتاج الخشب بنسبة 15%.", "cost":{"wood":70,"food":20}, "hearth":1, "building":"", "requires":[], "effect":"wood"},
	"coalcraft": {"name":"إدارة الوقود", "branch":"الإعمار والإنتاج", "desc":"خفض استهلاك الفحم بنسبة 15%.", "cost":{"wood":45,"coal":35,"iron":5}, "hearth":2, "building":"", "requires":["woodcraft"], "effect":"coal"},
	"preservation": {"name":"حفظ المؤن", "branch":"الإعمار والإنتاج", "desc":"خفض استهلاك الطعام للسكان بنسبة 15%.", "cost":{"wood":50,"food":65}, "hearth":2, "building":"lodge", "requires":["woodcraft"], "effect":"food"},
	"ironwork": {"name":"صهر الحديد", "branch":"العتاد والفرسان", "desc":"زيادة إنتاج الحديد بنسبة 20%.", "cost":{"wood":60,"coal":50,"food":30}, "hearth":2, "building":"ironmine", "requires":[], "effect":"iron"},
	"cavalry_drill": {"name":"تدريب الفرسان", "branch":"العتاد والفرسان", "desc":"رفع القوة القتالية المحسوبة للفرسان بنسبة 20%.", "cost":{"food":80,"iron":20,"wood":45}, "hearth":3, "building":"stable", "requires":["ironwork"], "effect":"cavalry"},
	"field_medicine": {"name":"طب الميدان", "branch":"العتاد والفرسان", "desc":"تحسين الاستعداد للقوافل؛ خفض خطر الطريق بنسبة إضافية 5%.", "cost":{"food":70,"iron":18,"coal":25}, "hearth":3, "building":"infirmary", "requires":["ironwork"], "effect":"risk"},
	"logistics": {"name":"إدارة المسالك", "branch":"التجارة والإمداد", "desc":"تقليل مدة القوافل بنسبة 15%.", "cost":{"wood":80,"food":60,"iron":12}, "hearth":2, "building":"caravan_yard", "requires":[], "effect":"time"},
	"storekeeping": {"name":"هندسة المخازن", "branch":"التجارة والإمداد", "desc":"زيادة سعة تخزين الموارد بنسبة 20%.", "cost":{"wood":100,"iron":15,"coal":35}, "hearth":3, "building":"", "requires":["logistics"], "effect":"storage"},
	"trade_network": {"name":"شبكة القوافل", "branch":"التجارة والإمداد", "desc":"زيادة غنائم القوافل العائدة بنسبة 10%.", "cost":{"wood":90,"food":75,"iron":20}, "hearth":4, "building":"caravan_yard", "requires":["logistics"], "effect":"loot"},
}

var _emit_t := 0.0
var _save_t := 0.0
var _fame_t := 0.0
var researched: Array = []


func _ready() -> void:
	randomize()
	_new_game()
	load_game()


var settings: Dictionary = {"muted": false, "effects": true, "ambience": true, "graphics_quality": "medium", "profile": {"name":"قائد الموقد", "tribe":"قبيلة الصقيع", "emblem":"❄", "color":"#D99A45"}}

func _new_game() -> void:
	stock = {"wood": 150.0, "coal": 60.0, "food": 80.0, "iron": 20.0}
	plots = []
	for i in PLOT_COUNT:
		plots.append({"type": "", "level": 0, "to": 0, "end": 0.0, "workers": 0})
	plots[0]["type"] = "hearth"
	plots[0]["level"] = 1
	plots[0]["workers"] = 1
	pop = 6
	cavalry_count = 0
	infantry_count = 0
	archer_count = 0
	cavalry_rank = 1
	cavalry_tier = 0
	infantry_rank = 1
	infantry_tier = 0
	archer_rank = 1
	archer_tier = 0
	exp_end = 0.0
	caravan_end = 0.0
	caravan_route = ""
	caravan_companions = 0
	caravan_food = 0
	storm_clock = 0.0
	fame = 0
	loyalty = {"sheikh": 50, "hakim": 50, "faris": 50}
	pending_event = ""
	event_clock = 55.0
	event_count = 0
	last_event = ""
	tribal_relations = {"valley": 0, "pass": 0, "oasis": 0}
	tribal_cooldowns = {"valley": 0.0, "pass": 0.0, "oasis": 0.0}
	claimed_missions = []
	claimed_achievements = []
	researched = []
	_cold_t = 0.0
	_starve_t = 0.0
	_grow_t = 0.0


func now() -> float:
	return Time.get_unix_time_from_system()


func fmt_time(sec: float) -> String:
	var s := int(maxf(0.0, ceil(sec)))
	return "%d:%02d" % [floori(s / 60.0), s % 60]


# ---------- حسابات ----------

func hearth_level() -> int:
	return int(plots[0]["level"])


func storage_cap() -> int:
	return int((300 + 300 * hearth_level()) * (1.2 if has_research("storekeeping") else 1.0))


func pop_cap() -> int:
	var c := 4 + hearth_level() * 2
	for p in plots:
		if p["type"] == "tent":
			c += int(p["level"]) * 4
	return c


func is_storm() -> bool:
	return storm_clock >= STORM_CYCLE - STORM_LEN


func storm_warning() -> bool:
	return (not is_storm()) and storm_clock >= STORM_CYCLE - STORM_LEN - 15.0


func outdoor() -> float:
	return -50.0 if is_storm() else -25.0


func warmth() -> float:
	if float(stock["coal"]) <= 0.0:
		return 0.0
	return 12.0 + 6.0 * float(hearth_level())


func coal_burn() -> float:
	return 0.08 * float(hearth_level()) * keeper_factor() * (2.0 if is_storm() else 1.0) * (0.85 if has_research("coalcraft") else 1.0)


func temp_mult() -> float:
	if temp >= -10.0:
		return 1.0
	if temp >= -25.0:
		return 0.65
	return 0.35


func _raw_rate(key: String) -> float:
	var r := 0.0
	for i in PLOT_COUNT:
		r += plot_rate(i, key)
	return r


# إنتاج مبنى واحد (بالثانية) بحسب مستواه وعدد عماله
func plot_rate(i: int, key: String) -> float:
	var p: Dictionary = plots[i]
	var lvl := int(p["level"])
	if lvl <= 0 or not DEFS.has(p["type"]):
		return 0.0
	var pr: Dictionary = DEFS[p["type"]]["prod"]
	if not pr.has(key):
		return 0.0
	var sl := slots_for(str(p["type"]), lvl)
	if sl <= 0:
		return 0.0
	return float(pr[key]) * (1.0 + 0.7 * float(lvl - 1)) * float(int(p["workers"])) / float(sl) * caravan_production_mult() * caravan_production_mult()


# ---------- الناجون والوظائف ----------

func slots_for(type: String, lvl: int) -> int:
	if lvl <= 0:
		return 0
	if type == "hearth":
		return lvl
	if type == "tent" or type == "" or type in ["caravan_yard", "majlis", "guard_post", "stable", "infirmary", "research_hall", "infantry_barracks", "archer_barracks"]:
		return 0
	return 2 + lvl


func workers_of(i: int) -> int:
	return int(plots[i]["workers"])


func keeper_factor() -> float:
	return 1.0 - 0.05 * float(workers_of(0))


func idle() -> int:
	var w := 0
	for q in plots:
		w += int(q["workers"])
	return maxi(0, pop - w)


func free_slots() -> int:
	var n := 0
	for q in plots:
		n += maxi(0, slots_for(str(q["type"]), int(q["level"])) - int(q["workers"]))
	return n


func assign(i: int, d: int) -> bool:
	var p: Dictionary = plots[i]
	var sl := slots_for(str(p["type"]), int(p["level"]))
	if sl <= 0:
		return false
	var w := int(p["workers"])
	var nw := clampi(w + d, 0, sl)
	if nw == w:
		return false
	if nw > w and idle() <= 0:
		toast.emit("لا يوجد ناجون عاطلون", true)
		return false
	p["workers"] = nw
	changed.emit()
	save_game()
	return true


func auto_assign() -> void:
	for q in plots:
		q["workers"] = 0
	var left := pop
	var progress := true
	while left > 0 and progress:
		progress = false
		for t in AUTO_ORDER:
			for i in PLOT_COUNT:
				var p: Dictionary = plots[i]
				if str(p["type"]) != t or int(p["level"]) <= 0:
					continue
				if left > 0 and int(p["workers"]) < slots_for(t, int(p["level"])):
					p["workers"] = int(p["workers"]) + 1
					left -= 1
					progress = true
	toast.emit("وُزّع الناجون على الأعمال", false)
	changed.emit()
	save_game()


func _fill_idle(i: int) -> void:
	var p: Dictionary = plots[i]
	var room := slots_for(str(p["type"]), int(p["level"])) - int(p["workers"])
	var n := mini(idle(), room)
	if n > 0:
		p["workers"] = int(p["workers"]) + n


# يضمن ألا يزيد العمال عن الناجين ولا عن مقاعد المبنى
func _normalize_workers() -> void:
	var total := 0
	for i in PLOT_COUNT:
		var p: Dictionary = plots[i]
		var sl := slots_for(str(p["type"]), int(p["level"]))
		p["workers"] = clampi(int(p["workers"]), 0, sl)
		total += int(p["workers"])
	var j := PLOT_COUNT - 1
	while total > pop and j >= 0:
		var w := int(plots[j]["workers"])
		var take := mini(w, total - pop)
		plots[j]["workers"] = w - take
		total -= take
		j -= 1


func prod_rate(key: String) -> float:
	var bonus := 1.0
	if key == "wood" and has_research("woodcraft"):
		bonus += 0.15
	if key == "iron" and has_research("ironwork"):
		bonus += 0.20
	return _raw_rate(key) * bonus * temp_mult() * fame_mult() * loy_mult()


func busy_count() -> int:
	var n := 0
	for p in plots:
		if float(p["end"]) > 0.0:
			n += 1
	return n


func cost_for(type: String, level_to: int) -> Dictionary:
	var base: Dictionary = DEFS[type]["cost"]
	# الموقد هو المبنى الرئيسي؛ تكلفته أعلى من أي مبنى آخر عند المستوى نفسه.
	var hearth_multiplier: float = 2.5 if type == "hearth" else 1.0
	# تصاعد تدريجي مناسب لمسار طويل يصل إلى المستوى 30.
	var f: float = pow(1.35, float(level_to - 1)) * hearth_multiplier
	var out: Dictionary = {}
	for k in base:
		out[k] = int(ceil(float(base[k]) * f))
	return out


func time_for(type: String, level_to: int) -> float:
	var growth: float = 1.25 if type == "hearth" else 1.22
	return float(DEFS[type]["time"]) * pow(growth, float(level_to - 1))


func can_afford(cost: Dictionary) -> bool:
	if developer_mode:
		return true
	for k in cost:
		if float(stock[k]) < float(cost[k]):
			return false
	return true


func _pay(cost: Dictionary) -> void:
	if developer_mode:
		return
	for k in cost:
		stock[k] = float(stock[k]) - float(cost[k])


func building_level(type: String) -> int:
	var total := 0
	for p in plots:
		if str(p.get("type", "")) == type:
			total += int(p.get("level", 0))
	return total


# ---------- أفعال اللاعب ----------

func building_unlock_level(type: String) -> int:
	return int(BUILDING_UNLOCKS.get(type, 1))


func plot_unlock_level(i: int) -> int:
	return int(EXTRA_PLOT_HEARTH_LEVELS.get(i, 1))


func is_plot_unlocked(i: int) -> bool:
	return i >= 0 and i < PLOT_COUNT and (developer_mode or hearth_level() >= plot_unlock_level(i))


func start_build(i: int, type: String) -> bool:
	if i <= 0 or i >= PLOT_COUNT:
		return false
	if not is_plot_unlocked(i):
		toast.emit("تحتاج نار الضيافة إلى المستوى %d لفتح قطعة الأرض" % plot_unlock_level(i), true)
		return false
	if not developer_mode and hearth_level() < building_unlock_level(type):
		toast.emit("يتطلب هذا المبنى نار الضيافة مستوى %d" % building_unlock_level(type), true)
		return false
	if plots[i]["type"] != "":
		return false
	for plot in plots:
		if str(plot.get("type", "")) == type:
			toast.emit("يمكن بناء نسخة واحدة فقط من كل مبنى", true)
			return false
	return _begin(i, type, 1)

func start_upgrade(i: int) -> bool:
	if i < 0 or i >= plots.size() or i >= PLOT_COUNT:
		return false
	if not is_plot_unlocked(i):
		toast.emit("تحتاج نار الضيافة إلى المستوى %d لفتح قطعة الأرض" % plot_unlock_level(i), true)
		return false
	var p: Dictionary = plots[i]
	if p["type"] == "" or float(p["end"]) > 0.0:
		return false
	var to := int(p["level"]) + 1
	if p["type"] == "hearth":
		if to > MAX_HEARTH:
			toast.emit("الموقد وصل لأقصى مستوى", false)
			return false
	else:
		if to > MAX_LEVEL_OTHER:
			toast.emit("المبنى وصل لأقصى مستوى", false)
			return false
		if not developer_mode and to > hearth_level() + 1:
			toast.emit("يمكن أن يتجاوز المبنى مستوى نار الضيافة بمستوى واحد فقط", true)
			return false
		if not developer_mode and to >= MAX_LEVEL_OTHER and hearth_level() < MAX_HEARTH:
			toast.emit("لا يمكن بلوغ المستوى 30 قبل وصول نار الضيافة إلى المستوى 30", true)
			return false
	return _begin(i, p["type"], to)


func _begin(i: int, type: String, to: int) -> bool:
	if not developer_mode and busy_count() >= MAX_BUILDERS:
		toast.emit("جميع البنّائين مشغولون", true)
		return false
	var cost := cost_for(type, to)
	if not can_afford(cost):
		toast.emit("الموارد غير كافية", true)
		return false
	_pay(cost)
	var p: Dictionary = plots[i]
	p["type"] = type
	p["to"] = to
	p["end"] = 0.0 if developer_mode else now() + time_for(type, to)
	if developer_mode:
		_finish(i, true)
	structure_changed.emit()
	changed.emit()
	save_game()
	return true


func speed_up(i: int) -> void:
	var p: Dictionary = plots[i]
	if float(p["end"]) > 0.0:
		_finish(i, false)
		changed.emit()


func start_expedition() -> void:
	if exp_end > 0.0:
		return
	if not developer_mode and float(stock["food"]) < EXP_FOOD_COST:
		toast.emit("لا يوجد طعام كافٍ للكشافة", true)
		return
	stock["food"] = float(stock["food"]) - EXP_FOOD_COST
	exp_end = now() + EXP_TIME
	toast.emit("خرجت الكشافة للاستكشاف", false)
	changed.emit()


# ---------- القوافل ----------

func start_caravan(route_id: String, companions: int) -> bool:
	if caravan_end > 0.0:
		toast.emit("هناك قافلة خارج المخيم بالفعل", true)
		return false
	if not CARAVAN_ROUTES.has(route_id):
		return false
	var route: Dictionary = CARAVAN_ROUTES[route_id]
	var team := clampi(companions, 0, mini(3, maxi(0, pop - 1)))
	var food_cost := int(route["food"]) + team * 4
	if not developer_mode and float(stock["food"]) < food_cost:
		toast.emit("الطعام لا يكفي لتجهيز هذه القافلة", true)
		return false
	stock["food"] = float(stock["food"]) - food_cost
	caravan_route = route_id
	caravan_companions = team
	caravan_food = food_cost
	var stable_levels := building_level("stable")
	var travel_time := float(route["time"]) * maxf(0.55, 1.0 - 0.12 * float(stable_levels)) * (0.85 if has_research("logistics") else 1.0)
	caravan_end = now() + travel_time
	toast.emit("انطلقت قافلة %s ومعها %d مرافقين" % [route["name"], team], false)
	changed.emit()
	save_game()
	return true


func finish_caravan() -> void:
	if caravan_end <= 0.0 or not CARAVAN_ROUTES.has(caravan_route):
		caravan_end = 0.0
		return
	var route: Dictionary = CARAVAN_ROUTES[caravan_route]
	var risk := float(route["risk"])
	risk = maxf(0.03, risk - 0.07 * float(building_level("guard_post")) - minf(0.12, float(cavalry_power()) * 0.01) - (0.05 if has_research("field_medicine") else 0.0))
	if is_storm():
		risk = minf(0.8, risk + 0.22)
	var roll := randf()
	var msg: String = "عادت قافلة %s بسلام: " % route["name"]
	var bad := false
	if roll < risk:
		bad = true
		var loss := mini(caravan_companions, 1 if roll < risk * 0.45 else 0)
		if loss > 0:
			pop = maxi(1, pop - loss)
		msg = "تعرضت قافلة %s للخطر! " % route["name"]
		var salvage := int(8 + 12 * float(route["reward"]))
		stock["wood"] = minf(float(storage_cap()), float(stock["wood"]) + salvage)
		stock["food"] = minf(float(storage_cap()), float(stock["food"]) + salvage)
		msg += "أنقذ المرافقون جزءاً من المؤن."
		if loss > 0:
			msg += " فُقد أحد المرافقين."
	else:
		var mult := float(route["reward"]) * (1.0 + float(caravan_companions) * 0.12) * (1.0 + float(fame_rank()) * 0.04) * (1.1 if has_research("trade_network") else 1.0)
		var loot := {"wood": int(randf_range(18, 35) * mult), "coal": int(randf_range(12, 25) * mult), "food": int(randf_range(15, 30) * mult), "iron": int(randf_range(5, 12) * mult)}
		var parts := PackedStringArray()
		for k in RES_KEYS:
			var before := float(stock[k])
			stock[k] = minf(float(storage_cap()), before + float(loot[k]))
			var gained := int(float(stock[k]) - before)
			if gained > 0:
				parts.append("%s %d" % [RES_NAMES[k], gained])
		fame += 2 + int(route["reward"] * 2.0) + caravan_companions
		if randf() < 0.18 and pop < pop_cap():
			pop += 1
			msg += " وعثروا على ناجٍ انضم إلى القبيلة! "
		msg += "، ".join(parts)
	caravan_end = 0.0
	caravan_route = ""
	caravan_companions = 0
	caravan_food = 0
	toast.emit(msg, bad)
	changed.emit()
	save_game()


# ---------- مركز البحوث (القسم 12) ----------
func has_research(tech_id: String) -> bool:
	return tech_id in researched

func research_status(tech_id: String) -> String:
	if not RESEARCHES.has(tech_id):
		return "غير متاحة"
	if has_research(tech_id):
		return "مكتملة"
	if building_level("research_hall") <= 0:
		return "تحتاج بناء دار الحكمة"
	if research_count() >= building_level("research_hall") * 3:
		return "طوّر دار الحكمة لفتح أبحاث إضافية"
	var tech: Dictionary = RESEARCHES[tech_id]
	if developer_mode:
		return "جاهزة للبحث"
	if hearth_level() < int(tech.get("hearth", 1)):
		return "تحتاج موقد مستوى %d" % int(tech["hearth"])
	var building := str(tech.get("building", ""))
	if building != "" and building_level(building) <= 0:
		return "تحتاج بناء %s" % str(DEFS.get(building, {}).get("name", building))
	for req in tech.get("requires", []):
		if not has_research(str(req)):
			return "تتطلب بحث: %s" % str(RESEARCHES[str(req)]["name"])
	return "جاهزة للبحث"

func start_research(tech_id: String) -> bool:
	if not RESEARCHES.has(tech_id):
		toast.emit("هذا البحث غير معروف", true)
		return false
	var status := research_status(tech_id)
	if status == "مكتملة":
		toast.emit("هذا البحث مكتمل بالفعل", false)
		return false
	if status != "جاهزة للبحث":
		toast.emit(status, true)
		return false
	var tech: Dictionary = RESEARCHES[tech_id]
	var cost: Dictionary = tech["cost"]
	if not can_afford(cost):
		toast.emit("الموارد غير كافية لهذا البحث", true)
		return false
	_pay(cost)
	researched.append(tech_id)
	toast.emit("اكتمل بحث: %s" % str(tech["name"]), false)
	changed.emit()
	save_game()
	return true

func research_count() -> int:
	return researched.size()

# ---------- القوة الكلية للمدينة ----------
# القوة تُحسب من الحالة الحالية ولا تُحفظ كرقم منفصل.
# كل مبنى وأبحاثه لها وزن؛ مخزون الموارد والإنتاج الخام لا يمنحان قوة بحد ذاتهما.
const TROOP_POWER_INFANTRY := 25
const TROOP_POWER_ARCHER := 30
const TROOP_POWER_CAVALRY := 25 # يتأثر بعدد الفرسان وفئتهم ورتبتهم وبحث تدريب الفرسان.
const HEARTH_POWER_BASE := 60
const HEARTH_POWER_GROWTH := 8
# وزن المبنى لكل مستوى: [قيمة المستوى الأساسية، زيادة كل مستوى لاحق].
const POWER_BUILDING_WEIGHTS := {
    "tent": [14, 2],
    "woodcutter": [18, 3],
    "coalmine": [20, 3],
    "lodge": [18, 3],
    "ironmine": [22, 4],
    "caravan_yard": [24, 4],
    "majlis": [22, 4],
    "guard_post": [35, 5],
    "stable": [32, 5],
    "infirmary": [28, 4],
    "research_hall": [32, 5],
    "infantry_barracks": [35, 5],
    "archer_barracks": [35, 5],
}
# الأبحاث الاقتصادية والتجارية تمنح قوة تطوير، لكن مخزون الموارد لا يمنح أي نقاط.
const POWER_RESEARCH_VALUES := {
    "woodcraft": 140,
    "coalcraft": 150,
    "preservation": 160,
    "ironwork": 170,
    "cavalry_drill": 300,
    "field_medicine": 220,
    "logistics": 150,
    "storekeeping": 160,
    "trade_network": 190,
}

func _power_for_level(level: int, base_points: int, growth_points: int) -> int:
	# مجموع تراكمي: كل مستوى جديد يمنح أكثر من المستوى السابق.
	var safe_level := maxi(0, level)
	return safe_level * base_points + int(float(growth_points * safe_level * (safe_level - 1)) / 2.0)

func city_power_breakdown() -> Dictionary:
	# العدد × وزن الفئة × رتبة التدريب؛ الفئات والرتب مستقلة لكل نوع جيش.
	var infantry_points := infantry_power()
	var archer_points := archer_power()
	var cavalry_points := maxi(0, cavalry_power()) * TROOP_POWER_CAVALRY
	var building_points := 0
	for plot in plots:
		var building_type := str(plot.get("type", ""))
		var level := maxi(0, int(plot.get("level", 0)))
		if building_type == "hearth":
			building_points += _power_for_level(level, HEARTH_POWER_BASE, HEARTH_POWER_GROWTH)
		elif POWER_BUILDING_WEIGHTS.has(building_type):
			var weight: Array = POWER_BUILDING_WEIGHTS[building_type]
			building_points += _power_for_level(level, int(weight[0]), int(weight[1]))
	var research_points := 0
	for tech_id in researched:
		research_points += int(POWER_RESEARCH_VALUES.get(str(tech_id), 0))
	return {
		"army": infantry_points + archer_points + cavalry_points,
		"buildings": building_points,
		"research": research_points,
		"total": infantry_points + archer_points + cavalry_points + building_points + research_points,
	}

func city_power() -> int:
	return maxi(0, int(city_power_breakdown().get("total", 0)))

# ---------- منظومة الفرسان (القسم 11) ----------
func military_player_level() -> int:
	# مستوى التقدم العام مستقل عن مستويات المباني، ويُحتسب من السمعة المكتسبة.
	return clampi(1 + int(floor(float(maxi(0, fame)) / 10.0)), 1, 30)

func military_tier_for_level(level: int) -> int:
	var tier := 0
	for i in MILITARY_TIER_LEVELS.size():
		if level >= int(MILITARY_TIER_LEVELS[i]):
			tier = i
	return tier

func military_tier_name(tier: int) -> String:
	return str(MILITARY_TIER_NAMES[clampi(tier, 0, MILITARY_TIER_NAMES.size() - 1)])

func infantry_capacity() -> int:
	return building_level("infantry_barracks") * 5

func archer_capacity() -> int:
	return building_level("archer_barracks") * 4

func infantry_power() -> int:
	var tier_multiplier: int = [1, 2, 4, 8][clampi(infantry_tier, 0, 3)]
	return maxi(0, infantry_count) * TROOP_POWER_INFANTRY * maxi(1, infantry_rank) * tier_multiplier

func archer_power() -> int:
	var tier_multiplier: int = [1, 2, 4, 8][clampi(archer_tier, 0, 3)]
	return maxi(0, archer_count) * TROOP_POWER_ARCHER * maxi(1, archer_rank) * tier_multiplier

func train_infantry() -> bool:
	var unlocked_tier := military_tier_for_level(military_player_level())
	if infantry_tier < unlocked_tier:
		infantry_tier += 1
		infantry_rank = 1
		toast.emit("تم فتح فئة %s للمشاة" % military_tier_name(infantry_tier), false)
		changed.emit(); save_game()
		return true
	if infantry_count <= 0:
		toast.emit("جنّد جنود مشاة أولاً قبل تدريبهم", true)
		return false
	if infantry_rank >= MILITARY_RANKS_PER_TIER:
		toast.emit("وصل المشاة إلى أعلى رتبة تدريب حالياً", false)
		return false
	var cost := {"food": 20 * infantry_rank, "iron": 10 * infantry_rank, "wood": 16 * infantry_rank}
	if not can_afford(cost):
		toast.emit("الموارد غير كافية لتدريب المشاة", true)
		return false
	_pay(cost)
	infantry_rank += 1
	toast.emit("ارتفعت رتبة المشاة إلى %d؛ قوتهم الآن %d" % [infantry_rank, infantry_power()], false)
	changed.emit(); save_game()
	return true

func train_archers() -> bool:
	var unlocked_tier := military_tier_for_level(military_player_level())
	if archer_tier < unlocked_tier:
		archer_tier += 1
		archer_rank = 1
		toast.emit("تم فتح فئة %s للرماة" % military_tier_name(archer_tier), false)
		changed.emit(); save_game()
		return true
	if archer_count <= 0:
		toast.emit("جنّد رماة أولاً قبل تدريبهم", true)
		return false
	if archer_rank >= MILITARY_RANKS_PER_TIER:
		toast.emit("وصل الرماة إلى أعلى رتبة تدريب حالياً", false)
		return false
	var cost := {"food": 22 * archer_rank, "iron": 12 * archer_rank, "wood": 18 * archer_rank}
	if not can_afford(cost):
		toast.emit("الموارد غير كافية لتدريب الرماة", true)
		return false
	_pay(cost)
	archer_rank += 1
	toast.emit("ارتفعت رتبة الرماة إلى %d؛ قوتهم الآن %d" % [archer_rank, archer_power()], false)
	changed.emit(); save_game()
	return true

func recruit_infantry() -> bool:
	if building_level("infantry_barracks") <= 0:
		toast.emit("ابنِ ثكنة المشاة أولاً", true)
		return false
	var cost := {"food": 12 + infantry_count, "wood": 8, "iron": 2}
	if not can_afford(cost):
		toast.emit("الموارد غير كافية لتجنيد جندي", true)
		return false
	_pay(cost)
	infantry_count += 1
	toast.emit("تم التجنيد بنجاح — إجمالي جنود المشاة: %d" % infantry_count, false)
	changed.emit(); save_game()
	return true

func recruit_archer() -> bool:
	if building_level("archer_barracks") <= 0:
		toast.emit("ابنِ ثكنة الرماة أولاً", true)
		return false
	var cost := {"food": 14 + archer_count, "wood": 10, "iron": 3}
	if not can_afford(cost):
		toast.emit("الموارد غير كافية لتجنيد رامٍ", true)
		return false
	_pay(cost)
	archer_count += 1
	toast.emit("تم التجنيد بنجاح — إجمالي الرماة: %d" % archer_count, false)
	changed.emit(); save_game()
	return true

func cavalry_capacity() -> int:
	# هذه سعة دفعة التدريب، وليست حداً أعلى لعدد الفرسان الموجودين.
	return maxi(1, building_level("stable") * 3)

func cavalry_power() -> int:
	var tier_multiplier: int = [1, 2, 4, 8][clampi(cavalry_tier, 0, 3)]
	return int(round(float(cavalry_count * cavalry_rank * tier_multiplier) * (1.2 if has_research("cavalry_drill") else 1.0)))

func recruit_cavalry() -> bool:
	if building_level("stable") <= 0:
		toast.emit("ابنِ إسطبل الفرسان أولاً", true)
		return false
	var cost := {"food": 18 + cavalry_count * 2, "wood": 12, "iron": 5}
	if not can_afford(cost):
		toast.emit("الموارد غير كافية لتجهيز فارس جديد", true)
		return false
	_pay(cost)
	cavalry_count += 1
	toast.emit("انضم فارس جديد إلى راية القبيلة", false)
	changed.emit()
	save_game()
	return true

func train_cavalry() -> bool:
	var unlocked_tier := military_tier_for_level(military_player_level())
	if cavalry_tier < unlocked_tier:
		var next_tier := cavalry_tier + 1
		if military_player_level() < int(MILITARY_TIER_LEVELS[next_tier]):
			toast.emit("تُفتح الفئة التالية عند مستوى اللاعب %d" % int(MILITARY_TIER_LEVELS[next_tier]), true)
			return false
		cavalry_tier = next_tier
		cavalry_rank = 1
		toast.emit("تم فتح فئة %s للفرسان" % military_tier_name(cavalry_tier), false)
		changed.emit()
		save_game()
		return true
	if cavalry_count <= 0:
		toast.emit("جنّد فرساناً أولاً قبل تدريبهم", true)
		return false
	if cavalry_rank >= MILITARY_RANKS_PER_TIER:
		toast.emit("وصل الفرسان إلى أعلى رتبة تدريب حالياً", false)
		return false
	var cost := {"food": 25 * cavalry_rank, "iron": 12 * cavalry_rank, "wood": 20 * cavalry_rank}
	if not can_afford(cost):
		toast.emit("الموارد غير كافية لتدريب الفرسان", true)
		return false
	_pay(cost)
	cavalry_rank += 1
	toast.emit("تدرّب الفرسان وارتفعت رتبتهم إلى %d؛ قوتهم الآن %d" % [cavalry_rank, cavalry_power()], false)
	changed.emit()
	save_game()
	return true

func caravan_production_mult() -> float:
	if caravan_end <= 0.0:
		return 1.0
	return maxf(0.65, 1.0 - float(caravan_companions) * 0.06)


# ---------- أحداث ----------

func _finish(i: int, silent: bool) -> void:
	var p: Dictionary = plots[i]
	var was_new := int(p["level"]) == 0
	p["level"] = int(p["to"])
	p["to"] = 0
	p["end"] = 0.0
	if was_new:
		_fill_idle(i)
	if not silent:
		toast.emit("اكتمل: %s — مستوى %d" % [DEFS[p["type"]]["name"], int(p["level"])], false)
	structure_changed.emit()


func _finish_expedition() -> void:
	exp_end = 0.0
	var lvl := hearth_level()
	var roll := randf()
	var mult := 1.0
	var bad := false
	var msg := "عادت الكشافة بغنائم: "
	if roll < 0.15:
		mult = 0.4
		bad = true
		msg = "هاجمتهم الذئاب! عادوا بغنيمة قليلة: "
	var parts := PackedStringArray()
	var cap_v := float(storage_cap())
	for k in RES_KEYS:
		var amt := int(float(randi_range(20, 60) * lvl) * mult)
		stock[k] = minf(float(stock[k]) + float(amt), cap_v)
		parts.append("%s %d" % [RES_NAMES[k], amt])
	msg += "، ".join(parts)
	if roll > 0.8 and pop < pop_cap():
		var n := mini(randi_range(1, 3), pop_cap() - pop)
		pop += n
		msg += " — ووجدوا %d ناجين!" % n
	toast.emit(msg, bad)


func _process(delta: float) -> void:
	var t := now()
	for i in PLOT_COUNT:
		var p: Dictionary = plots[i]
		if float(p["end"]) > 0.0 and t >= float(p["end"]):
			_finish(i, false)
	if exp_end > 0.0 and t >= exp_end:
		_finish_expedition()
	if caravan_end > 0.0 and t >= caravan_end:
		finish_caravan()
	_process_world_caravans(t)

	if intro_seen and pending_event == "":
		event_clock += delta
		if event_clock >= EVENT_INTERVAL:
			_post_event()

	storm_clock = fmod(storm_clock + delta, STORM_CYCLE)
	temp = outdoor() + warmth()
	_simulate(delta)
	_life(delta)
	if building_level("majlis") > 0:
		_fame_t += delta
		if _fame_t >= 60.0:
			_fame_t = 0.0
			fame += building_level("majlis")

	_emit_t += delta
	if _emit_t >= 0.25:
		_emit_t = 0.0
		changed.emit()
	_save_t += delta
	if _save_t >= 10.0:
		_save_t = 0.0
		save_game()


func _simulate(dt: float) -> void:
	if float(stock["coal"]) > 0.0:
		stock["coal"] = maxf(0.0, float(stock["coal"]) - coal_burn() * dt)
	var cap_v := float(storage_cap())
	for k in RES_KEYS:
		var net := prod_rate(k)
		if k == "food":
			net -= float(pop) * 0.03 * (0.85 if has_research("preservation") else 1.0)
		stock[k] = clampf(float(stock[k]) + net * dt, 0.0, cap_v)


func _life(dt: float) -> void:
	# البرد القارس يقتل الناجين
	if temp < -25.0:
		var shelter_relief := 1.0 + 0.35 * float(building_level("infirmary"))
		_cold_t += dt / shelter_relief
		if _cold_t >= 20.0 and pop > 2:
			_cold_t = 0.0
			pop -= 1
			_normalize_workers()
			toast.emit("مات أحد الناجين من البرد! زوّد الموقد بالفحم وارفع مستواه", true)
	else:
		_cold_t = maxf(0.0, _cold_t - dt)
	# الجوع
	if float(stock["food"]) <= 0.0:
		_starve_t += dt
		if _starve_t >= 15.0 and pop > 2:
			_starve_t = 0.0
			pop -= 1
			_normalize_workers()
			toast.emit("مات أحد الناجين من الجوع!", true)
	else:
		_starve_t = 0.0
	# نمو السكان
	if float(stock["food"]) > 5.0 and temp >= -25.0 and pop < pop_cap():
		_grow_t += dt
		if _grow_t >= 12.0:
			_grow_t = 0.0
			pop += 1
	else:
		_grow_t = 0.0


# ---------- السمعة والمجلس ----------

func fame_rank() -> int:
	var r := 0
	for i in FAME_RANKS.size():
		if fame >= int(FAME_RANKS[i][0]):
			r = i
	return r


func fame_title() -> String:
	return str(FAME_RANKS[fame_rank()][1])


func fame_mult() -> float:
	return 1.0 + 0.04 * float(fame_rank())


func loy_avg() -> float:
	var s := 0.0
	for a in ADVISOR_ORDER:
		s += float(loyalty[a])
	return s / float(ADVISOR_ORDER.size())


func loy_mult() -> float:
	var a := loy_avg()
	if a >= 70.0:
		return 1.1
	if a < 30.0:
		return 0.85
	return 1.0


func tribe_cooldown_left(tribe_id: String) -> float:
	if not TRIBES.has(tribe_id):
		return 0.0
	return maxf(0.0, float(tribal_cooldowns.get(tribe_id, 0.0)) - now())


func help_tribe(tribe_id: String) -> bool:
	if not TRIBES.has(tribe_id):
		return false
	var left := tribe_cooldown_left(tribe_id)
	if left > 0.0:
		toast.emit("سبق أن قدمتم الفزعة لهذه القبيلة. عودوا بعد %s" % fmt_time(left), true)
		return false
	var tribe: Dictionary = TRIBES[tribe_id]
	var cost: Dictionary = tribe["cost"]
	for key in cost:
		if not developer_mode and float(stock.get(key, 0.0)) < float(cost[key]):
			toast.emit("المؤن غير كافية لتلبية نداء هذه القبيلة", true)
			return false
	for key in cost:
		stock[key] = maxf(0.0, float(stock[key]) - float(cost[key]))
	var cap_v := float(storage_cap())
	var gift: Dictionary = tribe["gift"]
	for key in gift:
		stock[key] = minf(cap_v, float(stock[key]) + float(gift[key]))
	var rank_before := fame_rank()
	fame += int(tribe["fame"])
	tribal_relations[tribe_id] = mini(100, int(tribal_relations.get(tribe_id, 0)) + int(tribe["relation"]))
	tribal_cooldowns[tribe_id] = now() + FAZAA_COOLDOWN
	loyalty["sheikh"] = clampi(int(loyalty["sheikh"]) + 3, 0, 100)
	loyalty["faris"] = clampi(int(loyalty["faris"]) + 4, 0, 100)
	var msg := "وصلت فزعتكم إلى %s. ارتفعت العلاقة إلى %d%%، واكتسبتم %d سمعة." % [str(tribe["name"]), int(tribal_relations[tribe_id]), int(tribe["fame"])]
	if fame_rank() > rank_before:
		msg += " صارت سمعتكم: " + fame_title() + "."
	toast.emit(msg, false)
	changed.emit()
	save_game()
	return true



func mission_progress(mission: Dictionary) -> int:
	var kind := str(mission.get("kind", ""))
	match kind:
		"hearth":
			return hearth_level()
		"building":
			return building_level(str(mission.get("target_id", "")))
		"population":
			return pop
		"relation":
			var best := 0
			for tribe_id in tribal_relations:
				best = maxi(best, int(tribal_relations[tribe_id]))
			return best
		"fame":
			return fame
	return 0


func mission_done(mission: Dictionary) -> bool:
	return mission_progress(mission) >= int(mission.get("target", 0))


func claim_mission(mission_id: String) -> bool:
	for mission in MISSIONS:
		if str(mission["id"]) != mission_id:
			continue
		if mission_id in claimed_missions:
			toast.emit("استلمت مكافأة هذه المهمة مسبقاً", true)
			return false
		if not mission_done(mission):
			toast.emit("أكمل المهمة أولاً لتحصل على المكافأة", true)
			return false
		var cap_v := float(storage_cap())
		var reward: Dictionary = mission["reward"]
		var parts := PackedStringArray()
		for key in reward:
			var before := float(stock[key])
			stock[key] = minf(cap_v, before + float(reward[key]))
			var gained := int(float(stock[key]) - before)
			if gained > 0:
				parts.append("%s +%d" % [RES_NAMES[key], gained])
		claimed_missions.append(mission_id)
		toast.emit("أُنجزت مهمة «%s»! المكافأة: %s" % [mission["title"], "، ".join(parts)], false)
		changed.emit()
		save_game()
		return true
	return false


func achievement_progress(achievement: Dictionary) -> int:
	match str(achievement.get("kind", "")):
		"hearth":
			return hearth_level()
		"fame":
			return fame
		"population":
			return pop
		"relation":
			var best := 0
			for tribe_id in tribal_relations:
				best = maxi(best, int(tribal_relations.get(tribe_id, 0)))
			return best
		"buildings":
			var count := 0
			for i in range(1, plots.size()):
				if int(plots[i].get("level", 0)) > 0:
					count += 1
			return count
	return 0


func achievement_done(achievement: Dictionary) -> bool:
	return achievement_progress(achievement) >= int(achievement.get("target", 1))


func claim_achievement(achievement_id: String) -> bool:
	for achievement in ACHIEVEMENTS:
		if str(achievement.get("id", "")) != achievement_id:
			continue
		if achievement_id in claimed_achievements:
			toast.emit("استلمت مكافأة هذا الإنجاز مسبقاً", true)
			return false
		if not achievement_done(achievement):
			toast.emit("لم يكتمل الإنجاز بعد", true)
			return false
		var cap_v := float(storage_cap())
		var reward: Dictionary = achievement.get("reward", {})
		var parts := PackedStringArray()
		for key in reward:
			if not stock.has(key):
				continue
			var before := float(stock[key])
			stock[key] = minf(cap_v, before + float(reward[key]))
			var gained := int(float(stock[key]) - before)
			if gained > 0:
				parts.append("%s +%d" % [RES_NAMES[key], gained])
		claimed_achievements.append(achievement_id)
		toast.emit("إنجاز «%s»! المكافأة: %s" % [str(achievement.get("title", "")), "، ".join(parts) if not parts.is_empty() else "المخازن ممتلئة"], false)
		changed.emit()
		save_game()
		return true
	return false


func mark_intro_seen() -> void:
	intro_seen = true
	save_game()


func _post_event() -> void:
	var pick := ""
	if event_count == 0:
		pick = "guest"
	else:
		var pool := []
		for id in EVENTS:
			if id == last_event:
				continue
			if str(EVENTS[id]["cond"]) == "pop_room" and pop >= pop_cap():
				continue
			pool.append(id)
		if pool.is_empty():
			event_clock = 0.0
			return
		pick = str(pool[randi() % pool.size()])
	pending_event = pick
	last_event = pick
	event_clock = 0.0
	event_count += 1
	toast.emit("المجلس ينعقد: " + str(EVENTS[pick]["title"]), false)
	changed.emit()
	save_game()


func decide(idx: int) -> bool:
	if pending_event == "" or not EVENTS.has(pending_event):
		return false
	var ev: Dictionary = EVENTS[pending_event]
	var ch: Dictionary = ev["choices"][idx]
	var fx: Dictionary = ch["fx"]
	for k in RES_KEYS:
		if not developer_mode and float(fx.get(k, 0)) < 0.0 and float(stock[k]) < -float(fx[k]):
			toast.emit("الموارد غير كافية لهذا القرار", true)
			return false
	var cap_v := float(storage_cap())
	for k in RES_KEYS:
		if fx.has(k):
			stock[k] = clampf(float(stock[k]) + float(fx[k]), 0.0, cap_v)
	var msg: String = ch["result"]
	var rank_before := fame_rank()
	fame = maxi(0, fame + int(fx.get("fame", 0)))
	if fame_rank() > rank_before:
		msg += " — ارتفعت سمعتكم: " + fame_title()
	if fx.has("pop") and randf() <= float(fx.get("pop_p", 1.0)):
		var n := mini(int(fx["pop"]), maxi(0, pop_cap() - pop))
		if n > 0:
			pop += n
			msg += " — وانضم إليكم %d من الناجين" % n
	if fx.has("loy"):
		var ly: Dictionary = fx["loy"]
		for a in ly:
			if a == "all":
				for b in ADVISOR_ORDER:
					loyalty[b] = clampi(int(loyalty[b]) + int(ly[a]), 0, 100)
			else:
				loyalty[a] = clampi(int(loyalty[a]) + int(ly[a]), 0, 100)
	pending_event = ""
	event_clock = 0.0
	toast.emit(msg, false)
	changed.emit()
	save_game()
	return true


# ---------- حفظ وتحميل ----------

func save_game() -> void:
	var data := {
		"stock": stock, "plots": plots, "pop": pop,
		"exp_end": exp_end, "caravan_end": caravan_end, "caravan_route": caravan_route,
		"caravan_companions": caravan_companions, "caravan_food": caravan_food,
		"cavalry_count": cavalry_count, "cavalry_rank": cavalry_rank, "cavalry_tier": cavalry_tier,
		"infantry_count": infantry_count, "infantry_rank": infantry_rank, "infantry_tier": infantry_tier,
		"archer_count": archer_count, "archer_rank": archer_rank, "archer_tier": archer_tier, "researched": researched,
		"developer_mode": developer_mode,
		"storm": storm_clock, "last": now(),
		"fame": fame, "loyalty": loyalty, "pending_event": pending_event,
		"event_clock": event_clock, "event_count": event_count, "intro_seen": intro_seen,
		"tribal_relations": tribal_relations, "tribal_cooldowns": tribal_cooldowns,
		"claimed_missions": claimed_missions, "claimed_achievements": claimed_achievements,
		"settings": settings,
		"world_gathered": world_gathered, "world_caravans": world_caravans,
        "world_player_cities": world_player_cities, "world_node_balances": world_node_balances,
        "world_node_regen_times": world_node_regen_times, "world_map_views": world_map_views,
        "world_map_saved_locations": world_map_saved_locations,
	}
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(data))
		f.close()


func load_game() -> bool:
	if not FileAccess.file_exists(SAVE_PATH):
		return false
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return false
	var d = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(d) != TYPE_DICTIONARY:
		return false
	var arr: Array = d.get("plots", [])
	if arr.is_empty() or arr.size() > PLOT_COUNT:
		return false
	var s: Dictionary = d.get("stock", {})
	for k in RES_KEYS:
		stock[k] = float(s.get(k, 0.0))
	plots = []
	for e in arr:
		plots.append({
			"type": str(e.get("type", "")),
			"level": clampi(int(e.get("level", 0)), 0, MAX_HEARTH if str(e.get("type", "")) == "hearth" else MAX_LEVEL_OTHER),
			"to": clampi(int(e.get("to", 0)), 0, MAX_HEARTH if str(e.get("type", "")) == "hearth" else MAX_LEVEL_OTHER),
			"end": float(e.get("end", 0.0)),
			"workers": int(e.get("workers", 0)),
		})
	while plots.size() < PLOT_COUNT:
		plots.append({"type": "", "level": 0, "to": 0, "end": 0.0, "workers": 0})
	pop = int(d.get("pop", 6))
	exp_end = float(d.get("exp_end", 0.0))
	caravan_end = float(d.get("caravan_end", 0.0))
	caravan_route = str(d.get("caravan_route", ""))
	caravan_companions = int(d.get("caravan_companions", 0))
	caravan_food = int(d.get("caravan_food", 0))
	cavalry_count = maxi(0, int(d.get("cavalry_count", 0)))
	infantry_count = maxi(0, int(d.get("infantry_count", 0)))
	archer_count = maxi(0, int(d.get("archer_count", 0)))
	cavalry_rank = clampi(int(d.get("cavalry_rank", 1)), 1, MILITARY_RANKS_PER_TIER)
	cavalry_tier = clampi(int(d.get("cavalry_tier", 0)), 0, 3)
	infantry_rank = clampi(int(d.get("infantry_rank", 1)), 1, MILITARY_RANKS_PER_TIER)
	infantry_tier = clampi(int(d.get("infantry_tier", 0)), 0, 3)
	archer_rank = clampi(int(d.get("archer_rank", 1)), 1, MILITARY_RANKS_PER_TIER)
	archer_tier = clampi(int(d.get("archer_tier", 0)), 0, 3)
	developer_mode = bool(d.get("developer_mode", false))
	researched = d.get("researched", [])
	if typeof(researched) != TYPE_ARRAY:
		researched = []
	var valid_research: Array = []
	for tech_id in researched:
		if RESEARCHES.has(str(tech_id)) and str(tech_id) not in valid_research:
			valid_research.append(str(tech_id))
	researched = valid_research
	if caravan_route != "" and not CARAVAN_ROUTES.has(caravan_route):
		caravan_end = 0.0
		caravan_route = ""
		caravan_companions = 0
		caravan_food = 0
	storm_clock = float(d.get("storm", 0.0))
	fame = int(d.get("fame", 0))
	var ly: Dictionary = d.get("loyalty", {})
	for a in ADVISOR_ORDER:
		loyalty[a] = int(ly.get(a, 50))
	pending_event = str(d.get("pending_event", ""))
	if pending_event != "" and not EVENTS.has(pending_event):
		pending_event = ""
	event_clock = float(d.get("event_clock", 0.0))
	event_count = int(d.get("event_count", 0))
	intro_seen = bool(d.get("intro_seen", false))
	var tribal_relation_data: Dictionary = d.get("tribal_relations", {})
	var tc: Dictionary = d.get("tribal_cooldowns", {})
	for tribe_id in TRIBES:
		tribal_relations[tribe_id] = clampi(int(tribal_relation_data.get(tribe_id, 0)), 0, 100)
		tribal_cooldowns[tribe_id] = float(tc.get(tribe_id, 0.0))
	claimed_missions = d.get("claimed_missions", [])
	claimed_achievements = d.get("claimed_achievements", [])
	settings = d.get("settings", {"muted": false, "effects": true, "ambience": true, "graphics_quality": "medium", "profile": {"name":"قائد الموقد", "tribe":"قبيلة الصقيع", "emblem":"❄", "color":"#D99A45"}})
	if typeof(settings) != TYPE_DICTIONARY: settings = {"muted": false, "effects": true, "ambience": true, "graphics_quality": "medium"}
	settings["muted"] = bool(settings.get("muted", false)); settings["effects"] = bool(settings.get("effects", true)); settings["ambience"] = bool(settings.get("ambience", true)); settings["graphics_quality"] = str(settings.get("graphics_quality", "medium"))
	world_gathered = d.get("world_gathered", {})
	if typeof(world_gathered) != TYPE_DICTIONARY:
		world_gathered = {}
	world_caravans = d.get("world_caravans", [])
	world_player_cities = d.get("world_player_cities", {})
	world_node_balances = d.get("world_node_balances", {})
	world_node_regen_times = d.get("world_node_regen_times", {})
	world_map_views = d.get("world_map_views", {})
	world_map_saved_locations = d.get("world_map_saved_locations", {})
	if typeof(world_player_cities) != TYPE_DICTIONARY: world_player_cities = {}
	if typeof(world_node_balances) != TYPE_DICTIONARY: world_node_balances = {}
	if typeof(world_node_regen_times) != TYPE_DICTIONARY: world_node_regen_times = {}
	if typeof(world_map_views) != TYPE_DICTIONARY: world_map_views = {}
	if typeof(world_map_saved_locations) != TYPE_DICTIONARY: world_map_saved_locations = {}
	world_map_cache.clear()
	if typeof(world_caravans) != TYPE_ARRAY:
		world_caravans = []
	if typeof(world_gathered) != TYPE_DICTIONARY:
		world_gathered = {}
	var has_w := false
	for e2 in arr:
		if e2.has("workers"):
			has_w = true
	if has_w:
		_normalize_workers()
	else:
		auto_assign()
	var away := now() - float(d.get("last", now()))
	if away > 30.0:
		_apply_offline(minf(away, 8.0 * 3600.0))
	return true


func _apply_offline(sec: float) -> void:
	var t := now()
	for i in PLOT_COUNT:
		var p: Dictionary = plots[i]
		if float(p["end"]) > 0.0 and t >= float(p["end"]):
			_finish(i, true)
	if exp_end > 0.0 and t >= exp_end:
		_finish_expedition()
	if caravan_end > 0.0 and t >= caravan_end:
		finish_caravan()
	_process_world_caravans(t)
	var cap_v := float(storage_cap())
	var lvl := hearth_level()
	for k in RES_KEYS:
		var net := _raw_rate(k) * 0.5
		if k == "food":
			net -= float(pop) * 0.03 * (0.85 if has_research("preservation") else 1.0) * 0.5
		if k == "coal":
			net -= 0.08 * float(lvl) * keeper_factor() * 0.5
		stock[k] = clampf(float(stock[k]) + net * sec, 0.0, cap_v)
	pending_msg = "مرحباً بعودتك! واصلت المدينة العمل أثناء غيابك."


func province_open_threshold() -> int:
	return int(round(float(PROVINCE_CAPACITY) * PROVINCE_OPEN_THRESHOLD))


func province_name(province_id: String) -> String:
	for province in WORLD_PROVINCES:
		if str(province.get("id", "")) == province_id:
			return str(province.get("name", "مقاطعة"))
	return "مقاطعة"

func province_data() -> Array:
	# نموذج التصميم يعرض خمس مقاطعات أولية. أعداد المدن الحقيقية لا يمكن حسابها قبل السيرفر.
	var out: Array = []
	for province in WORLD_PROVINCES:
		out.append(province.duplicate(true))
	return out


func world_province_seed(province_id: String) -> int:
	for i in range(WORLD_PROVINCES.size()):
		if str(WORLD_PROVINCES[i].get("id", "")) == province_id:
			return 74129 + i * 991
	return 74129 + posmod(int(hash(province_id)), 10000)


func _world_node_key(province_id: String, node_id: String) -> String:
	return province_id + "|" + node_id


func world_resource_tier(x: int, y: int, province_id: String) -> int:
	# مصدر وحيد لمستوى المورد، تستخدمه اللعبة والخريطة معًا.
	var seed_value: int = posmod(int(hash(province_id)), WORLD_RESOURCE_SEED_MODULUS)
	var dx: float = float(x - WORLD_MAP_CENTER) / WORLD_RESOURCE_DISTANCE_NORMALIZER
	var dy: float = float(y - WORLD_MAP_CENTER) / WORLD_RESOURCE_DISTANCE_NORMALIZER
	var noise: float = sin(float(x) * WORLD_RESOURCE_X_NOISE_FREQUENCY + float(seed_value)) * WORLD_RESOURCE_X_NOISE_AMPLITUDE + cos(float(y) * WORLD_RESOURCE_Y_NOISE_FREQUENCY) * WORLD_RESOURCE_Y_NOISE_AMPLITUDE
	var distance_ratio: float = sqrt(dx * dx + dy * dy) + noise
	if distance_ratio > WORLD_RESOURCE_OUTER_TIER_THRESHOLD:
		return 1 + posmod(x + y, 3)
	if distance_ratio > WORLD_RESOURCE_MIDDLE_TIER_THRESHOLD:
		return 4 + posmod(x * 3 + y, 3)
	return 7 + posmod(x + y * 3, 2)


func world_resource_kind(x: int, y: int) -> String:
	# مصدر وحيد لنوع المورد؛ يجب ألا تنسخ هذه المعادلة إلى سكربت الخريطة.
	var resources: Array[String] = ["wood", "iron", "coal", "food"]
	return resources[posmod(x * WORLD_RESOURCE_TYPE_X_MULTIPLIER + y * WORLD_RESOURCE_TYPE_Y_MULTIPLIER, resources.size())]


func world_node_base_info(node_id: String, province_id: String = "north_ridge") -> Dictionary:
	if not node_id.begins_with("node_"):
		return world_node_info_legacy(node_id)
	var parts: PackedStringArray = node_id.split("_")
	if parts.size() != 3 or not parts[1].is_valid_int() or not parts[2].is_valid_int():
		return {}
	var x: int = clampi(int(parts[1]), 0, WORLD_MAP_SIZE - 1)
	var y: int = clampi(int(parts[2]), 0, WORLD_MAP_SIZE - 1)
	var tier: int = world_resource_tier(x, y, province_id)
	var kind: String = world_resource_kind(x, y)
	var names: Dictionary = {"wood":"غابة خشب", "iron":"منجم حديد", "coal":"منجم فحم", "food":"مؤن"}
	var max_amount: int = tier * WORLD_NODE_BASE_STOCK
	return {"id":node_id, "x":x, "y":y, "tier":tier, "resource":kind, "name":str(names.get(kind,"مورد")), "max_amount":max_amount, "amount":max_amount, "distance":0, "province_id":province_id}


func world_node_info(node_id: String, province_id: String = "north_ridge") -> Dictionary:
	# يعيد البيانات المشتركة نفسها للخريطة ولمنطق القافلة، مع الرصيد المتبقي.
	if not node_id.begins_with("node_"):
		return world_node_info_legacy(node_id)
	var info: Dictionary = world_node_base_info(node_id, province_id)
	if info.is_empty():
		return {}
	var key: String = _world_node_key(province_id, node_id)
	var max_amount: int = int(info.get("max_amount", 0))
	var remaining: int = int(world_node_balances.get(key, max_amount))
	if world_node_balances.has(key):
		var last_regen: float = float(world_node_regen_times.get(key, now()))
		var cycles: int = int(maxf(0.0, now() - last_regen) / WORLD_NODE_RESPAWN)
		if cycles > 0:
			remaining = mini(max_amount, remaining + cycles * maxi(1, int(ceil(float(max_amount) * WORLD_NODE_REGEN_FRACTION))))
			world_node_balances[key] = remaining
			world_node_regen_times[key] = last_regen + float(cycles) * WORLD_NODE_RESPAWN
	info["amount"] = remaining
	info["distance"] = 0
	return info


func world_node_info_legacy(node_id: String) -> Dictionary:
	# الحفاظ على معرّفات المواقع القديمة التي قد تكون محفوظة في نسخة سابقة.
	var resources: Array[String] = ["wood", "iron", "coal", "food"]
	var names: Dictionary = {"wood":"غابة الخشب", "iron":"منجم الحديد", "coal":"حقل الفحم", "food":"مخزن المؤن"}
	for i in range(56):
		if node_id == "world_%02d" % i:
			var ring: int = floori(float(i) / 8.0)
			var tier: int = 1 if ring == 0 else (2 if ring == 1 else (3 if ring == 2 else (4 if ring == 3 else (5 if ring == 4 else (6 if ring == 5 else 7)))))
			var kind: String = resources[i % resources.size()]
			return {"id":node_id,"tier":tier,"resource":kind,"name":str(names[kind]),"amount":tier * WORLD_NODE_BASE_STOCK,"distance":int((7-ring)*18+20)}
	return {}


func get_or_create_player_city_position(province_id: String, seed_value: int, occupied: Array = []) -> Vector2i:
	# موضع ثابت ومحفوظ لكل مقاطعة، مع فحص العرش والمدن التجريبية.
	if world_player_cities.has(province_id) and typeof(world_player_cities[province_id]) == TYPE_DICTIONARY:
		var saved: Dictionary = world_player_cities[province_id]
		return Vector2i(clampi(int(saved.get("x", WORLD_MAP_CENTER)), 2, WORLD_MAP_SIZE - 4), clampi(int(saved.get("y", WORLD_MAP_CENTER)), 2, WORLD_MAP_SIZE - 4))
	var rng := RandomNumberGenerator.new()
	rng.seed = int(hash(province_id)) ^ seed_value ^ 0x6F31A2
	var chosen := Vector2i(600, 600)
	for attempt in range(WORLD_PLAYER_CITY_PLACEMENT_ATTEMPTS):
		var angle: float = rng.randf_range(0.0, TAU)
		var radius: float = rng.randf_range(WORLD_PLAYER_CITY_MIN_RADIUS, WORLD_PLAYER_CITY_MAX_RADIUS)
		var candidate := Vector2i(clampi(roundi(float(WORLD_MAP_CENTER) + cos(angle) * radius), 2, WORLD_MAP_SIZE - 4), clampi(roundi(float(WORLD_MAP_CENTER) + sin(angle) * radius), 2, WORLD_MAP_SIZE - 4))
		if candidate.x >= 596 and candidate.x <= 601 and candidate.y >= 596 and candidate.y <= 601:
			continue
		var free := true
		for item in occupied:
			if abs(int(item.get("x", -100)) - candidate.x) < 3 and abs(int(item.get("y", -100)) - candidate.y) < 3:
				free = false
				break
		if free:
			chosen = candidate
			break
	world_player_cities[province_id] = {"x":chosen.x,"y":chosen.y}
	save_game()
	return chosen


func update_world_map_view(province_id: String, x: int, y: int, zoom: float) -> void:
	# تحديث ذاكرة موضع الكاميرا بلا كتابة قرص في كل إطار أثناء السحب.
	world_map_views[province_id] = {"x":clampi(x,0,WORLD_MAP_SIZE-1),"y":clampi(y,0,WORLD_MAP_SIZE-1),"zoom":clampf(zoom,6.0,1200.0)}


func save_world_map_view(province_id: String, x: int, y: int, zoom: float) -> void:
	update_world_map_view(province_id, x, y, zoom)
	save_game()


func get_world_map_view(province_id: String) -> Dictionary:
	var value = world_map_views.get(province_id, {})
	if typeof(value) == TYPE_DICTIONARY:
		return value.duplicate(true)
	return {}


func set_world_map_saved_locations(province_id: String, locations: Array) -> void:
	world_map_saved_locations[province_id] = locations.duplicate(true)
	save_game()


func get_world_map_saved_locations(province_id: String) -> Array:
	var value = world_map_saved_locations.get(province_id, [])
	return value.duplicate(true) if typeof(value) == TYPE_ARRAY else []


func world_node_ready(node_id: String, province_id: String = "north_ridge") -> bool:
	var n: Dictionary = world_node_info(node_id, province_id)
	return not n.is_empty() and int(n.get("amount", 0)) > 0


func send_world_caravan(node_id: String, province_id: String = "north_ridge") -> bool:
	var n: Dictionary = world_node_info(node_id, province_id)
	if n.is_empty():
		toast.emit("تعذر العثور على هذا المورد.", true)
		return false
	for active in world_caravans:
		if str(active.get("node_id", "")) == node_id and str(active.get("province_id", "north_ridge")) == province_id:
			toast.emit("هناك قافلة تعمل على هذا المورد بالفعل.", true)
			return false
	var yard: int = building_level("caravan_yard")
	if yard <= 0:
		toast.emit("يجب بناء مرسى القوافل أولًا لإرسال قافلة.", true)
		return false
	var max_active: int = mini(WORLD_CARAVAN_MAX_CONCURRENT, 1 + yard)
	if world_caravans.size() >= max_active:
		toast.emit("جميع القوافل المتاحة مشغولة حاليًا.", true)
		return false
	var remaining: int = int(n.get("amount", 0))
	if remaining <= 0:
		toast.emit("هذا المورد نفد مؤقتًا؛ سيعود تدريجيًا.", true)
		return false
	var city: Vector2i = get_or_create_player_city_position(province_id, world_province_seed(province_id))
	var target := Vector2i(int(n.get("x", 600)), int(n.get("y", 600)))
	var distance: float = Vector2(float(city.x), float(city.y)).distance_to(Vector2(float(target.x), float(target.y)))
	var capacity: int = WORLD_CARAVAN_BASE_CAPACITY + yard * WORLD_CARAVAN_YARD_CAPACITY
	var planned_amount: int = mini(capacity, remaining)
	var food_cost: int = maxi(WORLD_CARAVAN_MIN_FOOD_COST, int(ceil(distance / WORLD_CARAVAN_FOOD_DISTANCE_UNIT * WORLD_CARAVAN_FOOD_PER_100_CELLS)))
	if float(stock.get("food", 0.0)) < float(food_cost):
		toast.emit("الطعام غير كافٍ لمؤونة الطريق (%d طعام)." % food_cost, true)
		return false
	stock["food"] = float(stock.get("food", 0.0)) - float(food_cost)
	var time_multiplier: float = maxf(WORLD_CARAVAN_MIN_TIME_MULTIPLIER, 1.0 - WORLD_CARAVAN_STABLE_TIME_REDUCTION_PER_LEVEL * float(building_level("stable")))
	if has_research("logistics"):
		time_multiplier *= 0.85
	if is_storm():
		time_multiplier *= WORLD_CARAVAN_STORM_TIME_MULTIPLIER
	var round_trip_seconds: float = maxf(WORLD_CARAVAN_MIN_TRIP_SECONDS, distance * WORLD_CARAVAN_TIME_PER_CELL * WORLD_CARAVAN_ROUND_TRIP_MULTIPLIER * time_multiplier)
	var risk: float = clampf(WORLD_CARAVAN_BASE_RISK + distance / WORLD_CARAVAN_RISK_PER_CELL_DIVISOR - WORLD_CARAVAN_GUARD_REDUCTION * float(building_level("guard_post")) - minf(WORLD_CARAVAN_CAVALRY_REDUCTION_CAP, float(cavalry_power()) * WORLD_CARAVAN_CAVALRY_REDUCTION) - (WORLD_CARAVAN_MEDICINE_REDUCTION if has_research("field_medicine") else 0.0), WORLD_CARAVAN_MIN_RISK, WORLD_CARAVAN_MAX_RISK)
	if is_storm():
		risk = minf(WORLD_CARAVAN_MAX_RISK, risk + WORLD_CARAVAN_STORM_RISK)
	var caravan_id: String = "wc_%d_%d" % [Time.get_ticks_msec(), randi_range(1000,9999)]
	world_caravans.append({"id":caravan_id,"node_id":node_id,"province_id":province_id,"resource":str(n.get("resource","wood")),"amount":planned_amount,"start":now(),"finish":now()+round_trip_seconds,"tier":int(n.get("tier",1)),"distance":distance,"capacity":capacity,"food_cost":food_cost,"risk":risk,"stage":"outbound","player_x":city.x,"player_y":city.y,"target_x":target.x,"target_y":target.y})
	save_game()
	changed.emit()
	toast.emit("انطلقت قافلة لجمع %s؛ الحمولة القصوى %d والعودة خلال %s." % [str(n.get("name","المورد")), planned_amount, fmt_time(round_trip_seconds)], false)
	return true


func _process_world_caravans(t: float) -> void:
	var changed_any := false
	for i in range(world_caravans.size() - 1, -1, -1):
		var c: Dictionary = world_caravans[i]
		var finish_time: float = float(c.get("finish", 0.0))
		if t < finish_time:
			continue
		var key: String = str(c.get("resource", "wood"))
		var node_key: String = _world_node_key(str(c.get("province_id", "north_ridge")), str(c.get("node_id", "")))
		var info: Dictionary = world_node_base_info(str(c.get("node_id", "")), str(c.get("province_id", "north_ridge")))
		var maximum: int = int(info.get("max_amount", int(c.get("amount", 0))))
		var remaining: int = int(world_node_balances.get(node_key, maximum))
		# طبّق كل دورات التجدد التي انقضت قبل حساب حمولة القافلة وخصمها.
		# نحافظ على الجزء المتبقي من دورة التجدد بدل تصفير الساعة عند كل عودة.
		var regen_time: float = float(world_node_regen_times.get(node_key, t))
		if world_node_balances.has(node_key):
			var elapsed_cycles: int = int(maxf(0.0, t - regen_time) / WORLD_NODE_RESPAWN)
			if elapsed_cycles > 0:
				var regen_per_cycle: int = maxi(1, int(ceil(float(maximum) * WORLD_NODE_REGEN_FRACTION)))
				remaining = mini(maximum, remaining + elapsed_cycles * regen_per_cycle)
				regen_time += float(elapsed_cycles) * WORLD_NODE_RESPAWN
		world_node_regen_times[node_key] = regen_time
		var safe_capacity: int = int(c.get("capacity", WORLD_CARAVAN_BASE_CAPACITY + building_level("caravan_yard") * WORLD_CARAVAN_YARD_CAPACITY))
		var collected: int = mini(safe_capacity, mini(int(c.get("amount", 0)), remaining))
		var risk: float = clampf(float(c.get("risk", WORLD_CARAVAN_BASE_RISK)), 0.0, WORLD_CARAVAN_MAX_RISK)
		var loss_fraction: float = 0.0
		if randf() < risk:
			loss_fraction = randf_range(WORLD_CARAVAN_LOSS_MIN_FRACTION, WORLD_CARAVAN_LOSS_MAX_FRACTION) * (WORLD_CARAVAN_STORM_LOSS_MULTIPLIER if is_storm() else 1.0)
		var lost: int = mini(collected, int(ceil(float(collected) * clampf(loss_fraction, 0.0, 0.9))) if loss_fraction > 0.0 else 0)
		var delivered: int = maxi(0, collected - lost)
		var added: int = mini(delivered, maxi(0, storage_cap() - int(stock.get(key, 0))))
		stock[key] = int(stock.get(key, 0)) + added
		world_node_balances[node_key] = maxi(0, remaining - collected)
		world_gathered[node_key] = now()
		world_caravans.remove_at(i)
		if lost > 0:
			toast.emit("عادت القافلة بعد خطر الطريق؛ فُقد %d من الحمولة ووصل %d." % [lost, added], true)
		else:
			toast.emit("عادت القافلة ومعها %d من %s." % [added, str(RES_NAMES.get(key, key))], false)
		changed_any = true
	if changed_any:
		save_game()
		changed.emit()


func active_world_caravan_count() -> int:
	return world_caravans.size()


func gather_world_node(province_id: String, node_id: String) -> bool:
	return send_world_caravan(node_id, province_id)


func developer_grant_resources() -> void:
	if not developer_mode: return
	for key in RES_KEYS: stock[key] = 999999.0
	pop = 50
	fame = 9999
	changed.emit(); save_game()

func developer_unlock_research() -> void:
	if not developer_mode: return
	researched.clear()
	for tech_id in RESEARCHES: researched.append(tech_id)
	changed.emit(); save_game()

func developer_finish_all_construction() -> void:
	if not developer_mode: return
	for i in range(plots.size()):
		if float(plots[i].get("end", 0.0)) > 0.0: _finish(i, true)
	structure_changed.emit(); changed.emit(); save_game()

func developer_unlock_military() -> void:
	if not developer_mode: return
	cavalry_count = cavalry_capacity()
	cavalry_tier = 3
	cavalry_rank = MILITARY_RANKS_PER_TIER
	changed.emit(); save_game()

func reset_game() -> void:
	_new_game()
	world_gathered.clear()
	world_caravans.clear()
	world_player_cities.clear()
	world_node_balances.clear()
	world_node_regen_times.clear()
	world_map_views.clear()
	world_map_saved_locations.clear()
	world_map_cache.clear()
	save_game()
	structure_changed.emit()
	changed.emit()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED:
		save_game()
