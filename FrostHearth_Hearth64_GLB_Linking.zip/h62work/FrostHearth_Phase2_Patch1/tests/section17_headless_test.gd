extends SceneTree

const WORLD_MAP_SCREEN = preload("res://scripts/world_map_screen.gd")

var failed := false
var had_previous_save := false
var previous_save_text := ""

func _initialize() -> void:
	call_deferred("_run_tests")

func _run_tests() -> void:
	_backup_save_file()
	await _test_world_map_hud()
	_test_caravan_balance()
	_test_city_and_resource_save_load()
	_restore_save_file()
	if failed:
		push_error("SECTION17_HEADLESS_TEST: FAILED")
		quit(1)
	else:
		print("SECTION17_HEADLESS_TEST: PASS")
		quit(0)

func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		push_error("SECTION17_HEADLESS_TEST: " + message)
	else:
		print("PASS: " + message)

func _test_world_map_hud() -> void:
	var screen: Control = WORLD_MAP_SCREEN.new()
	root.add_child(screen)
	await process_frame
	_check(is_instance_valid(screen.get("hud")), "world map HUD was built in _ready")
	_check(is_instance_valid(screen.get("action_button")), "world map action button exists")
	screen.queue_free()
	await process_frame

func _test_caravan_balance() -> void:
	# استخدم موردًا على بعد 6 خانات من المدينة؛ مع حمولة مرسى مستوى 1
	# تكون مدة الذهاب والإياب 48 ثانية وعائد الحمولة المخطط نحو 2.9 مورد/ثانية.
	# اجعل شروط الاختبار ثابتة حتى لا تؤثر بيانات حفظ سابقة في النتيجة.
	GameState.plots = []
	for i in range(GameState.PLOT_COUNT):
		GameState.plots.append({"type":"", "level":0, "to":0, "end":0.0, "workers":0})
	GameState.plots[1]["type"] = "caravan_yard"
	GameState.plots[1]["level"] = 1
	GameState.researched = []
	GameState.storm_clock = 0.0
	var city: Vector2i = GameState.get_or_create_player_city_position("north_ridge", GameState.world_province_seed("north_ridge"))
	var target := city + Vector2i(6 if city.x < 1190 else -6, 0)
	var node_id := "node_%d_%d" % [target.x, target.y]
	var node_info: Dictionary = GameState.world_node_base_info(node_id, "north_ridge")
	_check(not node_info.is_empty(), "nearest-route test resource exists")
	if node_info.is_empty():
		return
	var yard_slot := -1
	for i in range(GameState.plots.size()):
		if str(GameState.plots[i].get("type", "")) == "caravan_yard":
			yard_slot = i
			break
	if yard_slot < 0:
		for i in range(GameState.plots.size()):
			if str(GameState.plots[i].get("type", "")) == "":
				yard_slot = i
				break
	_check(yard_slot >= 0, "a plot is available for the test caravan yard")
	if yard_slot < 0:
		return
	GameState.plots[yard_slot]["type"] = "caravan_yard"
	GameState.plots[yard_slot]["level"] = 1
	GameState.stock["food"] = 10000.0
	GameState.world_caravans.clear()
	var key: String = GameState._world_node_key("north_ridge", node_id)
	GameState.world_node_balances.erase(key)
	GameState.world_node_regen_times.erase(key)
	var started: bool = GameState.send_world_caravan(node_id, "north_ridge")
	_check(started, "caravan can be sent for the test resource")
	if not started or GameState.world_caravans.is_empty():
		return
	var caravan: Dictionary = GameState.world_caravans.back()
	var duration: float = float(caravan.get("finish", 0.0)) - float(caravan.get("start", 0.0))
	var yield_per_second: float = float(caravan.get("amount", 0)) / maxf(duration, 0.001)
	_check(duration >= 30.0, "caravan duration respects the 30-second minimum")
	_check(yield_per_second >= 1.0 and yield_per_second <= 3.0, "planned caravan yield is 1–3 resources/second (%.3f)" % yield_per_second)

func _test_city_and_resource_save_load() -> void:
	var province_id := "north_ridge"
	var city: Vector2i = GameState.get_or_create_player_city_position(province_id, GameState.world_province_seed(province_id))
	var node_id := "node_%d_%d" % [city.x + 9, city.y]
	var key: String = GameState._world_node_key(province_id, node_id)
	GameState.world_node_balances[key] = 123
	GameState.world_node_regen_times[key] = GameState.now()
	GameState.save_game()
	GameState.world_player_cities.erase(province_id)
	GameState.world_node_balances.erase(key)
	var loaded: bool = GameState.load_game()
	_check(loaded, "save file loads successfully")
	_check(GameState.get_or_create_player_city_position(province_id, GameState.world_province_seed(province_id)) == city, "player city position survives save/load")
	_check(int(GameState.world_node_balances.get(key, -1)) == 123, "resource balance survives save/load")

func _backup_save_file() -> void:
	if FileAccess.file_exists(GameState.SAVE_PATH):
		var file := FileAccess.open(GameState.SAVE_PATH, FileAccess.READ)
		if file != null:
			had_previous_save = true
			previous_save_text = file.get_as_text()
			file.close()

func _restore_save_file() -> void:
	if had_previous_save:
		var file := FileAccess.open(GameState.SAVE_PATH, FileAccess.WRITE)
		if file != null:
			file.store_string(previous_save_text)
			file.close()
	else:
		var absolute_path := ProjectSettings.globalize_path(GameState.SAVE_PATH)
		if FileAccess.file_exists(GameState.SAVE_PATH):
			DirAccess.remove_absolute(absolute_path)
