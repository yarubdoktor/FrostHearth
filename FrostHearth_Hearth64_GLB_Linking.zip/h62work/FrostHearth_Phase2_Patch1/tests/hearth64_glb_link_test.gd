extends SceneTree
## اختبار ربط GLB (Hearth64). التشغيل:
## godot --headless --path . --script res://tests/hearth64_glb_link_test.gd

const MAIN = preload("res://scripts/main.gd")

var failed := false


func _initialize() -> void:
	call_deferred("_run_tests")


func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		push_error("FAIL: " + message)


func _run_tests() -> void:
	for type in MAIN.GLB_MODELS.keys():
		var e: Dictionary = MAIN.GLB_MODELS[type]
		var path := str(e["path"])
		var fit := float(e["fit"])
		var max_h := float(e["max_h"])
		_check(ResourceLoader.exists(path), "%s: الملف غير موجود/غير مستورد: %s" % [type, path])
		var packed := load(path) as PackedScene
		_check(packed != null, "%s: فشل التحميل كـ PackedScene" % type)
		if packed == null:
			continue
		var model := packed.instantiate() as Node3D
		_check(model != null, "%s: الجذر ليس Node3D" % type)
		if model == null:
			continue
		var meshes := model.find_children("*", "MeshInstance3D", true, false)
		_check(meshes.size() > 0, "%s: لا يحتوي MeshInstance3D" % type)
		var info: Dictionary = MAIN.glb_fit_info(model, path, fit, max_h)
		var s: float = info["scale"]
		var pos: Vector3 = info["position"]
		var bb: AABB = info["bounds"]
		var size: Vector3 = info["size"]
		var bottom := pos.y + bb.position.y * s
		_check(absf(bottom - MAIN.G) < 0.01, "%s: القاعدة ليست على y=G (الفعلي %.3f)" % [type, bottom])
		if fit > 0.0:
			_check(maxf(size.x, size.z) <= fit + 0.02, "%s: البصمة %.2f أكبر من fit=%.2f" % [type, maxf(size.x, size.z), fit])
		if max_h > 0.0:
			_check(size.y <= max_h + 0.02, "%s: الارتفاع %.2f أكبر من max_h=%.2f" % [type, size.y, max_h])
		# كل سطح بلا خامة يجب أن يحصل على خامة ألوان الرؤوس.
		MAIN._fix_glb_materials(model)
		for mi in meshes:
			var m := mi as MeshInstance3D
			for i in m.mesh.get_surface_count():
				var has_mat: bool = m.mesh.surface_get_material(i) != null or m.get_surface_override_material(i) != null
				_check(has_mat, "%s: سطح بلا خامة في %s" % [type, m.name])
		print("%s: meshes=%d scale=%.2f size=%s" % [type, meshes.size(), s, str(size)])
		model.free()
	if failed:
		push_error("HEARTH64_GLB_LINK_TEST: FAILED")
		quit(1)
	else:
		print("HEARTH64_GLB_LINK_TEST: PASS")
		quit(0)
