extends SceneTree

const UITheme = preload("res://scripts/ui/ui_theme.gd")
var failures: Array[String] = []

func _initialize() -> void:
	_run_test.call_deferred()

func _run_test() -> void:
	var packed := load("res://scenes/main.tscn") as PackedScene
	if packed == null:
		_fail("تعذر تحميل المشهد الرئيسي")
		_finish()
		return
	var game := packed.instantiate()
	root.add_child(game)
	for _i in 8:
		await process_frame
	var ui := _find_ui(game)
	if ui == null:
		_fail("لم يتم العثور على واجهة ui.gd")
		_finish()
		return
	if not ui.has_method("show_plot") or not ui.has_method("hide_panel") or not ui.has_method("is_over_ui") or not ui.has_method("show_world_map") or not ui.has_method("close_world_map") or not ui.has_method("show_toast"):
		_fail("واجهة التوافق لا تحتوي كل الدوال المطلوبة")
	var nav: Dictionary = ui.get("nav_buttons")
	for key in ["city", "tribe", "research", "map", "more"]:
		if not nav.has(key):
			_fail("قسم تنقل مفقود: " + key)
	if nav.size() != 5:
		_fail("عدد أقسام التنقل ليس خمسة")
	var old_stock: Dictionary = GameState.stock.duplicate(true)
	var old_storm_clock: float = GameState.storm_clock
	var old_pending_event: String = GameState.pending_event
	var old_pop: int = GameState.pop
	GameState.stock["coal"] = 10000.0
	GameState.storm_clock = 0.0
	GameState.pending_event = ""
	GameState.pop = 0
	var before := str(ui.get("goal_title").text)
	var claimed: Array = GameState.claimed_missions.duplicate()
	var first_id := str(GameState.MISSIONS[0].get("id", ""))
	if not first_id in GameState.claimed_missions:
		GameState.claimed_missions.append(first_id)
	ui.call("_refresh_goal")
	var after := str(ui.get("goal_title").text)
	GameState.claimed_missions = claimed
	GameState.stock = old_stock
	GameState.storm_clock = old_storm_clock
	GameState.pending_event = old_pending_event
	GameState.pop = old_pop
	ui.call("_refresh_goal")
	if before == after and GameState.MISSIONS.size() > 1:
		_fail("شريط الهدف لم يتغير عند تغير المهمة الحالية")
	ui.call("_enforce_ui_minimums", ui.get("root"))
	_check_tree(ui.get("root"), ui)
	ui.call("show_world_map")
	for _map_frame in 4:
		await process_frame
	var map_screen := ui.get("world_map_screen") as Control
	if map_screen == null or not is_instance_valid(map_screen):
		_fail("شاشة الخريطة لم تُنشأ")
	else:
		map_screen.call("_enforce_map_minimums", map_screen.get("hud"))
		_check_tree(map_screen, ui)
		ui.call("close_world_map")
	var safe: Rect2 = ui.get("safe_rect")
	for property_name in ["top_panel", "goal_panel", "bottom_row"]:
		var control := ui.get(property_name) as Control
		if control != null and control.is_visible_in_tree():
			var rect := control.get_global_rect()
			if rect.position.x < -1 or rect.end.x > root.get_visible_rect().size.x + 1:
				_fail(property_name + " يتجاوز حدود العرض")
		if control != null and property_name == "top_panel" and control.get_global_rect().position.y < safe.position.y - 2:
			_fail("الشريط العلوي يتجاوز المنطقة الآمنة")
		if control != null and property_name in ["goal_panel", "bottom_row"] and control.get_global_rect().end.y > safe.end.y + 2:
			_fail(property_name + " يتجاوز المنطقة الآمنة السفلية")
	if failures.is_empty():
		print("SECTION18_UI_TEST_PASS")
		game.queue_free()
		quit(0)
	else:
		for message in failures:
			push_error(message)
		game.queue_free()
		quit(1)

func _find_ui(node: Node) -> Node:
	if node.has_method("show_plot") and node.has_method("show_world_map") and node.has_method("is_over_ui"):
		return node
	for child in node.get_children():
		var found := _find_ui(child)
		if found != null:
			return found
	return null

func _check_tree(node: Node, ui: Node) -> void:
	if node is Button:
		var b := node as Button
		var minimum := b.custom_minimum_size
		if minimum.x < UITheme.TOUCH_MIN or minimum.y < UITheme.TOUCH_MIN:
			_fail("زر أصغر من حد اللمس: " + b.name)
	elif node is Label:
		var label := node as Label
		var font_size := label.get_theme_font_size("font_size")
		if font_size < UITheme.FONT_DETAIL:
			_fail("نص أصغر من الحد المسموح: " + label.name + "=" + str(font_size))
	for child in node.get_children():
		_check_tree(child, ui)

func _fail(message: String) -> void:
	failures.append(message)

func _finish() -> void:
	for message in failures:
		push_error(message)
	quit(1)
