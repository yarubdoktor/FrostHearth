# Food Production Winterstead — Asset Library Entry

- File: `food_production_winterstead.glb`
- Format: glTF 2.0 binary (GLB), embedded solid-color vertex materials
- Intended use: winter food-production resource/building asset for FrostHearth
- Geometry: 73 scene components; deliberately built from low-poly meshes for mobile rendering
- Visual features: snow-capped timber barn, stone foundation, roof, chimney, grain/hay stores, crop beds, fence, barrels, trough with icy water, snow patches and rocks
- Orientation: Y-up; centered approximately around the origin; approximate footprint 6 x 3.5 world units
- Runtime integration: not connected to the map yet; map scripts remain unchanged
- Validation: archive/GLB readability checks only; not yet imported or rendered in Godot, so final in-engine appearance and performance remain unverified

This is a stylized prototype asset intended for the winter strategy art library. It should be visually reviewed in Godot before being treated as final AAA-quality art.
