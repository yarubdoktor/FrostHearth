
- `frostwatch_defense_tower_premium.glb` — برج FrostWatch الدفاعي الشتوي.

- **FrostVault Storehouse** — `frostvault_storehouse_premium.glb` — مخزن موارد شتوي محسّن أولياً.


- **Hearth52 — FrostRoad Caravan Exchange:** `../buildings/frostroad_caravan_exchange_premium.glb` — نقطة تبادل القوافل؛ غير مربوطة بعد.

- `frostwall_modular_corner_premium.glb` — قطعة زاوية للسور المعياري بزاوية 90 درجة؛ أصل مستقل لم يُربط بالخريطة بعد.

## FrostWall — نهاية السور
- `frostwall_modular_endcap_premium.glb` — عمود نهاية متناسق مع المقطع المستقيم وقطعة الزاوية.

## FrostWall — مقطع بوابة دفاعية
- `frostwall_modular_gate_segment_premium.glb` — إطار بوابة مركزي متناسق مع منظومة السور المعياري.

- `frostwall_watchtower_premium.glb` — برج حراسة متناسق مع منظومة FrostWall، مع منصة خشبية وتفاصيل حجرية وجليدية.
