# فهرس مباني مكتبة FrostHearth

هذه أصول GLB مستقلة جُمعت للمراجعة الفنية لاحقاً. لا يعني وجودها أنها مربوطة بالخريطة أو معتمدة نهائياً داخل Godot.

- `frostspire_citadel_premium.glb` — القلعة الرئيسية.
- `frostguard_barracks_premium.glb` — ثكنة الحرس.
- `frostwatch_defense_tower_premium.glb` — برج المراقبة والدفاع.
- `grand_hearth_winter_premium.glb` — الموقد الملكي الدائري.
- `frostgate_city_gate_premium.glb` — بوابة المدينة.
- `frostvault_storehouse_premium.glb` — مخزن الموارد.
- `frostmane_cavalry_barracks_premium.glb` — ثكنة الفرسان.
- `frosthaven_healer_hall_premium.glb` — قاعة العلاج الشتوية.

## قائمة مراجعة عامة

- التحقق من المقياس والاتجاه والخامات في Godot 4.
- معاينة كل أصل من زاوية الخريطة وبالحجم المصغر.
- قياس عدد المثلثات والمواد وعمليات الرسم، واختبار الهاتف.
- دمج الأجزاء الثابتة أو إعداد مستويات تفاصيل أخف عند الحاجة.

- `frostwall_modular_corner_premium.glb` — قطعة زاوية للسور المعياري بزاوية 90 درجة؛ أصل مستقل لم يُربط بالخريطة بعد.

## FrostWall — نهاية السور
- `frostwall_modular_endcap_premium.glb` — عمود نهاية متناسق مع المقطع المستقيم وقطعة الزاوية.

## FrostWall — مقطع بوابة دفاعية
- `frostwall_modular_gate_segment_premium.glb` — إطار بوابة مركزي متناسق مع منظومة السور المعياري.

- `frostwall_watchtower_premium.glb` — برج حراسة متناسق مع منظومة FrostWall، مع منصة خشبية وتفاصيل حجرية وجليدية.
