# فهرس مكتبة المباني — FrostHearth

## أصول جديدة
- **Frostspire Citadel** — `frostspire_citadel_premium.glb` — القلعة الرئيسية الشتوية.
- **FrostGuard Barracks** — `frostguard_barracks_premium.glb` — ثكنة الحرس.
- **FrostWatch Defense Tower** — `frostwatch_defense_tower_premium.glb` — برج دفاع ومراقبة.
- **Grand Hearth (Round)** — `grand_hearth_winter_premium.glb` — موقد دائري مرتفع، بحوض نار علوي وثماني فتحات جانبية.
- **FrostGate City Gate** — `frostgate_city_gate_premium.glb` — بوابة مدينة شتوية مع برجتين جانبيتين وقوس وبوابات خشبية.
- **FrostVault Storehouse** — `frostvault_storehouse_premium.glb` — مخزن موارد شتوي بهيكل حجري/خشبي، باب مزدوج، وتفاصيل صناديق وبراميل.

## ملاحظة جودة
كل الأصول بحاجة إلى معاينة داخل Godot وقياس الأداء على الجهاز المستهدف قبل الاعتماد النهائي. فحص الملف وحده لا يثبت الجودة البصرية أو الأداء داخل اللعبة.

- `frostmane_cavalry_barracks_premium.glb` — ثكنة الفرسان الشتوية (أصل أولي؛ يحتاج اختباراً داخل Godot).

## 13. FrostClan Council Hall — قاعة مجلس القبيلة
- الملف: `frostclan_council_hall_premium.glb`
- الحالة: مضاف إلى مكتبة الأصول، ولم يُربط بالخريطة بعد.
- المراجعة المطلوبة: استيراد Godot، المعاينة من زاوية الخريطة، مراجعة المقاييس والمواد وعدد عمليات الرسم، واختبار الأداء على الهاتف.


## Hearth52 — FrostRoad Caravan Exchange
- الملف: `frostroad_caravan_exchange_premium.glb`
- الوظيفة: نقطة تبادل قوافل شتوية (تُعتمد إذا كانت ضمن المباني المطلوبة).
- الحالة: أُضيف إلى المكتبة؛ لم يُربط بالخريطة ولم يُختبر داخل Godot بعد.

- `frostwall_modular_corner_premium.glb` — قطعة زاوية للسور المعياري بزاوية 90 درجة؛ أصل مستقل لم يُربط بالخريطة بعد.

## FrostWall — نهاية السور
- `frostwall_modular_endcap_premium.glb` — عمود نهاية متناسق مع المقطع المستقيم وقطعة الزاوية.

## FrostWall — مقطع بوابة دفاعية
- `frostwall_modular_gate_segment_premium.glb` — إطار بوابة مركزي متناسق مع منظومة السور المعياري.

- `frostwall_watchtower_premium.glb` — برج حراسة متناسق مع منظومة FrostWall، مع منصة خشبية وتفاصيل حجرية وجليدية.


## Hearth58 — برج مدفعية FrostWall
- `buildings/frostwall_artillery_tower_premium.glb` — برج مدفعية شتوي ثقيل، أصل بصري غير مربوط بعد بنظام اللعب.
