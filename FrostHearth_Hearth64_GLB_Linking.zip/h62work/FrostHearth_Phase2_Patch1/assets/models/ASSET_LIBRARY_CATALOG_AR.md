# مكتبة أصول FrostHearth — سجل الأصول

هذه المكتبة تجمع نماذج GLB التي تُجهّز قبل مرحلة الربط. وجود الأصل في القائمة لا يعني أنه اختُبر أو اعتُمد نهائياً داخل Godot.

## أصول الموارد والإنتاج
- `resources/forest_wood_winter.glb` — غابة أخشاب شتوية.
- `resources/iron_mine_winter_premium.glb` — مكمن خام الحديد.
- `resources/stone_quarry_winter_premium.glb` — محجر الحجر.
- `resources/food_production_winterstead.glb` — منشأة إنتاج الغذاء الشتوية.

## المباني والمعالم الجديدة
- `buildings/frostspire_citadel_premium.glb` — قلعة Frostspire الرئيسية.
- `buildings/frostguard_barracks_premium.glb` — ثكنة الحرس الشتوية.
- `buildings/frostwatch_defense_tower_premium.glb` — برج المراقبة والدفاع.
- `buildings/grand_hearth_winter_premium.glb` — الموقد الملكي الدائري المرتفع، مع حوض علوي وفتحات نار جانبية.
- `buildings/frostgate_city_gate_premium.glb` — بوابة المدينة الشتوية، مع برجتين وقوس وبوابات خشبية.
- `buildings/frostvault_storehouse_premium.glb` — مخزن الموارد الشتوي FrostVault.
- `buildings/frostmane_cavalry_barracks_premium.glb` — ثكنة فرسان شتوية مع إسطبل ومعلف وعناصر خيل زخرفية.

- `buildings/frostwall_modular_segment_premium.glb` — مقطع سور دفاعي شتوي معياري قابل للتكرار.
- `buildings/frostwall_modular_corner_premium.glb` — قطعة زاوية 90 درجة لربط مقاطع السور المتعامدة، بتاج ثلجي ودعامة حجرية.
- `buildings/frostwall_modular_endcap_premium.glb` — عمود نهاية للسور المعياري، بخامات FrostWall نفسها وتاج ثلجي وشرفات مسننة.
- `buildings/frostwall_modular_gate_segment_premium.glb` — مقطع بوابة دفاعية للسور، بفتحة مركزية ومصراعين خشبيين وإطار حجري ثلجي.

## أصول سابقة موجودة في المشروع
- `royal_hearth.glb` — موقد/معلم ملكي سابق.
- `arabian_winter_lodge.glb` — نُزل شتوي.
- `timber_storehouse.glb` — مخزن أخشاب.

- `buildings/frostwall_watchtower_premium.glb` — برج حراسة مرتفع متناسق مع FrostWall، بدعامات حجرية وفتحات جليدية ومنصة خشبية وسقف ثلجي.

## الحالة التقنية
- الأصول محفوظة كملفات GLB مستقلة.
- Hearth64: رُبطت 10 نماذج بأنواع المباني عبر `GLB_MODELS` في `scripts/main.gd` (لم تُختبر داخل Godot بعد).
- يلزم استيراد كل أصل إلى Godot، وفحص المقاييس والخامات والاتجاه والوضوح عند حجم الخريطة، ثم قياس الأداء على جهاز مستهدف.


## Hearth58 — برج مدفعية FrostWall
- `buildings/frostwall_artillery_tower_premium.glb` — برج مدفعية شتوي ثقيل، أصل بصري غير مربوط بعد بنظام اللعب.
- `buildings/frosthaven_healer_hall_premium.glb` — مضافة الحكيم الشتوية؛ أصل مرشح للنوع `infirmary` بانتظار اختبار الربط.
- `buildings/frostclan_council_hall_premium.glb` — مجلس القبيلة؛ أصل مرشح للنوع `majlis` بانتظار اختبار الربط.
