# Frost Hearth — Section 02: Caravans

## Implemented
- Added the Caravan Yard building; caravan routes stay locked until it is completed.
- Added three routes: Buried Oasis, Traders' Camp, and Mountain Pass.
- Route-specific travel duration, provisions, risk, and reward multipliers.
- Player chooses up to three companions. Companions improve successful rewards and temporarily reduce production while away.
- A route can return resources, fame, and occasionally a new survivor; risky trips can lose one companion.
- Caravan state is persisted in the existing save file and handled when the game resumes after being away.
- Added a procedural 3D caravan-yard structure and Arabic route-selection UI.

## Validation status
- Static source review completed: no duplicate function names and no obvious unmatched quote lines in the edited GDScript files.
- Runtime validation and APK export were not performed because the Godot executable/export templates are not available in this environment.

## Known follow-up work
- Add visible camel/caravan actors and route departure/arrival animation.
- Add event-specific encounters (storm, wolves, bandits) and dynamic barter prices.
- Connect caravan outcomes to dedicated Majlis events and add further balance testing.
