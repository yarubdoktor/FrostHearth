extends Node
const Defs := preload("res://scripts/defs.gd")
## لقطة تحقق بصري: فرقة المسيرة على الخريطة — تشكيل واتجاه
func _ready() -> void:
	Game.save_path_override = "user://frost_save_shot_map.json"
	Game.new_game()
	Game.dev_mode = true
	for r in ["food", "wood", "coal", "iron"]:
		Game.res[r] = 100000.0
	Game.troops = {}
	for tp in ["shield", "spear", "bow"]:
		for t in range(1, 5):
			Game.troops["%s_%d" % [tp, t]] = 20
	Game.heroes["siraj"]["owned"] = true
	Game.defender = "siraj"
	var map_scene: PackedScene = load("res://world_map.tscn")
	var map: Node3D = map_scene.instantiate()
	add_child(map)
	await get_tree().process_frame
	await get_tree().process_frame
	var res_info := {}
	for tile in map.lookup:
		var info: Dictionary = map.lookup[tile]
		if str(info.get("kind", "")) == "res":
			res_info = info
			break
	map._select(res_info)
	map._on_action()
	map._open_venture_window({})
	var k0: String = map.vent_spins.keys()[0]
	map.vent_spins[k0].value = 5
	map._send_venture()
	await get_tree().process_frame
	await get_tree().process_frame
	await get_tree().process_frame
	# كاميرا فوق فرقة المسيرة
	var squad: Node3D = map.march_vis["venture"]["troop"]
	var cam := Camera3D.new()
	map.add_child(cam)
	var sp: Vector3 = squad.global_position
	cam.position = sp + Vector3(0, 5.5, 6.5)
	cam.look_at(sp + Vector3(0, 0.3, 0), Vector3.UP)
	cam.make_current()
	await get_tree().process_frame
	await get_tree().process_frame
	await get_tree().process_frame
	var img: Image = get_viewport().get_texture().get_image()
	img.save_png("res://shot_map_squad.png")
	print("SHOT saved")
	get_tree().quit(0)
