extends Node
const Defs := preload("res://scripts/defs.gd")
## لقطة تحقق بصري: قاعة الأبطال والثكنات — تحفظ لقطات PNG للفحص
## التشغيل: xvfb-run godot --path . res://tools/city_screenshot.tscn

func _ready() -> void:
	Game.save_path_override = "user://frost_save_shot.json"
	Game.new_game()
	Game.dev_mode = true
	for r in ["food", "wood", "coal", "iron"]:
		Game.res[r] = 100000.0
	Game.plots["hh1"] = 1
	Game.plots["bs1"] = 1
	Game.plots["bp1"] = 1
	Game.plots["ba1"] = 1
	Game.heroes["siraj"]["owned"] = true
	Game.heroes["layla"]["owned"] = true
	Game.heroes["reem"]["owned"] = true
	Game.troops["shield_1"] = 45
	Game.troops["spear_2"] = 20
	var city_scene: PackedScene = load("res://city.tscn")
	var city: Node3D = city_scene.instantiate()
	add_child(city)
	Game.last_daily = Game._today()
	Game.daily_ready = false
	Game.pending_decision = -1
	Game.decision_next = Game.now() + 99999.0
	await get_tree().process_frame
	await get_tree().process_frame
	await get_tree().process_frame
	city._close_window()
	if city.modal_layer != null:
		for c in city.modal_layer.get_children():
			c.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	var cam := Camera3D.new()
	city.add_child(cam)
	var hall_pos: Vector3 = city.plot_nodes["hh1"]["root"].position
	var fwd := (Defs.CITY_CENTER - hall_pos).normalized()
	cam.position = hall_pos + fwd * 10.0 + Vector3(0, 3.6, 0)
	cam.look_at(hall_pos + Vector3(0, 1.4, 0) + fwd * 3.0, Vector3.UP)
	cam.make_current()
	await get_tree().process_frame
	await get_tree().process_frame
	await get_tree().process_frame
	var img: Image = get_viewport().get_texture().get_image()
	img.save_png("res://shot_hero_hall.png")
	print("SHOT1 saved")
	var cam2 := Camera3D.new()
	city.add_child(cam2)
	var bpos: Vector3 = city.plot_nodes["bs1"]["root"].position
	var fwd2 := (Defs.CITY_CENTER - bpos).normalized()
	cam2.position = bpos + fwd2 * 10.0 + Vector3(0, 3.6, 0)
	cam2.look_at(bpos + Vector3(0, 1.4, 0) + fwd2 * 3.0, Vector3.UP)
	cam2.make_current()
	await get_tree().process_frame
	await get_tree().process_frame
	await get_tree().process_frame
	var img2: Image = get_viewport().get_texture().get_image()
	img2.save_png("res://shot_barracks.png")
	print("SHOT2 saved")
	get_tree().quit(0)
