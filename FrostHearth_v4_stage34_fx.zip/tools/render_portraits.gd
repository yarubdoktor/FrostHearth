extends Node
## أداة توليد صور الجنود من النماذج ثلاثية الأبعاد — لكل نموذج Viewport مستقل يُلتقط منه PNG بخلفية شفافة
## التشغيل: godot --path . res://tools/render_portraits.tscn (يحتاج عرضاً حقيقياً — xvfb على لينكس)

const OUT := {
	"res://assets/city/soldier_shield.glb": "res://assets/ui/portrait_shield.png",
	"res://assets/city/soldier_spear.glb": "res://assets/ui/portrait_spear.png",
	"res://assets/city/soldier_bow.glb": "res://assets/ui/portrait_bow.png",
}
const SIZE := 512

var holder: Node3D

func _ready() -> void:
	holder = Node3D.new()
	add_child(holder)
	var failed := false
	for src in OUT:
		if not await _render_one(src, OUT[src]):
			failed = true
	print("PORTRAITS " + ("FAILED" if failed else "DONE"))
	get_tree().quit(1 if failed else 0)

func _render_one(src: String, dst: String) -> bool:
	var ps: PackedScene = load(src)
	if ps == null:
		print("SKIP missing " + src)
		return false
	var vp := SubViewport.new()
	vp.size = Vector2(SIZE, SIZE)
	vp.transparent_bg = true
	vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	holder.add_child(vp)
	var root := Node3D.new()
	vp.add_child(root)
	var cam := Camera3D.new()
	cam.fov = 30.0
	root.add_child(cam)
	var sun := DirectionalLight3D.new()
	sun.light_energy = 0.95
	root.add_child(sun)
	var fill := DirectionalLight3D.new()
	fill.light_energy = 0.3
	fill.light_color = Color(0.6, 0.75, 1.0)
	root.add_child(fill)
	var model: Node3D = ps.instantiate()
	root.add_child(model)
	# تأطير على الجسم مع قصّ طفيف للرمح الطويل
	var aabb := AABB()
	var stack: Array = [model]
	while not stack.is_empty():
		var n: Node = stack.pop_back()
		for c in n.get_children():
			stack.append(c)
		if n is MeshInstance3D:
			aabb = aabb.merge((n as MeshInstance3D).get_aabb())
	if aabb.size == Vector3.ZERO:
		aabb = model.transform * AABB()
	print("AABB " + src + " pos=" + str(aabb.position) + " size=" + str(aabb.size))
	# تأطير على الجسم — الرمح الأطول يُقص من الأعلى بورتريه متزن
	var body_h := minf(aabb.position.y + aabb.size.y, 0.85)
	var center := Vector3(aabb.get_center().x, body_h * 0.5, aabb.get_center().z)
	var h := maxf(body_h * 1.05, aabb.size.x * 1.1)
	var dir := Vector3(0.7, 0.28, 1.0).normalized()
	cam.position = center + dir * maxf(h * 2.0, 2.2)
	cam.look_at(center, Vector3.UP)
	sun.position = cam.position + Vector3(2, 5, 2)
	sun.look_at(center, Vector3.UP)
	fill.position = cam.position + Vector3(-4, 1, -2)
	fill.look_at(center, Vector3.UP)
	await get_tree().process_frame
	await get_tree().process_frame
	await get_tree().process_frame
	var img: Image = vp.get_texture().get_image()
	var err := img.save_png(dst)
	print("SAVED " + dst + " err=" + str(err) + " size=" + str(img.get_size()))
	vp.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	return err == OK
