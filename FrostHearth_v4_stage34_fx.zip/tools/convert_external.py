#!/usr/bin/env python3
"""تحويل نماذج خارجية ثقيلة (GLB بخامات 4096) إلى أصول خفيفة بأسلوب اللعبة.

الخطوات: قراءة النموذج ← خبز لون الخامة في ألوان رؤوس (COLOR_0 كبقية أصول اللعبة) ←
تبسيط هندسي QEM (طي الحواف بمربعات الخطأ) ← تدوير/تحجيم/وضع القاعدة عند y=0 ←
تظليل مسطح كمولّد الأصول (tools/glb.py).

الاستخدام:
  python3 tools/convert_external.py IN.glb OUT.glb --tris 3500 --up z --height 11
  --up y|z|-z|-y  محور الأعلى في الملف الأصلي
  --height H أو --footprint W  حجم الناتج بوحدات اللعبة
يحتاج numpy + scipy + Pillow.
"""
import argparse, heapq, io, json, struct, sys, os
import numpy as np
from PIL import Image
from scipy.spatial import cKDTree

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from glb import GLB, MeshBuilder  # noqa: E402

Image.MAX_IMAGE_PIXELS = None
CT = {5126: "f4", 5123: "u2", 5125: "u4", 5121: "u1"}
NC = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4}


def _acc(j, bin_, i):
    a = j["accessors"][i]; bv = j["bufferViews"][a["bufferView"]]
    n = NC[a["type"]]; dt = np.dtype(CT[a["componentType"]])
    off = bv.get("byteOffset", 0) + a.get("byteOffset", 0)
    stride = bv.get("byteStride", 0) or n * dt.itemsize
    if stride == n * dt.itemsize:
        return np.frombuffer(bin_, dtype=dt, count=a["count"] * n, offset=off).reshape(a["count"], n)
    raw = np.frombuffer(bin_, dtype=np.uint8, offset=off)
    return np.stack([np.frombuffer(raw[k * stride:k * stride + n * dt.itemsize].tobytes(), dtype=dt) for k in range(a["count"])])


def load_baked(path):
    """يرجع (V, F, colors_linear) — اللون مأخوذ من خامة اللون الأساسي عند UV كل رأس."""
    b = open(path, "rb").read()
    cl, _ = struct.unpack("<II", b[12:20]); j = json.loads(b[20:20 + cl]); bin_ = b[20 + cl + 8:]
    p = j["meshes"][0]["primitives"][0]
    pos = _acc(j, bin_, p["attributes"]["POSITION"]).astype(np.float64)
    uv = _acc(j, bin_, p["attributes"]["TEXCOORD_0"]).astype(np.float64)
    idx = _acc(j, bin_, p["indices"]).reshape(-1, 3).astype(np.int64)
    ti = j["materials"][0]["pbrMetallicRoughness"]["baseColorTexture"]["index"]
    t = j["textures"][ti]
    src = t.get("source", t.get("extensions", {}).get("EXT_texture_webp", {}).get("source"))
    bv = j["bufferViews"][j["images"][src]["bufferView"]]
    o = bv.get("byteOffset", 0)
    img = Image.open(io.BytesIO(bin_[o:o + bv["byteLength"]])).convert("RGB")
    tex = np.asarray(img); H, W = tex.shape[:2]
    u = np.clip((uv[:, 0] % 1.0) * (W - 1) + 0.5, 0, W - 1).astype(int)
    v = np.clip((uv[:, 1] % 1.0) * (H - 1) + 0.5, 0, H - 1).astype(int)
    col = (tex[v, u] / 255.0) ** 2.2        # كما تفعل lin() في build_city.py
    return pos, idx, col


def weld(V, F, C, dec=6):
    """دمج الرؤوس المتطابقة موضعيًا (التقسيم عند حدود UV) مع متوسط اللون."""
    key = np.round(V, dec)
    _, first, inv = np.unique(key, axis=0, return_index=True, return_inverse=True)
    inv = inv.reshape(-1)
    nV = len(first)
    Vn = V[first]
    Cn = np.zeros((nV, 3)); cnt = np.bincount(inv, minlength=nV)[:, None]
    np.add.at(Cn, inv, C)
    Cn /= cnt
    Fn = inv[F]
    ok = (Fn[:, 0] != Fn[:, 1]) & (Fn[:, 1] != Fn[:, 2]) & (Fn[:, 0] != Fn[:, 2])
    return Vn, Fn[ok], Cn


def precluster(V, F, C, max_faces):
    """تقليل أولي سريع بتجميع الرؤوس في شبكة (للنماذج بمئات الآلاف من المثلثات) قبل QEM."""
    diag = np.linalg.norm(V.max(0) - V.min(0)); size = diag / 400.0; lo = V.min(0)
    while True:
        key = np.floor((V - lo) / size).astype(np.int64)
        _, inv = np.unique(key, axis=0, return_inverse=True); inv = inv.reshape(-1)
        n = inv.max() + 1; cnt = np.bincount(inv, minlength=n)[:, None]
        Vn = np.zeros((n, 3)); Cn = np.zeros((n, 3))
        np.add.at(Vn, inv, V); np.add.at(Cn, inv, C); Vn /= cnt; Cn /= cnt
        Fn = inv[F]
        ok = (Fn[:, 0] != Fn[:, 1]) & (Fn[:, 1] != Fn[:, 2]) & (Fn[:, 0] != Fn[:, 2])
        if ok.sum() <= max_faces:
            return Vn, Fn[ok], Cn
        size *= 1.25


def qem(V, F, target):
    """تبسيط بمربعات الخطأ (Garland-Heckbert) مع منع انقلاب الوجوه وحماية الحواف المفتوحة."""
    V = V.copy(); nV = len(V)
    p0, p1, p2 = V[F[:, 0]], V[F[:, 1]], V[F[:, 2]]
    nrm = np.cross(p1 - p0, p2 - p0); ar = np.linalg.norm(nrm, axis=1)
    nrm /= (ar[:, None] + 1e-30); area = ar / 2
    P = np.hstack([nrm, -(nrm * p0).sum(1)[:, None]])
    Qf = np.einsum("mi,mj->mij", P, P) * area[:, None, None]
    Q = np.zeros((nV, 4, 4))
    for k in range(3):
        np.add.at(Q, F[:, k], Qf)
    # حواف مفتوحة: مستوى عمودي على الوجه يمر بالحافة
    ecount = {}
    for fi, f in enumerate(F):
        for a, b in ((f[0], f[1]), (f[1], f[2]), (f[2], f[0])):
            k = (min(a, b), max(a, b)); ecount.setdefault(k, []).append(fi)
    for (a, b), fl in ecount.items():
        if len(fl) == 1:
            e = V[b] - V[a]; L = np.linalg.norm(e)
            n = np.cross(e, nrm[fl[0]]); ln = np.linalg.norm(n)
            if ln < 1e-12:
                continue
            n /= ln; pl = np.append(n, -n @ V[a])
            w = 10.0 * L * L
            Qe = np.outer(pl, pl) * w
            Q[a] += Qe; Q[b] += Qe
    faces = [list(map(int, f)) for f in F]
    alive_f = [True] * len(faces)
    vf = [set() for _ in range(nV)]
    for fi, f in enumerate(faces):
        for v in f:
            vf[v].add(fi)
    alive_v = [True] * nV
    stamp = [0] * nV
    nfaces = len(faces)

    def best(u, v):
        Qs = Q[u] + Q[v]
        A = Qs.copy(); A[3] = [0, 0, 0, 1]
        cands = [V[u], V[v], (V[u] + V[v]) / 2]
        if abs(np.linalg.det(A)) > 1e-12:
            try:
                x = np.linalg.solve(A, [0, 0, 0, 1])[:3]
                if np.linalg.norm(x - cands[2]) < 2.0 * (np.linalg.norm(V[u] - V[v]) + 1e-9):
                    cands.append(x)
            except np.linalg.LinAlgError:
                pass
        bc, bp = 1e300, cands[2]
        for c in cands:
            h = np.append(c, 1.0)
            e = h @ Qs @ h
            if e < bc:
                bc, bp = e, c
        return bc, bp

    heap = []
    for (a, b) in ecount:
        c, p = best(a, b)
        heapq.heappush(heap, (c, a, b, 0, 0, tuple(p)))

    def flips(u, v, newp):
        """هل يقلب الطيّ أي وجه محيط؟ (u يُدمج في v)."""
        for fi in vf[u] | vf[v]:
            f = faces[fi]
            if u in f and v in f:
                continue
            pts = [V[x] for x in f]
            n0 = np.cross(pts[1] - pts[0], pts[2] - pts[0])
            pts2 = [newp if x in (u, v) else V[x] for x in f]
            n1 = np.cross(pts2[1] - pts2[0], pts2[2] - pts2[0])
            l0, l1 = np.linalg.norm(n0), np.linalg.norm(n1)
            if l1 < 1e-14 or (l0 > 1e-14 and (n0 @ n1) / (l0 * l1) < 0.25):
                return True
        return False

    while heap and nfaces > target:
        c, u, v, su, sv, p = heapq.heappop(heap)
        if not (alive_v[u] and alive_v[v]) or stamp[u] != su or stamp[v] != sv:
            continue
        newp = np.array(p)
        if flips(u, v, newp):
            continue
        # تطبيق الطيّ: u ← v
        for fi in list(vf[u]):
            f = faces[fi]
            if v in f:
                alive_f[fi] = False; nfaces -= 1
                for x in f:
                    vf[x].discard(fi)
            else:
                f[f.index(u)] = v
                vf[v].add(fi)
        vf[u] = set()
        alive_v[u] = False
        V[v] = newp; Q[v] = Q[u] + Q[v]; stamp[v] += 1
        nb = set()
        for fi in vf[v]:
            nb.update(faces[fi])
        nb.discard(v)
        for w in nb:
            cc, pp = best(v, w)
            a, b = (v, w)
            heapq.heappush(heap, (cc, a, b, stamp[a], stamp[b], tuple(pp)))
    keep = [i for i, f in enumerate(faces) if alive_f[i]]
    Fo = np.array([faces[i] for i in keep], np.int64)
    used = np.unique(Fo)
    remap = -np.ones(nV, np.int64); remap[used] = np.arange(len(used))
    return V[used], remap[Fo]


UP = {"y": np.eye(3), "-y": np.diag([1, -1, -1.0]),
      "z": np.array([[1, 0, 0], [0, 0, 1], [0, -1, 0.0]]),    # z→y
      "-z": np.array([[1, 0, 0], [0, 0, -1], [0, 1, 0.0]])}


def convert(src, dst, tris, up, height=None, footprint=None, yaw=0.0, name=None, face=None, lum=0.09):
    V, F, C = load_baked(src)
    n0 = len(F)
    V, F, C = weld(V, F, C)
    if len(F) > 90000:
        V, F, C = precluster(V, F, C, 70000)
    tree = cKDTree(V)
    Vs, Fs = qem(V, F, tris)
    # إعادة خبز اللون من أقرب رؤوس الأصل (أدق من تتبع الطيّ)
    k = 6
    d, ix = tree.query(Vs, k=k)
    w = 1.0 / (d + 1e-6)
    Cs = (C[ix] * w[:, :, None]).sum(1) / w.sum(1)[:, None]
    # مطابقة السطوع لأصول اللعبة (خامات الذكاء الاصطناعي أغمق من لوحة اللعبة): متوسط الإضاءة الخطية ≈ lum
    cur = float((Cs @ [0.2126, 0.7152, 0.0722]).mean())
    gain = min(max(lum / max(cur, 1e-4), 1.0), 3.0)
    Cs = np.clip(Cs * gain, 0, 1)
    R = UP[up]
    Vs = Vs @ R.T
    if face == "orange":   # أدِر النموذج ليواجه جهة اللون البرتقالي (الأتون) المحور +z كأبنية اللعبة
        mn0, mx0 = Vs.min(0), Vs.max(0); ctr = (mn0 + mx0) / 2
        r, b = Cs[:, 0], Cs[:, 2]
        m = (r > 0.25) & (r > 2.5 * b)
        if m.sum() > 3:
            vx, vz = (Vs[m, 0] - ctr[0]).mean(), (Vs[m, 2] - ctr[2]).mean()
            yaw = float(np.degrees(np.arctan2(-vx, vz)))
    a = np.radians(yaw); Ry = np.array([[np.cos(a), 0, np.sin(a)], [0, 1, 0], [-np.sin(a), 0, np.cos(a)]])
    Vs = Vs @ Ry.T
    mn, mx = Vs.min(0), Vs.max(0)
    if height:
        s = height / (mx[1] - mn[1])
    else:
        s = footprint / max(mx[0] - mn[0], mx[2] - mn[2])
    Vs = (Vs - [(mn[0] + mx[0]) / 2, mn[1], (mn[2] + mx[2]) / 2]) * s
    # اتجاه الوجوه: تأكد أن الأعلى يشير للخارج (قارن مع مركز الكتلة)
    tri = Vs[Fs]
    nr = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    cen = tri.mean(1) - Vs.mean(0)
    if (np.einsum("ij,ij->i", nr, cen) > 0).mean() < 0.5:
        Fs = Fs[:, ::-1]
    tri = Vs[Fs]
    col = Cs[Fs].reshape(-1, 3)
    m = MeshBuilder(); m.add_soup("Matte", tri, col)
    nm = name or os.path.splitext(os.path.basename(dst))[0]
    g = GLB(); n = g.add_node(nm, mesh=g.add_mesh(nm, m)); g.save(dst, [n])
    size = Vs.max(0) - Vs.min(0)
    return dict(tris_in=n0, tris_out=len(Fs), size=[round(float(x), 2) for x in size], kb=round(os.path.getsize(dst) / 1024, 1)), Vs, Fs, Cs


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("src"); ap.add_argument("dst")
    ap.add_argument("--tris", type=int, default=3500)
    ap.add_argument("--up", default="y", choices=list(UP))
    ap.add_argument("--height", type=float); ap.add_argument("--footprint", type=float)
    ap.add_argument("--yaw", type=float, default=0.0)
    ap.add_argument("--face", choices=["orange"])
    a = ap.parse_args()
    if not (a.height or a.footprint):
        sys.exit("حدد --height أو --footprint")
    info, *_ = convert(a.src, a.dst, a.tris, a.up, a.height, a.footprint, a.yaw, face=a.face)
    print(info)
