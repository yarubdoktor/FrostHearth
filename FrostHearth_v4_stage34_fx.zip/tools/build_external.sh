#!/bin/sh
# يحوّل النماذج الخارجية (من Pixabay) إلى أصول خفيفة. المصدر: مجلد SRC (افتراضيًا ext_src/)
SRC=${1:-ext_src}; OUT=assets/city_ext
python3 tools/convert_external.py $SRC/pixellabs-blacksmith-workshop-4884.glb $OUT/workshop_ext.glb --tris 3500 --up=-z --footprint 6.0 --face orange
python3 tools/convert_external.py $SRC/pixellabs-tower-3179.glb $OUT/scout_tower_ext.glb --tris 2500 --up=-z --height 12
python3 tools/convert_external.py $SRC/pixellabs-fantasy-3830.glb $OUT/wizard_tower_ext.glb --tris 2500 --up=-z --height 8
python3 tools/convert_external.py $SRC/pixellabs-fantasy-tower-3d-model-2690.glb $OUT/fantasy_tower_ext.glb --tris 2500 --up=-z --height 12
python3 tools/convert_external.py $SRC/pixellabs-fantasy-signpost-3561.glb $OUT/lamppost_ext.glb --tris 1500 --up=-z --height 5
