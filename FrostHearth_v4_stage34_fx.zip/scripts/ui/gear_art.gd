extends RefCounted
## Painted PNG icons: one per troop type and equipment slot.
const TEXTURES := {
	"shield_weapon": preload("res://assets/gear/shield_weapon.png"),
	"shield_armor": preload("res://assets/gear/shield_armor.png"),
	"shield_helmet": preload("res://assets/gear/shield_helmet.png"),
	"shield_rune": preload("res://assets/gear/shield_rune.png"),
	"spear_weapon": preload("res://assets/gear/spear_weapon.png"),
	"spear_armor": preload("res://assets/gear/spear_armor.png"),
	"spear_helmet": preload("res://assets/gear/spear_helmet.png"),
	"spear_rune": preload("res://assets/gear/spear_rune.png"),
	"bow_weapon": preload("res://assets/gear/bow_weapon.png"),
	"bow_armor": preload("res://assets/gear/bow_armor.png"),
	"bow_helmet": preload("res://assets/gear/bow_helmet.png"),
	"bow_rune": preload("res://assets/gear/bow_rune.png"),
}


static func icon(tp: String, slot: String, side: int = 64) -> TextureRect:
	var view := TextureRect.new()
	view.name = "GearIcon_" + tp + "_" + slot
	view.texture = TEXTURES.get(tp + "_" + slot)
	view.custom_minimum_size = Vector2(side, side)
	view.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	view.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	view.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	view.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return view
