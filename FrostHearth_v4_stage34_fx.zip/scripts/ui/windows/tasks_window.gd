extends RefCounted
## المرحلة 33 — سجل المهام الفاخر: بطاقات بحالات (مكتملة • حالية • قادمة)، أشرطة تقدّم
## حية، مكافآت مصوّرة بأيقونات الموارد، وأزرار استلام/انتقال — مستوحى من واجهات
## استراتيجيات الأجهزة الكبرى: إطارات ذهبية على كحلي داكن ولمسات جليدية زرقاء.

const UI := preload("res://scripts/ui_kit.gd")
const Defs := preload("res://scripts/defs.gd")
const WinProg := preload("res://scripts/ui/windows/progression_windows.gd")

const GOLD_BD := Color("e8b44a")
const GREEN_BD := Color("5cc47e")
const ICE := Color("4fb4ff")


static func show(city: Node) -> void:
	WinProg.window(city, "المهام", "task", func(body: VBoxContainer): _build(city, body))


static func _build(city: Node, body: VBoxContainer) -> void:
	_chapter(city, body, 1, Defs.TASKS, Game.task_index, "claim_task")
	if Game.chapter2_open():
		body.add_child(_spacer(6))
		_chapter(city, body, 2, Defs.TASKS2, Game.task2_index, "claim_task2")
	else:
		var hint := WinProg.wrap_lbl("يُفتح الفصل الثاني (الجيش والأبطال والأبحاث) بترقية الفرن إلى المستوى 3.", 16, UI.TEXT_DIM)
		hint.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		body.add_child(hint)
	# إعادة بناء السجل عند استلام مهمة (تغيّر الفهرس)
	var sig := [str(Game.task_index) + "|" + str(Game.task2_index)]
	city.win_tick.append(func() -> void:
		if not is_instance_valid(body):
			return
		var now_sig := str(Game.task_index) + "|" + str(Game.task2_index)
		if now_sig != sig[0]:
			sig[0] = now_sig
			city._refresh_window())


static func _spacer(h: float) -> Control:
	var s := Control.new()
	s.custom_minimum_size = Vector2(0, h)
	s.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return s


## ترويسة فصل: عنوان + شريط تقدّم عام + بطاقات مهامه
static func _chapter(city: Node, body: VBoxContainer, ch: int, tasks: Array, idx: int, claim: String) -> void:
	var total: int = tasks.size()
	var head := _card(Color(0.11, 0.08, 0.03, 0.96), GOLD_BD)
	body.add_child(head)
	var hv := VBoxContainer.new()
	hv.add_theme_constant_override("separation", 7)
	head.add_child(hv)
	var ht := HBoxContainer.new()
	ht.add_theme_constant_override("separation", 8)
	hv.add_child(ht)
	var hl := UI.label("الفصل %s — رحلة البقاء" % ("الأول" if ch == 1 else "الثاني"), 22, UI.GOLD)
	hl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ht.add_child(hl)
	# علامات BiDi + بلا مسافات حول الشرطة حتى لا تنعكس الأرقام في النص العربي (RTL)
	ht.add_child(UI.label("\u2066%d/%d\u2069" % [mini(idx, total), total], 19, Color("ffe8b0")))
	var hb := UI.progress_bar(UI.GOLD)
	hb.custom_minimum_size = Vector2(0, 12)
	hv.add_child(hb)
	hb.value = 100.0 * float(mini(idx, total)) / float(total)
	# البطاقات: الحالية ثم القادمة (المكتملة تُختصر بالترويسة)
	var from := maxi(idx, 0)
	var to := mini(from + 5, total)
	for i in range(from, to):
		_task_card(city, body, ch, tasks[i], i, idx, claim)
	if to < total:
		var more := WinProg.wrap_lbl("… و%d مهمة أخرى تُكشف تباعًا بعد إتمام الحالية." % [total - to], 15, UI.TEXT_DIM)
		body.add_child(more)


## بطاقة مهمة واحدة بحالتها
static func _task_card(city: Node, body: VBoxContainer, ch: int, tk: Dictionary, i: int, idx: int, claim: String) -> void:
	var current: bool = i == idx
	var done: bool = current and Game.task_done(tk)
	var one: bool = tk["type"] in ["temp", "defender", "governor"]
	var pr := Game.task_progress(tk)
	# الحالة: 1 = حالية (ذهبية متوهجة عند الجاهزية) • 0 = قادمة (خافتة)
	var bd := GOLD_BD if done else (Color(1, 1, 1, 0.22) if current else Color(1, 1, 1, 0.08))
	var bg := Color(0.14, 0.10, 0.03, 0.96) if done else (Color(0.08, 0.13, 0.22, 0.95) if current else Color(0.05, 0.09, 0.15, 0.72))
	var card := _card(bg, bd)
	body.add_child(card)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 6)
	card.add_child(box)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	box.add_child(row)
	# شارة الحالة
	var badge: Control = null
	if done:
		var l := UI.label("✓", 26, UI.GREEN)
		l.custom_minimum_size = Vector2(36, 36)
		badge = l
	elif current:
		badge = UI.icon_rect("task", 36)
	else:
		var li := UI.icon_rect("lock", 30)
		li.modulate = Color(1, 1, 1, 0.45)
		badge = li
	row.add_child(badge)
	# نص المهمة
	var txt := WinProg.wrap_lbl(str(tk["text"]), 19, Color.WHITE if current else Color("8fa3b8"))
	txt.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(txt)
	# الزر: استلام للمكتملة • انتقال للحالية
	var btn: Button = null
	if current:
		btn = UI.button("استلام" if done else "اذهب", func() -> void:
			var tt := Game.tracked_task()
			if not tt.is_empty() and Game.task_done(tt["tk"]):
				if tt["ch"] == 1:
					Game.claim_task()
				else:
					Game.claim_task2()
				Sound.play("collect")
			else:
				city._task_action()
			city._refresh_window(), "gold" if done else "blue", 48)
		btn.custom_minimum_size = Vector2(108, 48)
		row.add_child(btn)
	# صف التقدّم + المكافآت
	var prow := HBoxContainer.new()
	prow.add_theme_constant_override("separation", 8)
	box.add_child(prow)
	var bar: ProgressBar = null
	var plbl: Label = null
	if not one:
		bar = UI.progress_bar(UI.GOLD if done else ICE)
		bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		bar.custom_minimum_size = Vector2(0, 10)
		prow.add_child(bar)
		plbl = UI.label("\u2066%s/%s\u2069" % [Defs.fmt(minf(pr.x, pr.y)), Defs.fmt(pr.y)], 15, UI.TEXT_DIM)
		prow.add_child(plbl)
		bar.value = 100.0 * clampf(pr.x / maxf(pr.y, 1.0), 0.0, 1.0)
	if current:
		prow.add_child(_reward_chips(tk["reward"]))
	# تحديث حي للبطاقة الحالية: شريط التقدّم وزر الاستلام
	if current:
		city.win_tick.append(func() -> void:
			if not is_instance_valid(bar) and not is_instance_valid(btn):
				return
			var p := Game.task_progress(tk)
			var d := Game.task_done(tk)
			if is_instance_valid(bar):
				bar.value = 100.0 * clampf(p.x / maxf(p.y, 1.0), 0.0, 1.0)
			if is_instance_valid(plbl):
				plbl.text = "\u2066%s/%s\u2069" % [Defs.fmt(minf(p.x, p.y)), Defs.fmt(p.y)]
			if is_instance_valid(btn):
				btn.text = "استلام" if d else "اذهب")


## لوحة بترويسة محددة (مستخدمة للترويسة الذهبية للفصل والبطاقات)
static func _card(bg: Color, border: Color) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", UI.style(bg, 16, border, 14))
	return p


## مكافآت مصوّرة: شريحة لكل مورد بأيقونته
static func _reward_chips(reward: Dictionary) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 6)
	for r in reward:
		var icon_name := _reward_icon(str(r))
		var c := UI.chip(icon_name, 20, 15)
		(c[1] as Label).text = Defs.fmt(float(reward[r]))
		h.add_child(c[0])
	return h


static func _reward_icon(r: String) -> String:
	if r.begins_with("shards_"):
		return "hero"
	return {"gems": "gem"}.get(r, r)
