extends "res://scripts/map/map_venture.gd"
## الطبقة 4/5 — لوحة خريطة الإقليم: اللمس والاختيار ولوحة المعلومات وأزرار الحرب.


func _on_tap(world: Vector3, _sp: Vector2) -> void:
	var size := int(data["size"])
	var tile := Vector2i(floori(world.x), floori(world.z))
	if tile.x < 0 or tile.y < 0 or tile.x >= size or tile.y >= size:
		return
	var info: Dictionary = lookup.get(tile, {})
	# Physical city footprints are registered in lookup. Vacant tiles can
	# additionally use screen-space selection tolerance without overwriting targets.
	if info.is_empty():
		var city := _pick_city(world, _sp)
		if not city.is_empty():
			info = city
	# Enlarged sites retain their logical one-tile destination. Touch tolerance
	# does not expand lookup, change occupancy, or overwrite adjacent entities.
	if resource_sites != null and (info.is_empty() or info.get("kind", "") == "res"):
		var site: Dictionary = resource_sites.pick(world, _sp)
		if not site.is_empty():
			info = site
	if info.is_empty():
		info = {"kind": "empty", "x": tile.x, "y": tile.y, "pos": Vector3(tile.x + 0.5, world.y, tile.y + 0.5)}
	_select(info)


func _select(info: Dictionary) -> void:
	selected = info
	p_action.disabled = false
	p_recall.visible = false
	var pos: Vector3 = info["pos"]
	var rr := 1.0
	match info["kind"]:
		"res":
			p_title.text = "%s  Lv.%d" % [RES_NAMES[info["t"]], info["l"]]
			p_sub.text = "مورد قابل للجمع"
			p_info.text = "الكمية المتوقعة: %s" % _fmt(RES_GAIN[info["t"]] * info["l"])
			p_action.text = "جمع"
			rr = MapVisuals.RESOURCE_RING_RADIUS
		"beast":
			p_title.text = "%s  Lv.%d" % [BEAST_NAMES[info["t"]], info["l"]]
			p_sub.text = "وحش بري"
			p_info.text = "القوة المقدّرة: %s" % _fmt(info["l"] * 3500)
			p_action.text = "هجوم"
			rr = 1.0
		"city":
			p_title.text = "%s  Lv.%d" % [info["n"], info["l"]]
			if info["team"] == "me":
				p_sub.text = TEAM_NAMES[info["team"]]
				p_info.text = "مدينتك — مركز إنتاجك وجيشك"
				p_action.text = "دخول المدينة"
			else:
				p_sub.text = "مدينة خصمة — تتحارب المدن الأربع على «عرس الإقليم» في المنتصف"
				p_info.text = "اقهر حرّاس المبنى قبلهم لتستحوذ على مكافآته"
				p_action.text = "حرب الإقليم"
				p_action.disabled = true
			rr = MapVisuals.CITY_RING_RADIUS
		"aurs":
			RegionWar.ensure(Game)
			p_title.text = "عرس الإقليم"
			if RegionWar.holder_id(Game) == "me":
				var gn := RegionWar.garrison_total(Game)
				p_sub.text = "تحت سيطرتك — الحامية: %d جندي" % gn
				p_info.text = "إنتاج المدينة +15٪ لكل مورد • جواهر وبلورات كل %s — حصّنه فمدن الخصوم ستعاود الهجوم"
				p_action.text = "تعزيز الحامية"
				p_recall.visible = true
				p_recall.disabled = gn <= 0
			else:
				var d := RegionWar.defenders(Game)
				p_sub.text = "بيد: %s" % RegionWar.holder_name(Game)
				p_info.text = "حرّاس المبنى: نحو %d — احتله لتفوز بإنتاج +15٪ ومكافآت دورية" % int(d["n"])
				p_action.text = "أرسل فرقة عسكرية"
			rr = 9.0
		_:
			p_title.text = "أرض خارجية"
			p_sub.text = "خريطة الإقليم الصغير"
			p_info.text = "أربع مدن تتحارب على «عرس الإقليم» في المنتصف — لا نقل للمدينة هنا"
			p_action.text = "—"
			p_action.disabled = true
			rr = 1.0
	p_sub.text += "   •   X: %d  Y: %d" % [info["x"], info["y"]]
	panel.visible = true
	if tools_sheet != null:
		tools_sheet.visible = false
	sel_ring.visible = true
	sel_ring.position = pos + Vector3(0, 0.15, 0)
	sel_rr = rr


func _on_action() -> void:
	if selected.is_empty():
		return
	var info := selected
	if info["kind"] == "city" and info["team"] == "me":
		_go_city()
	elif info["kind"] == "city":
		_toast("المعارك تُحسم عند عرس الإقليم في منتصف الإقليم — اضغط عليه لإرسال فرقتك")
	elif info["kind"] == "aurs":
		if not Game.venture.is_empty():
			_toast("الفرقة العسكرية في مهمة بالفعل")
		else:
			_open_venture_window({"kind": "aurs", "n": "عرس الإقليم"})
	elif Game.start_march(info):
		Sound.play("march")
		var m: Dictionary = Game.marches.back()
		_toast("انطلقت الفرقة — الوصول خلال %s" % Defs.fmt_time(float(m["arrive"]) - Game.now()))
	_close_panel()


func _on_recall() -> void:
	## سحب حامية عرس الإقليم إلى المدينة — المبنى يعود محايدًا
	var n := RegionWar.recall(Game)
	_close_panel()
	if n > 0:
		_toast("عادت الحامية (%d جندي) إلى المدينة — عاد عرس الإقليم محايدًا" % n)
	else:
		_toast("لا حامية لسحبها")
