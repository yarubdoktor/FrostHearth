extends RefCounted
## حرب الإقليم — منطق نقصي (بلا Node): أربع مدن تتنازع مبنى «عرس الإقليم».
## مدينتك + ثلاث مدن خصوم تتحارب على المبنى المركزي؛ من يحتله يربح إنتاجًا
## إضافيًا ومكافآت دورية. كل الدوال static وتقرأ/تكتب حالة اللعبة عبر Game.
## تخطيط الإقليم كله (المواضع والأسماء) مصدره الوحيد Defs.

const Defs := preload("res://scripts/defs.gd")
const Combat := preload("res://scripts/combat.gd")


static func defaults(t: float) -> Dictionary:
	## حالة حرب الإقليم الجديدة: المبنى محايد بيد حرّاس مستقلين
	return {"holder": "none", "units": {}, "garrison_p": float(Defs.AURS_BASE_GARRISON),
		"sieges": [], "start": t, "next_attack": t + Defs.AURS_FIRST_ATTACK, "reward_t": 0.0}


static func ensure(g: Node) -> void:
	if g.region.is_empty():
		g.region = defaults(g.now())


static func holder_id(g: Node) -> String:
	return str(g.region.get("holder", "none"))


static func holder_name(g: Node) -> String:
	var h := holder_id(g)
	if h == "me":
		return "مدينتك"
	if h == "none":
		return "حرّاس محايدون"
	for c in Defs.RIVAL_CITIES:
		if str(c["id"]) == h:
			return str(c["n"])
	return "حرّاس محايدون"


static func holder_color(g: Node) -> Color:
	var h := holder_id(g)
	if h == "me":
		return Color("ffd36b")
	if h == "none":
		return Color.WHITE
	for c in Defs.RIVAL_CITIES:
		if str(c["id"]) == h:
			return Color(String(c["col"]))
	return Color.WHITE


static func city_def(id: String) -> Dictionary:
	for c in Defs.RIVAL_CITIES:
		if str(c["id"]) == id:
			return c
	return {}


static func ai_power(g: Node, t: float) -> float:
	## قوة مدن الخصوم تنمو ببطء مع عمر الإقليم (سقف ×2.5)
	var age := maxf(t - float(g.region.get("start", t)), 0.0)
	return 1.0 + minf(age * Defs.AURS_AI_GROWTH, 1.5)


static func garrison_units(g: Node) -> Dictionary:
	## حامية المبنى الفعلية — وحدات حقيقية محفوظة إذا كانت بيد اللاعب
	var out: Dictionary = g.region.get("units", {})
	return out.duplicate(true)


static func garrison_total(g: Node) -> int:
	var n := 0
	for k in g.region.get("units", {}):
		n += int(g.region["units"][k])
	return n


static func defenders(g: Node) -> Dictionary:
	## حرّاس المبنى الحاليون: {n, name, stats} — مصدر واحد للمعاينة والمعركة الفعلية
	var h := holder_id(g)
	if h == "me":
		return {"n": garrison_total(g), "type": "aurs", "name": "عرس الإقليم — حاميتك",
			"stats": {"atk": 10.0, "def": 7.0, "hp": 30.0, "name": "حاميتك"}}
	var p := 1.0 if h == "none" else ai_power(g, g.now())
	var n := maxi(int(round(float(Defs.AURS_BASE_GARRISON) * (0.7 + 0.3 * p))), 6)
	var s := 1.0 + 0.15 * p
	return {"n": n, "type": "aurs", "name": "عرس الإقليم",
		"stats": {"atk": 9.0 * s, "def": 6.5 * s, "hp": 26.0 * s, "name": "حرّاس المبنى"}}


# ================================================================ حلقة الزمن (تُستدعى من _simulate بزمنها المجدول)
static func tick(g: Node, t: float) -> void:
	ensure(g)
	var r: Dictionary = g.region
	# مكافأة الاحتفاظ الدورية لمدينتك
	if holder_id(g) == "me":
		if float(r.get("reward_t", 0.0)) <= 0.0:
			r["reward_t"] = t + Defs.AURS_REWARD_EVERY
		elif t >= float(r["reward_t"]):
			r["reward_t"] = t + Defs.AURS_REWARD_EVERY
			g.give(Defs.AURS_REWARD.duplicate())
			if not g._offline:
				g.toast.emit("مكافأة عرس الإقليم: 6 جواهر و5 بلورات شفق")
	else:
		r["reward_t"] = 0.0
	# جدولة هجمات مدن الخصوم على المبنى
	if float(r.get("next_attack", 0.0)) <= t:
		var attacker := _pick_attacker(g)
		if attacker != "":
			var c := city_def(attacker)
			var d := Vector2(float(Defs.AURS["x"]) - float(c["x"]), float(Defs.AURS["y"]) - float(c["y"])).length()
			var power := _siege_power(g, t)
			r["sieges"].append({"id": "s_%d_%d" % [int(t), randi() % 10000], "city": attacker,
				"power": power, "start": t, "arrive": t + d / Defs.AURS_SIEGE_SPEED})
			r["next_attack"] = t + Defs.AURS_ATTACK_EVERY * randf_range(0.75, 1.35)
			if not g._offline:
				g.toast.emit("قوة من %s تتجه نحو عرس الإقليم" % str(c["n"]))
			g.region_changed.emit()
		else:
			r["next_attack"] = t + 120.0
	# حسم الوصولات بترتيبها الزمني — بنداء واحد لكل حصار
	var arr: Array = r["sieges"]
	if arr.is_empty():
		return
	arr.sort_custom(func(a, b): return float(a["arrive"]) < float(b["arrive"]))
	var changed := false
	while not arr.is_empty() and float(arr[0]["arrive"]) <= t:
		resolve_siege(g, arr[0], t)
		arr.pop_front()
		changed = true
	if changed:
		g.region_changed.emit()


static func _pick_attacker(g: Node) -> String:
	## مدينة خصم عشوائية — غير صاحبة المبنى الحالية
	var pool: Array = []
	var h := holder_id(g)
	for c in Defs.RIVAL_CITIES:
		if str(c["id"]) != h:
			pool.append(str(c["id"]))
	if pool.is_empty():
		return ""
	return str(pool[randi() % pool.size()])


static func _siege_power(g: Node, t: float) -> float:
	return float(Defs.AURS_BASE_GARRISON) * (0.8 + 0.6 * ai_power(g, t)) * randf_range(0.85, 1.2)


# ================================================================ حسم المعارك
static func resolve_siege(g: Node, siege: Dictionary, t: float) -> void:
	var h := holder_id(g)
	var city := str(siege["city"])
	if h == city:
		return   # لا معركة على مبنى يملكه المهاجم نفسه
	if h == "me":
		_defend_player_held(g, siege, t)
	else:
		_battle_ai(g, siege, t)


static func _battle_ai(g: Node, siege: Dictionary, t: float) -> void:
	## خصم ضد حرّاس/خصم آخر: حسم نسبي بالقوة — الباقي من قوة المنتصر يصير حامية جديدة
	var att := float(siege["power"])
	var def_p := maxf(float(g.region.get("garrison_p", float(Defs.AURS_BASE_GARRISON))), 4.0)
	var chance := att / maxf(att + def_p, 1.0)
	if randf() < chance:
		g.region["holder"] = str(siege["city"])
		g.region["garrison_p"] = att * randf_range(0.55, 0.8)
	else:
		g.region["garrison_p"] = maxf(def_p * randf_range(0.6, 0.85), 6.0)


static func _defend_player_held(g: Node, siege: Dictionary, t: float) -> void:
	## هجوم خصم على مبنى تحرسه حاميتك: معركة حقيقية بمنطق اللعبة نفسه
	var units := garrison_units(g)
	var att_n := maxi(int(round(float(siege["power"]))), 4)
	var s := 1.0 + 0.15 * ai_power(g, t)
	var att_stats := {"atk": 9.5 * s, "def": 6.5 * s, "hp": 27.0 * s, "name": "جيش المدينة الخصمة"}
	var mods: Dictionary = g.army_mods(g.defender)
	var rep: Dictionary = Combat.fight({"beast": att_n}, {"beast": att_stats}, units, mods, g.storm_active(t))
	var left := {}
	for k in rep["def_left"]:
		left[k] = int(rep["def_left"][k])
	g.region["units"] = left
	_apply_garrison_losses(g, rep["def_loss"])
	var cname := str(city_def(str(siege["city"])).get("n", "مدينة خصمة"))
	if bool(rep["att_win"]):
		# سقط المبنى: الناجون القليلون من حاميتك يعودون إلى المدينة
		for k in left:
			g.troops[k] = int(g.troops.get(k, 0)) + int(left[k])
		g.region["units"] = {}
		g.region["garrison_p"] = att_n * 0.7
		g.region["holder"] = str(siege["city"])
		if not g._offline:
			g.toast.emit("سقط عرس الإقليم بيد %s — أرسل فرقة لاستعادته" % cname)
	else:
		if not g._offline:
			g.toast.emit("صدّت حاميتك هجوم %s عن عرس الإقليم" % cname)


static func _apply_garrison_losses(g: Node, def_loss: Dictionary) -> void:
	## خسائر الحامية: قتلى وجرحى وفق قواعد اللعبة (نفس منطق الغارات)
	var room := maxi(g.wounded_cap() - g.wounded_total(), 0)
	for k in def_loss:
		var lost := int(def_loss[k])
		if lost <= 0:
			continue
		var dead := int(round(lost * 0.25 * g.death_mult(k)))
		var w := mini(lost - dead, room)
		room -= w
		dead += (lost - dead) - w
		g.wounded[k] = int(g.wounded.get(k, 0)) + w


# ================================================================ بيد اللاعب
static func player_capture(g: Node, survivors: Dictionary, t: float) -> void:
	## احتلال المبنى: الناجون يصبحون حاميته (نُقلوا مرة واحدة فقط)
	ensure(g)
	g.region["holder"] = "me"
	var units := garrison_units(g)
	for k in survivors:
		units[k] = int(units.get(k, 0)) + int(survivors[k])
	g.region["units"] = units
	g.region["garrison_p"] = 0.0
	g.region["reward_t"] = t + Defs.AURS_REWARD_EVERY
	g.region_changed.emit()


static func reinforce(g: Node, extra: Dictionary) -> void:
	## تعزيز يصل سلمًا إلى مبنى تحت سيطرتك
	var units := garrison_units(g)
	for k in extra:
		units[k] = int(units.get(k, 0)) + int(extra[k])
	g.region["units"] = units
	g.region_changed.emit()


static func recall(g: Node) -> int:
	## سحب الحامية إلى المدينة — المبنى يعود محايدًا بيد حرّاسه الأساسيين
	var n := 0
	for k in g.region.get("units", {}):
		g.troops[k] = int(g.troops.get(k, 0)) + int(g.region["units"][k])
		n += int(g.region["units"][k])
	if n > 0:
		g.region["units"] = {}
		g.region["holder"] = "none"
		g.region["garrison_p"] = float(Defs.AURS_BASE_GARRISON)
		g.region_changed.emit()
	return n
