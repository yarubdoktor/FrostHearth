extends Node3D
## المرحلة 34 — مؤثرات الفرن والرياح. ملف مستقل بلا أي منطق لعب: يقرأ حالة الفرن فقط ويرسم.
## يشمل: لهب تاجي برتقالي حول المدخنة، لسان لهب من فوهتها، ألسنة من الأبواب الأربعة، شرر وجمر،
## دخان بطبقتين، تموّج هواء ساخن (هيكا)، توهج برتقالي على الثلج، رياح متقطعة تميل معها كل الجسيمات،
## وخطوط ريح خفيفة تعبر المدينة. كل شيء جسيمات CPU وقوام مولَّد برمجيًا (لا ملفات صور).
## مواقع الهندسة مأخوذة من tools/build_city.py دالة furnace(t): r = 4.2+0.6t، قمة الجسم = 1.9+3.5+1.6t.

const CENTER := Vector3(60, 0, 60)
const HazeShader := preload("res://shaders/heat_haze.gdshader")

var tier := -1
var high := true
var furnace_on := false
var furnace_mode := 1
var storm := false
var wind := Vector3(0.9, 0.0, 0.3)        # متجه الريح الحالي (م/ث تقريبًا)
var wind_strength := 1.0

var smoke: CPUParticles3D                  # دخان المدخنة الرئيسي
var smoke_dark: CPUParticles3D             # طبقة سخام داكنة قريبة من الفوهة
var crown: CPUParticles3D                  # لهب حلقي حول المدخنة
var tongue: CPUParticles3D                 # لسان لهب من فوهة المدخنة
var door_flames: Array[CPUParticles3D] = []
var sparks: CPUParticles3D
var boost_sparks: CPUParticles3D           # شرر إضافي للوضع المضاعف
var embers: CPUParticles3D                 # جمر يتصاعد من قاعدة الفرن
var streaks: CPUParticles3D                # خطوط ريح
var haze: MeshInstance3D
var glow: MeshInstance3D
var chimneys: Array = []                   # مداخن البيوت (دخان خفيف)

var _t := 0.0
var _applied_on := false
var _applied_boost := false
var _flame_tex: ImageTexture
var _puff_tex: ImageTexture
var _dot_tex: ImageTexture
var _streak_tex: ImageTexture
var _glow_mat: StandardMaterial3D
var _streak_mat: StandardMaterial3D
var _haze_mat: ShaderMaterial


func _ready() -> void:
	position = CENTER
	_flame_tex = _make_flame_texture()
	_puff_tex = _make_radial_texture(48, 2.0)
	_dot_tex = _make_radial_texture(16, 3.0)
	_streak_tex = _make_streak_texture()
	_build()
	set_tier(0)


# ================================================================ القوام المولَّد
func _make_flame_texture() -> ImageTexture:
	## قطرة لهب: عريضة من الأسفل ودقيقة في الأعلى، حواف ناعمة
	var w := 32
	var h := 64
	var img := Image.create(w, h, false, Image.FORMAT_RGBA8)
	for y in h:
		var v := float(y) / float(h - 1)             # 0 أعلى ← 1 أسفل
		var half := lerpf(0.10, 0.95, pow(v, 0.65))
		var fade := clampf(1.0 - pow(v, 6.0) * 0.55, 0.0, 1.0)
		for x in w:
			var u := absf((float(x) - (w - 1) * 0.5) / ((w - 1) * 0.5))
			var d := u / half
			var a := clampf(1.0 - d * d, 0.0, 1.0) * fade
			a = pow(a, 0.8) * clampf(v * 6.0, 0.0, 1.0)
			img.set_pixel(x, y, Color(1, 1, 1, a))
	return ImageTexture.create_from_image(img)


func _make_radial_texture(size: int, power: float) -> ImageTexture:
	var img := Image.create(size, size, false, Image.FORMAT_RGBA8)
	var c := (size - 1) * 0.5
	for y in size:
		for x in size:
			var d := Vector2(x - c, y - c).length() / c
			var a := pow(clampf(1.0 - d, 0.0, 1.0), power)
			img.set_pixel(x, y, Color(1, 1, 1, a))
	return ImageTexture.create_from_image(img)


func _make_streak_texture() -> ImageTexture:
	## خط ريح: رفيع، يتلاشى من الطرفين
	var w := 64
	var h := 8
	var img := Image.create(w, h, false, Image.FORMAT_RGBA8)
	for y in h:
		var vy := 1.0 - absf((float(y) - (h - 1) * 0.5) / ((h - 1) * 0.5))
		for x in w:
			var ux := 1.0 - absf((float(x) - (w - 1) * 0.5) / ((w - 1) * 0.5))
			img.set_pixel(x, y, Color(1, 1, 1, pow(ux, 1.4) * pow(vy, 1.5)))
	return ImageTexture.create_from_image(img)


# ================================================================ أدوات
func _ramp(offs: Array, cols: Array) -> Gradient:
	var g := Gradient.new()
	g.offsets = PackedFloat32Array(offs)
	g.colors = PackedColorArray(cols)
	return g


func _curve(points: Array) -> Curve:
	var c := Curve.new()
	for p in points:
		c.add_point(Vector2(p[0], p[1]))
	return c


func _emitter(parent: Node3D, amount: int, life: float, tex: Texture2D, ramp: Gradient,
		additive: bool, size: Vector2) -> CPUParticles3D:
	var p := CPUParticles3D.new()
	p.set_meta("base_amount", amount)
	p.amount = amount if high else maxi(4, int(amount * 0.5))
	p.lifetime = life
	p.preprocess = life
	p.local_coords = false
	p.emitting = false
	p.color_ramp = ramp
	var q := QuadMesh.new()
	q.size = size
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD if additive else BaseMaterial3D.BLEND_MODE_MIX
	m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	m.billboard_keep_scale = true
	m.vertex_color_use_as_albedo = true
	m.albedo_texture = tex
	m.disable_fog = additive
	q.material = m
	p.mesh = q
	parent.add_child(p)
	return p


func _fire_ramp() -> Gradient:
	## أبيض-أصفر عند الجذر ← برتقالي صريح ← أحمر جمري ← يتلاشى. البرتقالي هو اللون الغالب
	return _ramp([0.0, 0.10, 0.42, 0.78, 1.0], [
		Color(1.0, 0.86, 0.45, 0.0), Color(1.0, 0.74, 0.26, 0.95), Color(1.0, 0.46, 0.07, 0.85),
		Color(0.86, 0.2, 0.03, 0.42), Color(0.3, 0.05, 0.0, 0.0)])


# ================================================================ البناء
func _build() -> void:
	var fire := _fire_ramp()
	var shrink := _curve([[0.0, 1.0], [0.55, 0.7], [1.0, 0.12]])

	# لهب تاجي حول المدخنة
	crown = _emitter(self, 30, 1.0, _flame_tex, fire, true, Vector2(1.1, 1.7))
	crown.emission_shape = CPUParticles3D.EMISSION_SHAPE_RING
	crown.emission_ring_axis = Vector3.UP
	crown.emission_ring_height = 0.1
	crown.direction = Vector3(0, 1, 0)
	crown.spread = 14.0
	crown.initial_velocity_min = 1.0
	crown.initial_velocity_max = 2.2
	crown.scale_amount_min = 0.8
	crown.scale_amount_max = 1.3
	crown.scale_amount_curve = shrink

	# لسان اللهب من فوهة المدخنة
	tongue = _emitter(self, 22, 0.85, _flame_tex, fire, true, Vector2(0.9, 1.7))
	tongue.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
	tongue.emission_sphere_radius = 0.35
	tongue.direction = Vector3(0, 1, 0)
	tongue.spread = 10.0
	tongue.initial_velocity_min = 2.2
	tongue.initial_velocity_max = 3.8
	tongue.scale_amount_min = 0.7
	tongue.scale_amount_max = 1.2
	tongue.scale_amount_curve = shrink

	# ألسنة الأبواب الأربعة
	for k in 4:
		var d := _emitter(self, 9, 0.6, _flame_tex, fire, true, Vector2(0.55, 0.9))
		d.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
		d.emission_box_extents = Vector3(0.35, 0.25, 0.1)
		d.spread = 18.0
		d.initial_velocity_min = 0.4
		d.initial_velocity_max = 0.9
		d.scale_amount_curve = shrink
		door_flames.append(d)

	# شرر: أصفر ساخن ← برتقالي ← أحمر
	var spark_ramp := _ramp([0.0, 0.25, 0.7, 1.0], [
		Color(1.0, 0.95, 0.6, 1.0), Color(1.0, 0.62, 0.15, 1.0),
		Color(0.95, 0.28, 0.05, 0.7), Color(0.4, 0.06, 0.0, 0.0)])
	sparks = _emitter(self, 36, 2.6, _dot_tex, spark_ramp, true, Vector2(0.16, 0.16))
	_setup_sparks(sparks, 2.5, 5.0, 28.0)
	boost_sparks = _emitter(self, 40, 2.2, _dot_tex, spark_ramp, true, Vector2(0.2, 0.2))
	_setup_sparks(boost_sparks, 4.5, 8.5, 40.0)

	# جمر قاعدة الفرن
	embers = _emitter(self, 22, 2.8, _dot_tex, spark_ramp, true, Vector2(0.13, 0.13))
	embers.emission_shape = CPUParticles3D.EMISSION_SHAPE_RING
	embers.emission_ring_axis = Vector3.UP
	embers.emission_ring_height = 0.05
	embers.direction = Vector3(0, 1, 0)
	embers.spread = 25.0
	embers.initial_velocity_min = 0.4
	embers.initial_velocity_max = 1.1

	# دخان: سخام داكن قريب ثم رماد فاتح يتّسع ويختفي، بصبغة برتقالية خفيفة قرب النار
	var dark_ramp := _ramp([0.0, 0.12, 0.55, 1.0], [
		Color(0.34, 0.2, 0.12, 0.0), Color(0.16, 0.15, 0.16, 0.5),
		Color(0.34, 0.35, 0.38, 0.3), Color(0.6, 0.62, 0.66, 0.0)])
	smoke_dark = _emitter(self, 26, 3.4, _puff_tex, dark_ramp, false, Vector2(1.5, 1.5))
	_setup_smoke(smoke_dark, 1.6, 2.6, 0.7, 2.0)
	var smoke_ramp := _ramp([0.0, 0.15, 0.6, 1.0], [
		Color(0.4, 0.3, 0.25, 0.0), Color(0.42, 0.43, 0.47, 0.5),
		Color(0.66, 0.68, 0.73, 0.3), Color(0.88, 0.9, 0.94, 0.0)])
	smoke = _emitter(self, 50, 6.5, _puff_tex, smoke_ramp, false, Vector2(1.8, 1.8))
	_setup_smoke(smoke, 1.3, 2.3, 0.6, 2.8)

	# توهج برتقالي على الثلج حول الفرن
	glow = MeshInstance3D.new()
	var gq := QuadMesh.new()
	gq.size = Vector2(30, 30)
	glow.mesh = gq
	glow.rotation_degrees = Vector3(-90, 0, 0)
	glow.position = Vector3(0, 0.14, 0)
	_glow_mat = StandardMaterial3D.new()
	_glow_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_glow_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_glow_mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	_glow_mat.albedo_texture = _make_radial_texture(64, 1.6)
	_glow_mat.albedo_color = Color(1.0, 0.45, 0.1, 0.0)
	_glow_mat.disable_fog = true
	_glow_mat.render_priority = 1
	glow.material_override = _glow_mat
	glow.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(glow)

	# هيكا: تموّج الهواء الساخن
	haze = MeshInstance3D.new()
	var hq := QuadMesh.new()
	hq.size = Vector2(7.0, 9.0)
	haze.mesh = hq
	_haze_mat = ShaderMaterial.new()
	_haze_mat.shader = HazeShader
	_haze_mat.set_shader_parameter("strength", 0.0)
	haze.material_override = _haze_mat
	haze.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(haze)

	# خطوط ريح تعبر المدينة
	var sramp := _ramp([0.0, 0.2, 0.8, 1.0], [
		Color(1, 1, 1, 0.0), Color(0.92, 0.96, 1.0, 0.5), Color(0.92, 0.96, 1.0, 0.4), Color(1, 1, 1, 0.0)])
	streaks = _emitter(self, 26, 4.2, _streak_tex, sramp, true, Vector2(5.0, 0.35))
	streaks.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	streaks.emission_box_extents = Vector3(2.0, 5.0, 46.0)
	streaks.position = Vector3(-50, 8, 0)
	streaks.direction = Vector3(1, 0, 0.15)
	streaks.spread = 4.0
	streaks.initial_velocity_min = 20.0
	streaks.initial_velocity_max = 27.0
	streaks.gravity = Vector3.ZERO
	streaks.preprocess = 0.0
	_streak_mat = ((streaks.mesh as QuadMesh).material) as StandardMaterial3D


func _setup_sparks(p: CPUParticles3D, v_min: float, v_max: float, spread: float) -> void:
	p.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
	p.emission_sphere_radius = 0.45
	p.direction = Vector3(0, 1, 0)
	p.spread = spread
	p.initial_velocity_min = v_min
	p.initial_velocity_max = v_max
	p.damping_min = 0.4
	p.damping_max = 0.9
	p.scale_amount_min = 0.6
	p.scale_amount_max = 1.4


func _setup_smoke(p: CPUParticles3D, v_min: float, v_max: float, s_from: float, s_to: float) -> void:
	p.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
	p.emission_sphere_radius = 0.5
	p.direction = Vector3(0, 1, 0)
	p.spread = 11.0
	p.initial_velocity_min = v_min
	p.initial_velocity_max = v_max
	p.scale_amount_min = 0.8
	p.scale_amount_max = 1.2
	p.angle_min = -90.0
	p.angle_max = 90.0
	p.scale_amount_curve = _curve([[0.0, s_from * 0.5], [1.0, s_to]])


# ================================================================ الهندسة حسب المرحلة البصرية
func geometry(t: int) -> Dictionary:
	## نفس معادلات build_city.py: furnace(t)
	var r := 4.2 + t * 0.6
	var h := 3.5 + t * 1.6
	var top := 1.9 + h
	return {"r": r, "top": top, "mouth": top + 3.5 + t}


func set_tier(t: int) -> void:
	t = clampi(t, 0, 2)
	if t == tier:
		return
	tier = t
	var g := geometry(t)
	var r: float = g["r"]
	var top: float = g["top"]
	var mouth: float = g["mouth"]
	crown.position = Vector3(0, top + 0.15, 0)
	crown.emission_ring_radius = r * 0.5
	crown.emission_ring_inner_radius = r * 0.3
	tongue.position = Vector3(0, mouth, 0)
	sparks.position = Vector3(0, mouth + 0.2, 0)
	boost_sparks.position = Vector3(0, mouth + 0.2, 0)
	smoke_dark.position = Vector3(0, mouth + 0.6, 0)
	smoke.position = Vector3(0, mouth + 1.0, 0)
	embers.position = Vector3(0, 0.62, 0)
	embers.emission_ring_radius = r * 0.88
	embers.emission_ring_inner_radius = r * 0.72
	for k in 4:
		var ang := k * PI / 2.0 + PI / 4.0
		var d := door_flames[k]
		d.position = Vector3(cos(ang) * (r * 0.6 + 0.3), 2.0, sin(ang) * (r * 0.6 + 0.3))
		d.direction = Vector3(cos(ang), 0.6, sin(ang))
	glow.position = Vector3(0, 0.14, 0)
	(glow.mesh as QuadMesh).size = Vector2.ONE * (r * 2.0 + 20.0)
	haze.position = Vector3(0, mouth + 3.2, 0)


func set_quality(is_high: bool) -> void:
	if is_high == high:
		return
	high = is_high
	var all: Array = [crown, tongue, sparks, boost_sparks, embers, smoke, smoke_dark, streaks] + door_flames + chimneys
	for p in all:
		if is_instance_valid(p) and p.has_meta("base_amount"):
			var n: int = int(p.get_meta("base_amount"))
			p.amount = n if high else maxi(4, int(n * 0.5))
	haze.visible = high


# ================================================================ مداخن البيوت
func add_chimney(parent: Node3D, pos: Vector3) -> CPUParticles3D:
	## خيط دخان رفيع من مدخنة بيت — يتبع الرياح ويتوقف عند إطفاء الفرن
	var ramp := _ramp([0.0, 0.2, 1.0], [
		Color(0.5, 0.45, 0.42, 0.0), Color(0.55, 0.56, 0.6, 0.4), Color(0.9, 0.92, 0.96, 0.0)])
	var p := _emitter(parent, 9, 3.4, _puff_tex, ramp, false, Vector2(0.8, 0.8))
	p.position = pos
	p.direction = Vector3(0, 1, 0)
	p.spread = 8.0
	p.initial_velocity_min = 0.7
	p.initial_velocity_max = 1.2
	p.scale_amount_curve = _curve([[0.0, 0.4], [1.0, 1.7]])
	p.emitting = furnace_on
	chimneys.append(p)
	return p


func remove_chimney(p: CPUParticles3D) -> void:
	chimneys.erase(p)
	if is_instance_valid(p):
		p.queue_free()


# ================================================================ كل إطار
func _update_wind(delta: float) -> void:
	var base := 0.9 + (3.0 if storm else 0.0)
	var gust := maxf(0.0, sin(_t * 0.37) * sin(_t * 0.91 + 1.3)) * (4.0 if storm else 2.2)
	wind_strength = lerpf(wind_strength, base + gust, clampf(delta * 1.5, 0.0, 1.0))
	var ang := 0.35 + sin(_t * 0.23) * 0.25
	wind = Vector3(cos(ang), 0.0, sin(ang)) * wind_strength


func update(delta: float, is_on: bool, mode: int, t_tier: int, is_storm: bool,
		light: OmniLight3D, cam_dist: float) -> void:
	_t += delta
	storm = is_storm
	furnace_on = is_on
	furnace_mode = mode
	set_tier(t_tier)
	_update_wind(delta)
	var boost := is_on and mode == 2
	# تشغيل/إطفاء — عند الإطفاء تُكمل الجسيمات الموجودة عمرها فتخبو طبيعيًا
	if is_on != _applied_on:
		_applied_on = is_on
		for p in [crown, tongue, sparks, embers, smoke, smoke_dark] + door_flames:
			p.emitting = is_on
	if boost != _applied_boost:
		_applied_boost = boost
		boost_sparks.emitting = boost
	# الرياح تميل بها الجسيمات: كلما ارتفع الجسيم كان الميل أشد
	var w := wind
	smoke.gravity = Vector3(w.x * 0.9, 0.9, w.z * 0.9)
	smoke_dark.gravity = Vector3(w.x * 0.7, 0.7, w.z * 0.7)
	sparks.gravity = Vector3(w.x * 1.7, -0.5, w.z * 1.7)
	boost_sparks.gravity = Vector3(w.x * 1.7, -0.7, w.z * 1.7)
	embers.gravity = Vector3(w.x * 0.8, 0.35, w.z * 0.8)
	crown.gravity = Vector3(w.x * 0.35, 1.4, w.z * 0.35)
	for d in door_flames:
		d.gravity = Vector3(w.x * 0.25, 1.0, w.z * 0.25)
	tongue.gravity = Vector3(w.x * 0.45, 1.8, w.z * 0.45)
	var lean := 0.07
	crown.direction = Vector3(w.x * lean, 1, w.z * lean)
	tongue.direction = Vector3(w.x * lean * 1.3, 1, w.z * lean * 1.3)
	# الوضع المضاعف: لهب أكبر وأكثف
	var s := 1.35 if mode == 2 else 1.0
	crown.scale_amount_min = 0.8 * s
	crown.scale_amount_max = 1.3 * s
	tongue.scale_amount_min = 0.7 * s
	tongue.scale_amount_max = 1.2 * s
	for p in chimneys:
		if is_instance_valid(p):
			p.emitting = is_on and cam_dist < 70.0
			p.gravity = Vector3(w.x * 0.6, 0.6, w.z * 0.6)
	_update_light_and_glow(light, is_on, mode)
	_update_streaks(cam_dist)


func _flicker() -> float:
	return 0.5 + 0.5 * (sin(_t * 13.0) * 0.5 + sin(_t * 7.3 + 1.7) * 0.3 + sin(_t * 23.1 + 0.4) * 0.2)


func _update_light_and_glow(light: OmniLight3D, is_on: bool, mode: int) -> void:
	var f := _flicker()
	var target := 0.0 if not is_on else (2.2 if mode == 1 else 4.0)
	if light != null:
		light.light_energy = lerpf(light.light_energy, target * (0.82 + 0.3 * f), 0.15)
		# برتقالي دافئ يميل للأصفر مع كل وميضة
		light.light_color = Color(1.0, 0.5, 0.15).lerp(Color(1.0, 0.7, 0.3), f * 0.6)
		light.position = CENTER + Vector3(0, geometry(tier)["top"] + 2.0, 0)
	var ga := _glow_mat.albedo_color.a
	var ga_t := 0.0 if not is_on else (0.34 if mode == 1 else 0.52) * (0.85 + 0.25 * f)
	_glow_mat.albedo_color = Color(1.0, lerpf(0.4, 0.55, f), 0.1, lerpf(ga, ga_t, 0.1))
	var hs := 0.0 if not is_on else (0.7 if mode == 1 else 1.0)
	_haze_mat.set_shader_parameter("strength", hs * (0.0 if not high else 1.0))


func _update_streaks(cam_dist: float) -> void:
	## الخطوط تظهر مع الهبّات فقط: خفية في الهدوء، واضحة في العاصفة
	var vis := clampf((wind_strength - 1.6) / 2.6, 0.0, 1.0)
	streaks.emitting = vis > 0.05 and cam_dist < 80.0
	if _streak_mat != null:
		_streak_mat.albedo_color = Color(1, 1, 1, vis * 0.9)
	streaks.speed_scale = 1.0 + vis * 0.6
