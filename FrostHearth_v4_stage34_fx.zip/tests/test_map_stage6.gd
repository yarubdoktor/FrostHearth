extends Node
## اختبار واجهة الخريطة — أعيدت كتابته لتصميم الإقليم المصغّر (المرحلة 23+):
## لا ضباب حرب، لا معاقل landmarks، المدن والمنفث هما عناصر الخريطة.
## التشغيل: godot --headless --path . res://tests/test_map_stage6.tscn

var ok := true

func fail(why: String) -> void:
	print("FAIL: " + why)
	ok = false

func _ready() -> void:
	Game.save_path_override = "user://frost_save_test_map6.json"
	Game.new_game()   # بيئة اختبار نظيفة
	var map_scene: PackedScene = load("res://world_map.tscn")
	var map: Node3D = map_scene.instantiate()
	add_child(map)
	await get_tree().process_frame
	await get_tree().process_frame

	# 0) لا طائرة ضباب ولا نسيج كشف — الإقليم مكشوف بالكامل بقرار تصميمي
	if map.fog_tex != null:
		fail("fog texture should not exist (region fully revealed by design)")
	if map.holds_label != null and map.holds_label.text.find("معاقل") >= 0:
		fail("holds label should be gone (landmarks removed by redesign)")

	# 1) كل نقاط الخريطة مكشوفة واللوحات ظاهرة دومًا
	if not Game.is_explored(5, 5) or not Game.is_explored(90, 90):
		fail("region should be fully explored by design")
	var visible_lm := 0
	for fl in map.fog_labels:
		if (fl["label"] as Label3D).visible:
			visible_lm += 1
	if visible_lm < 3:
		fail("region labels should always be visible (%d visible only)" % visible_lm)

	# 2) المدن الثلاث مسجلة في شبكة التحديد بأسمائها
	var cities := 0
	var seen := {}
	for k in map.lookup:
		var info: Dictionary = map.lookup[k]
		if String(info.get("kind", "")) == "city" and not seen.has(info):
			seen[info] = true
			cities += 1
			if String(info.get("n", "")).is_empty():
				fail("city name missing in lookup")
	if cities != 4:
		fail("expected 4 cities registered (3 rivals + home), got %d" % cities)

	# 3) المنفث: بيانات موجودة بلا عقدة ثلاثية الأبعاد + نافذة الجنود تعمل
	var vx := float(Game.vent["x"])
	var vz := float(Game.vent["y"])
	if Game.vent.is_empty() or not Game.vent.has("x"):
		fail("vent data missing from game state")
	if map.vent_node != null:
		fail("vent 3D node should be removed by region redesign")
	Game.troops = {}
	for tp in ["shield", "spear", "bow"]:
		for t in range(1, 5):
			Game.troops["%s_%d" % [tp, t]] = 5
	map._open_vent_window()
	if map.vent_win == null:
		fail("venture window did not open")
	else:
		if map.vent_spins.size() != 12:
			fail("spin count %d" % map.vent_spins.size())
		await get_tree().process_frame
		await get_tree().process_frame
		if map.vent_win.size.y > map.ui.size.y - 160.0:
			fail("venture window too tall for the screen: %d" % int(map.vent_win.size.y))
		var bottom: float = map.vent_win.position.y + map.vent_win.size.y
		if bottom > map.ui.size.y - 54.0:
			fail("venture window overlaps bottom nav: bottom=%.0f ui=%.0f" % [bottom, map.ui.size.y])
	map._close_vent_window()

	# 4) إرسال فعلي من الواجهة نحو المنفث: الخصم والتسجيل
	Game.venture = {}
	Game.troops = {"shield_1": 20, "bow_2": 10}
	map._open_vent_window()
	map.vent_spins["shield_1"].value = 15
	map._send_venture()
	if Game.venture.is_empty() or int(Game.troops["shield_1"]) != 5:
		fail("venture not started from UI")
	Game.venture = {}
	Game.troops = {}

	# 5) تنظيف ملف الحفظ الاختباري
	DirAccess.remove_absolute(ProjectSettings.globalize_path("user://frost_save_test_map6.json"))
	print("ALL STAGE6 MAP TESTS PASSED" if ok else "SOME STAGE6 MAP TESTS FAILED")
	get_tree().quit(0 if ok else 1)
