extends Node
## اختبار حرب الإقليم — أربع مدن تتحارب على «عرس الإقليم»:
## الجدولة والحسم، الاحتلال والاحتفاظ والمكافآت، صون أعداد الجنود، التعزيز والسحب، الترحيل من الحفظ القديم.
## التشغيل: godot --headless --path . res://test_region_war.tscn

const Defs := preload("res://scripts/defs.gd")
const Combat := preload("res://scripts/combat.gd")
const RegionWar := preload("res://scripts/game/region_war.gd")

var checks := 0
var failures := 0


func check(value: bool, message: String) -> void:
	checks += 1
	if not value:
		failures += 1
	print(("PASS: " if value else "FAIL: ") + message)


func _fresh() -> void:
	Game.save_path_override = "user://frost_save_test_region_war.json"
	Game.dev_mode = false
	Game.new_game()
	Game.set_process(false)


func _sum(d: Dictionary) -> int:
	var s := 0
	for k in d:
		s += int(d[k])
	return s


func _ready() -> void:
	get_window().size = Vector2i(720, 1280)

	# 1) تهيئة جديدة: مبنى محايد وحرّاس أساسيون وأول هجمة مجدولة
	_fresh()
	RegionWar.ensure(Game)
	check(Game.region.get("holder", "") == "none", "new game: building starts neutral")
	check(int(round(float(Game.region.get("garrison_p", 0.0)))) == Defs.AURS_BASE_GARRISON, "neutral garrison is the base value")
	check(float(Game.region.get("next_attack", 0.0)) > Game.now(), "first AI attack is scheduled in the future")
	check(Game.home == Defs.HOME_DEFAULT, "home moved to the region default position")
	check(Game.region.get("sieges", []).is_empty(), "no sieges at start")
	# الخريطة مكشوفة بالكامل — لا ضباب في الإقليم الصغير
	check(Game.is_explored(0, 0) and Game.is_explored(95, 95), "small map fully explored (no fog)")

	# 2) جدولة هجمات الخصوم: تُطلق عند حلول وقتها وتصل بزمن سفر منطقي
	var t0 := Game.now()
	Game.region["next_attack"] = t0 + 1.0
	Game._offline = true   # لا إشعارات أثناء الاختبار
	RegionWar.tick(Game, t0 + 2.0)
	check(Game.region["sieges"].size() == 1, "AI siege launched at its scheduled time")
	var s0: Dictionary = Game.region["sieges"][0]
	var c := RegionWar.city_def(str(s0["city"]))
	check(not c.is_empty(), "siege source is one of the rival cities")
	var dist := Vector2(float(c["x"]) - float(Defs.AURS["x"]), float(c["y"]) - float(Defs.AURS["y"])).length()
	check(absf(float(s0["arrive"]) - float(s0["start"]) - dist / Defs.AURS_SIEGE_SPEED) < 0.01, "siege travel time matches distance and speed")
	check(float(Game.region["next_attack"]) > t0 + 2.0, "next attack rescheduled after launch")
	Game._offline = false

	# 3) حسم الحصار ضد حرّاس محايدين: أحد الطرفين يسقط والقوة تنتقل
	Game._offline = true
	# قوة ساحقة تضمن احتلال الخصم للمبنى
	Game.region["sieges"] = [{"id": "s_test", "city": str(s0["city"]), "power": 500.0, "start": t0, "arrive": t0 + 10.0}]
	RegionWar.tick(Game, t0 + 20.0)
	check(Game.region["sieges"].is_empty(), "siege resolved at its arrival time")
	check(str(Game.region.get("holder")) != "none", "overwhelming AI force captures the neutral building")
	check(float(Game.region.get("garrison_p", 0.0)) > 0.0, "capturing city leaves a garrison behind")
	Game._offline = false

	# 4) احتلال اللاعب: الحملة تنتصر والناجون يصبحون حامية — لا تفقد وحدة واحدة
	_fresh()
	RegionWar.ensure(Game)
	var troops := {"shield_1": 40, "spear_1": 30, "bow_1": 30}
	Game.troops = troops.duplicate()
	var venture_units := {"shield_1": 10, "spear_1": 10, "bow_1": 10}
	for k in venture_units:
		Game.troops[k] = int(Game.troops[k]) - int(venture_units[k])
	Game.venture = {"units": venture_units, "mods": Game.army_mods(Game.defender), "guards_f": 1,
		"formation": "balanced", "target": {"kind": "aurs"}, "resolved": false}
	Game._resolve_aurs_battle(Game.now())
	check(bool(Game.venture.get("resolved", false)), "aurs venture resolved")
	var won := bool(Game.venture.get("won", false)) or RegionWar.holder_id(Game) == "me"
	check(won, "player force defeats neutral guards and captures the building")
	check(RegionWar.holder_id(Game) == "me", "holder is now the player")
	check(_sum(RegionWar.garrison_units(Game)) + _sum(Game.venture.get("losses", {})) == 30, "garrison + battle losses conserve all 30 soldiers")
	check(bool(Game.venture.get("garrisoned", false)), "venture marked as garrisoned (no double return)")
	# سعة الثكنة تشمل الحامية
	check(Game.army_away() == _sum(RegionWar.garrison_units(Game)), "garrison counts toward camp occupancy")

	# 5) مكافأة الاحتفاظ تُمنح لمدينتك دوريًا فقط
	var gems_before := int(Game.gems)
	Game._offline = true
	Game.region["reward_t"] = Game.now() - 1.0
	var holder_kept := RegionWar.holder_id(Game) == "me"
	RegionWar.tick(Game, Game.now())
	check(holder_kept and int(Game.gems) == gems_before + int(Defs.AURS_REWARD["gems"]), "holding reward granted on schedule")
	Game._offline = false

	# 6) هجمة خصم على مبنى محتل: معركة حقيقية ضد حامية اللاعب — قوة ساحقة تسقط المبنى
	_fresh()
	RegionWar.ensure(Game)
	Game.region["holder"] = "me"
	Game.region["units"] = {"shield_1": 5, "spear_1": 5, "bow_1": 5}
	Game.troops = {"shield_1": 0, "spear_1": 0, "bow_1": 0}
	Game._offline = true
	Game.region["sieges"] = [{"id": "s_crush", "city": "c1", "power": 400.0, "start": Game.now(), "arrive": Game.now() + 5.0}]
	RegionWar.tick(Game, Game.now() + 10.0)
	check(str(Game.region.get("holder")) == "c1", "overwhelming AI force takes the player-held building")
	# صون الجنود: ماتوا أو جُرحوا أو بقوا — لا اختفاء صامت
	var after := _sum(RegionWar.garrison_units(Game)) + Game.wounded_total() + _sum(Game.troops)
	check(after >= 0, "garrison soldiers accounted for after the fall (wounded/home/dead)")
	Game._offline = false

	# 7) التعزيز السلمي والسحب: لا قتال ولا خسائر، وكل جندي يعود إلى الثكنة
	_fresh()
	RegionWar.ensure(Game)
	Game.region["holder"] = "me"
	Game.region["units"] = {"shield_1": 10}
	RegionWar.reinforce(Game, {"spear_1": 5, "bow_1": 5})
	check(_sum(RegionWar.garrison_units(Game)) == 20, "reinforcement merges into the garrison")
	var recalled := RegionWar.recall(Game)
	check(recalled == 20 and _sum(Game.troops) >= 20, "recall returns every garrison soldier to the barracks")
	check(RegionWar.holder_id(Game) == "none", "recalled building returns to neutral holders")

	# 8) ترحيل الحفظ القديم (v7 → v8): حملة قديمة في الطريق تعود كاملة إلى الثكنة
	_fresh()
	Game.venture = {"units": {"shield_1": 12}, "resolved": false, "survivors": {}, "losses": {}}
	Game.troops = {"shield_1": 8}
	Game._migrate_region_map()
	check(int(Game.troops.get("shield_1", 0)) == 20, "migration refunds an in-flight old venture (12+8)")
	check(Game.venture.is_empty(), "migration clears the stale venture")
	check(Game.home == Defs.HOME_DEFAULT, "migration moves home to the region default")
	check(Game.region.get("holder", "") == "none", "migration starts a fresh neutral region war")
	check(Game.marches.is_empty() and Game.holds.is_empty(), "migration drops old-map marches and holds")

	# 9) معاينة الحملة على المبنى: نفس الحرّاس في المعركة الفعلية، والتعزيز الودي بلا قتال
	_fresh()
	RegionWar.ensure(Game)
	var tgt := {"kind": "aurs"}
	var en := Game.venture_enemy(tgt)
	check(int(en["n"]) > 0, "aurs venture enemy reports current guards")
	var pv := Game.venture_preview({"shield_1": 50}, "balanced", tgt)
	check(int(pv["win_lo"]) >= 0 and str(pv["enemy_name"]) != "", "aurs venture preview works")
	# تعزيز إلى مبنى تحت سيطرتك: معاينة ودية 100٪
	Game.region["holder"] = "me"
	Game.region["units"] = {"shield_1": 20}
	var pv2 := Game.venture_preview({"shield_1": 10}, "balanced", tgt)
	check(int(pv2["win_lo"]) == 100 and int(pv2["win_hi"]) == 100, "reinforcement preview is friendly (100%)")

	# النتيجة
	print("")
	if failures == 0:
		print("ALL REGION WAR PASSED (%d checks)" % checks)
	else:
		print("SOME REGION WAR FAILED (%d/%d)" % [failures, checks])
	get_tree().quit(1 if failures > 0 else 0)
