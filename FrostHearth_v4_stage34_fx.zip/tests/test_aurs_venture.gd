extends Node
## إعادة إنتاج تجمّد المستخدم: إرسال الجيش إلى «عرس الإقليم» ثم الوصول إليه
## سيناريو مطابق: اختيار عرس الإقليم ← نافذة البعثة ← إرسال ← عبور لحظة الوصول (معركة عرس الإقليم) ← العودة
const MarchTimers := preload("res://scripts/ui/march_timers.gd")
var m_failed := 0
var m_checks := 0
var m_pass := []

func _check(name: String, ok: bool) -> void:
	m_checks += 1
	if ok:
		m_pass.append(name)
	else:
		m_failed += 1
		push_error("FAILED: " + name)

func _poll_until(cond: Callable, timeout: float) -> bool:
	var deadline := Game.now() + timeout
	while Game.now() < deadline:
		await get_tree().process_frame
		if cond.call():
			return true
	return cond.call()

func _ready() -> void:
	Game.save_path_override = "user://frost_save_test_aurs.json"
	Game.new_game()
	Game.dev_mode = true
	for r in ["food", "wood", "coal", "iron"]:
		Game.res[r] = 100000.0
	Game.troops = {}
	for tp in ["shield", "spear", "bow"]:
		for t in range(1, 5):
			Game.troops["%s_%d" % [tp, t]] = 20
	Game.heroes["siraj"]["owned"] = true
	Game.defender = "siraj"
	var map_scene: PackedScene = load("res://world_map.tscn")
	var map: Node3D = map_scene.instantiate()
	add_child(map)
	await get_tree().process_frame
	await get_tree().process_frame

	# اختيار عرس الإقليم من الخريطة كما يفعل المستخدم
	var aurs_info := {}
	for tile in map.lookup:
		var info: Dictionary = map.lookup[tile]
		if str(info.get("kind", "")) == "aurs":
			aurs_info = info
			break
	_check("aurs tile found in map", not aurs_info.is_empty())
	map._select(aurs_info)
	map._on_action()   # يفتح نافذة البعثة لهدف عرس الإقليم
	await get_tree().process_frame
	await get_tree().process_frame
	# إرسال الجيش من النافذة الفعلية — أقوى تشكيل
	for k in map.vent_spins.keys():
		map.vent_spins[k].value = 20
	map._send_venture()
	_check("venture to aurs created", not Game.venture.is_empty())
	_check("venture target is aurs", str(Game.venture.get("target", {}).get("kind", "")) == "aurs")
	await get_tree().process_frame
	await get_tree().process_frame
	# مواعيد مستقبلية سليمة — عبور الوصول لا القفز فوقه
	var t0 := Game.now()
	Game.venture["arrive"] = t0 + 1.5
	Game.venture["leave"] = t0 + 5.0
	Game.venture["back"] = t0 + 9.0
	# إطارات قبل الوصول
	var seen_marching := false
	while Game.now() < float(Game.venture["arrive"]):
		await get_tree().process_frame
		seen_marching = true
	_check("frames processed before aurs arrival", seen_marching)
	_check("venture still active at arrival moment", not Game.venture.is_empty())
	# معركة عرس الإقليم عند الوصول — استقصاء
	var resolved := await _poll_until(func(): return bool(Game.venture.get("resolved", false)), 6.0)
	_check("aurs battle resolved at arrival", resolved)
	_check("venture report present", Game.venture.has("report"))
	# العودة والتصفية
	var returned := await _poll_until(func(): return Game.venture.is_empty(), 12.0)
	_check("venture returned and cleared", returned)
	# اللعبة تستجيب بعدها — إطار واحد على الأقل يعني الحلقة الرئيسية تعمل
	var frames := 0
	var resp_deadline := Game.now() + 1.0
	while Game.now() < resp_deadline:
		await get_tree().process_frame
		frames += 1
	print("FRAMES_IN_1S: %d" % frames)
	_check("game still responsive after aurs battle", frames > 0)

	map.free()
	await get_tree().process_frame
	if m_failed == 0:
		print("PASS: aurs venture crossing completed — %d checks" % m_checks)
		print("ALL_CHECKS: " + " | ".join(m_pass))
	else:
		print("FAILED: %d checks failed" % m_failed)
	get_tree().quit(1 if m_failed else 0)
