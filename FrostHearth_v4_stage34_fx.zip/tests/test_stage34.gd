extends Node
## Stage 34: مؤثرات الفرن والرياح — لهب برتقالي، شرر، دخان، هيكا، توهج، رياح، ومداخن المآوي.
## بصري فقط: لا يمس الحفظ ولا الاقتصاد ولا القتال.
var checks := 0
var failures := 0


func check(value: bool, message: String) -> void:
	checks += 1
	if not value:
		failures += 1
	print(("PASS: " if value else "FAIL: ") + message)


func frames(count: int = 4) -> void:
	for i in count:
		await get_tree().process_frame


func fresh() -> void:
	Game.save_path_override = "user://stage34_fx.json"
	Game.new_game()
	Game.set_process(false)
	Game.daily_ready = false
	Game.last_daily = Game._today()
	Game.offline_report = {}
	Game.raid_unseen = false
	Game.migration_note = {}
	Game.stats["built"] = 2


func make_city() -> Node:
	var city: Node = (load("res://city.tscn") as PackedScene).instantiate()
	get_tree().get_root().add_child.call_deferred(city)
	await city.ready
	await frames()
	return city


func test_structure() -> void:
	fresh()
	var city := await make_city()
	var fx: Node3D = city.furnace_fx
	check(fx != null and fx.is_inside_tree(), "furnace fx node is attached to the city")
	check(fx.position.is_equal_approx(Vector3(60, 0, 60)), "fx sits at the furnace position")
	check(city.smoke == fx.smoke, "city.smoke still points at the chimney smoke")
	check(fx.crown is CPUParticles3D and fx.tongue is CPUParticles3D and fx.sparks is CPUParticles3D, "flame and spark emitters exist")
	check(fx.door_flames.size() == 4, "four door flame emitters")
	check(fx.haze != null and fx.glow != null, "heat haze and ground glow exist")
	# اللون: اللهب برتقالي في منتصف العمر، وأبيض-أصفر عند الجذر
	var g: Gradient = fx.crown.color_ramp
	var mid: Color = g.sample(0.42)
	check(mid.r > 0.9 and mid.g > 0.35 and mid.g < 0.6 and mid.b < 0.2, "flame body color is orange")
	var root_c: Color = g.sample(0.10)
	check(root_c.g > mid.g, "flame root is hotter (yellower) than its body")
	check(city.fire_light.light_color.r > 0.9 and city.fire_light.light_color.b < 0.4, "fire light is warm orange")
	# الهندسة تطابق المولّد
	var g0: Dictionary = fx.geometry(0)
	check(absf(float(g0["mouth"]) - 8.9) < 0.01, "tier 0 chimney mouth matches build_city (8.9)")
	check(absf(float(fx.geometry(2)["mouth"]) - 14.1) < 0.01, "tier 2 chimney mouth matches build_city (14.1)")
	city.queue_free()
	await frames()


func test_modes() -> void:
	fresh()
	Game.res["coal"] = 500.0
	Game.furnace_mode = 1
	var city := await make_city()
	var fx: Node3D = city.furnace_fx
	await frames(6)
	check(fx.crown.emitting and fx.tongue.emitting and fx.smoke.emitting, "mode 1 with coal: flames and smoke emit")
	check(not fx.boost_sparks.emitting, "boost sparks off in normal mode")
	Game.furnace_mode = 2
	await frames(6)
	check(fx.boost_sparks.emitting, "boost mode adds extra sparks")
	Game.furnace_mode = 0
	await frames(6)
	check(not fx.crown.emitting and not fx.sparks.emitting and not fx.smoke.emitting, "furnace off: all fire emitters stop")
	Game.furnace_mode = 1
	Game.res["coal"] = 0.0
	await frames(6)
	check(not fx.crown.emitting, "no coal: flames stop")
	city.queue_free()
	await frames()


func test_wind_and_tiers() -> void:
	fresh()
	var city := await make_city()
	var fx: Node3D = city.furnace_fx
	for i in 120:
		fx.update(0.1, true, 1, 0, false, city.fire_light, 50.0)
	var calm: float = fx.wind_strength
	for i in 120:
		fx.update(0.1, true, 1, 0, true, city.fire_light, 50.0)
	check(fx.wind_strength > calm + 1.5, "storm makes the wind much stronger (%.2f > %.2f)" % [fx.wind_strength, calm])
	check(fx.smoke.gravity.x > 0.0, "smoke leans downwind")
	check(city.snow.direction.x > 0.12, "snowfall leans with the wind")
	fx.update(0.1, true, 1, 2, false, city.fire_light, 50.0)
	check(absf(fx.tongue.position.y - 14.1) < 0.01, "emitters move up with the furnace tier")
	fx.set_quality(false)
	check(fx.smoke.amount < int(fx.smoke.get_meta("base_amount")) and not fx.haze.visible, "low quality halves particles and hides haze")
	fx.set_quality(true)
	check(fx.smoke.amount == int(fx.smoke.get_meta("base_amount")) and fx.haze.visible, "high quality restores them")
	city.queue_free()
	await frames()


func test_chimneys() -> void:
	fresh()
	Game.plots["sh1"] = 6      # مرحلة بصرية 1 → مدخنة
	Game.plots["sh2"] = 2      # خيمة بلا مدخنة
	var city := await make_city()
	var fx: Node3D = city.furnace_fx
	check(fx.chimneys.size() == 1, "only the built house with a chimney gets smoke")
	Game.plots["sh1"] = 16     # مرحلة 2: تُستبدل المدخنة لا تتكرر
	city._refresh_plot("sh1")
	check(fx.chimneys.size() == 1, "chimney is replaced, not duplicated, on tier change")
	city.queue_free()
	await frames()


func _ready() -> void:
	get_window().size = Vector2i(720, 1280)
	await test_structure()
	await test_modes()
	await test_wind_and_tiers()
	await test_chimneys()
	print("RESULT: %d/%d" % [checks - failures, checks])
	get_tree().quit(0 if failures == 0 else 1)
