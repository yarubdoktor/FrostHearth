extends Node
## اختبار إرسال المسيرة في حالة لعبة غنية — عاصفة وحصارات ومنفث محتل وجرحى وبحث جارٍ
## التشغيل: godot --headless --path . res://tests/test_march_rich_state.tscn

var failed := 0
const RegionWar := preload("res://scripts/game/region_war.gd")

func _ck(tag: String) -> void:
	print("CK:" + tag)

func _fail(why: String) -> void:
	print("FAIL: " + why)
	failed += 1

func _ready() -> void:
	Game.save_path_override = "user://frost_save_test_rich.json"
	Game.new_game()
	Game.dev_mode = true
	for r in ["food", "wood", "coal", "iron"]:
		Game.res[r] = 100000.0
	Game.troops = {}
	for tp in ["shield", "spear", "bow"]:
		for t in range(1, 5):
			Game.troops["%s_%d" % [tp, t]] = 20
	# حالة غنية: جرحى وبحث وتجهيزات وعاصفة ومنفث محتل وحصارات
	Game.wounded = {"shield_1": 5, "spear_1": 3}
	Game.research = {"id": "tr_shield1", "lv": 1, "start": Game.now(), "end": Game.now() + 600.0}
	Game.gear_queue = [{"tp": "shield", "slot": "weapon", "start": Game.now(), "end": Game.now() + 300.0}]
	Game.storm_start = Game.now() - 60.0
	Game.storm_end = Game.now() + 300.0
	Game.vent["captured"] = true
	RegionWar.ensure(Game)
	Game.region["sieges"] = [{"id": "s_test", "city": "c1", "power": 500.0, "start": Game.now(), "arrive": Game.now() + 120.0}]
	Game.raid_next = Game.now() + 60.0
	RegionWar.tick(Game, Game.now())
	_ck("01 rich state ready (sieges=%d)" % Game.region.get("sieges", []).size())

	var map_scene: PackedScene = load("res://world_map.tscn")
	var map: Node3D = map_scene.instantiate()
	add_child(map)
	await get_tree().process_frame
	await get_tree().process_frame
	_ck("02 map loaded")

	var res_info := {}
	for tile in map.lookup:
		var info: Dictionary = map.lookup[tile]
		if str(info.get("kind", "")) == "res":
			res_info = info
			break
	if res_info.is_empty():
		_fail("no res site found")
	else:
		map._select(res_info)
		map._on_action()
		_ck("03 gather march sent")
		if Game.marches.is_empty():
			_fail("no march created")

	# فرقة عسكرية نحو عرس الإقليم والمنفث محتل (تعزيز الحامية)
	map._open_venture_window({"kind": "aurs", "n": "عرس الإقليم"})
	_ck("04 aurs venture window opened")
	if not map.vent_spins.is_empty():
		var k0: String = map.vent_spins.keys()[0]
		map.vent_spins[k0].value = 5
	map._send_venture()
	_ck("05 aurs venture sent")
	if Game.venture.is_empty():
		_fail("aurs venture not created")

	# دورات محاكاة متعددة مع الوقت الحقيقي — أي علة تظهر هنا كتوقف
	for i in 40:
		await get_tree().process_frame
		if i % 10 == 0:
			_ck("06 ticking %d (sieges=%d marches=%d)" % [i, Game.region.get("sieges", []).size(), Game.marches.size()])
	# محاكاة وصول الحصار (حل المعركة) عبر دفعة زمن يدوية
	Game._simulate(130.0, Game.now() + 130.0)
	_ck("07 offline-style simulate after siege arrival")
	for i in 10:
		await get_tree().process_frame
	_ck("08 frames after siege resolve (sieges=%d)" % Game.region.get("sieges", []).size())

	if failed == 0:
		print("PASS: rich-state march test completed")
	get_tree().quit(1 if failed > 0 else 0)
