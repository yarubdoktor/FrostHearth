extends Node
## إعادة إنتاج التجمّد عند وصول المسيرة إلى هدفها — دورة كاملة بمعالجات حقيقية
## نرسل مسيرات حقيقية عبر الواجهة، ثم نضبط مواعيدها بالمستقبل (start < arrive < leave < back)
## ونعبر لحظة الوصول إطاراً بإطار ونتحقق من كل مرحلة أثناء حدوثها، لا بعد اكتمالها فقط.
## النوافذ الزمنية تستخدم ساعة النظام (Game.now) لا مؤقتات المشهد، لتبقى صحيحة
## حتى على الأجهزة البطيئة أو الرسم البرمجي.
const MarchTimers := preload("res://scripts/ui/march_timers.gd")
var m_failed := 0
var m_checks := 0
var m_pass := []

func _check(name: String, ok: bool) -> void:
	m_checks += 1
	if ok:
		m_pass.append(name)
	else:
		m_failed += 1
		push_error("FAILED: " + name)

## ينتظر إطارات حتى شرط يتحقق أو مهلة ساعة النظام تنقضي — يعيد قيمة الشرط الأخيرة
func _poll_until(cond: Callable, timeout: float) -> bool:
	var deadline := Game.now() + timeout
	while Game.now() < deadline:
		await get_tree().process_frame
		if cond.call():
			return true
	return cond.call()

func _ready() -> void:
	Game.save_path_override = "user://frost_save_test_arrival.json"
	Game.new_game()
	Game.dev_mode = true
	for r in ["food", "wood", "coal", "iron"]:
		Game.res[r] = 100000.0
	Game.troops = {}
	for tp in ["shield", "spear", "bow"]:
		for t in range(1, 5):
			Game.troops["%s_%d" % [tp, t]] = 20
	Game.heroes["siraj"]["owned"] = true
	Game.defender = "siraj"
	var map_scene: PackedScene = load("res://world_map.tscn")
	var map: Node3D = map_scene.instantiate()
	add_child(map)
	await get_tree().process_frame
	await get_tree().process_frame

	# ---- 1) مسيرة جمع: عبور لحظة الوصول إطاراً بإطار
	var res_tiles := []
	for tile in map.lookup:
		var info: Dictionary = map.lookup[tile]
		if str(info.get("kind", "")) == "res":
			res_tiles.append(info)
	var hp: Vector3 = map.home_pos
	res_tiles.sort_custom(func(a, b): return (a["pos"] as Vector3).distance_to(hp) < (b["pos"] as Vector3).distance_to(hp))
	map._select(res_tiles[0])
	var n_before := Game.marches.size()
	map._on_action()
	_check("gather march created", Game.marches.size() == n_before + 1)
	var gm: Dictionary = Game.marches[Game.marches.size() - 1]
	_check("gather kind is res", str(gm["kind"]) == "res")
	await get_tree().process_frame
	# مواعيد مستقبلية بترتيب سليم — الاختبار يعبر الوصول لا يقفز فوقه
	var t0 := Game.now()
	gm["arrive"] = t0 + 1.5
	gm["leave"] = t0 + 5.0
	gm["back"] = t0 + 9.0
	_check("march times ordered", float(gm["start"]) < float(gm["arrive"]) and float(gm["arrive"]) < float(gm["leave"]) and float(gm["leave"]) < float(gm["back"]))
	var rt: String = str(res_tiles[0]["t"])
	var res_before := float(Game.res[rt])
	# عبور لحظة الوصول: إطارات قبل الوصول ثم التحقق أن المسيرة حية عندها
	var seen_marching := false
	while Game.now() < float(gm["arrive"]):
		await get_tree().process_frame
		seen_marching = true
	_check("frames processed before arrival", seen_marching)
	_check("march still active at arrival moment", Game.marches.has(gm))
	# أثناء العمل بعد الوصول: المرحلة «جمع» — نافذة ساعة نظام (3.5 ثانية عمل)
	var seen_work := false
	var work_deadline := Game.now() + 3.5
	while Game.now() < work_deadline and Game.marches.has(gm):
		await get_tree().process_frame
		var ph := MarchTimers.phase(gm, Game.now())
		if not ph.is_empty() and str(ph.get("caption", "")) == "جمع":
			seen_work = true
	_check("work phase observed after arrival", seen_work)
	_check("march alive during work window", Game.marches.has(gm))
	# بعد العودة: المكافأة والحذف — استقصاء حتى 8 ثوانٍ
	var removed := await _poll_until(func(): return not Game.marches.has(gm), 8.0)
	_check("gather march completed and removed", removed)
	_check("gather reward granted", float(Game.res[rt]) > res_before)

	# ---- 2) مسيرة استطلاع: كشف عند الوصول ثم عودة
	map._send_scout(res_tiles[1])
	var sm: Dictionary = Game.marches[Game.marches.size() - 1]
	_check("scout march created", str(sm["kind"]) == "scout" and Game.marches.has(sm))
	await get_tree().process_frame
	var t1 := Game.now()
	sm["arrive"] = t1 + 1.5
	sm["leave"] = t1 + 5.0
	sm["back"] = t1 + 9.0
	var revealed := await _poll_until(func(): return bool(sm.get("revealed", false)), 6.0)
	_check("scout revealed at arrival", revealed)
	var scout_done := await _poll_until(func(): return not Game.marches.has(sm), 10.0)
	_check("scout march completed and removed", scout_done)

	# ---- 3) بعثة (هجوم): معركة عند الوصول ثم عودة
	map._select(res_tiles[2])
	map._open_venture_window({})
	var k0: String = map.vent_spins.keys()[0]
	map.vent_spins[k0].value = 5
	map._send_venture()
	_check("venture created", not Game.venture.is_empty())
	await get_tree().process_frame
	await get_tree().process_frame
	var t2 := Game.now()
	Game.venture["arrive"] = t2 + 1.5
	Game.venture["leave"] = t2 + 5.0
	Game.venture["back"] = t2 + 9.0
	var resolved := await _poll_until(func(): return bool(Game.venture.get("resolved", false)), 6.0)
	_check("venture battle resolved at arrival", resolved)
	_check("venture still traveling back", not Game.venture.is_empty())
	var vent_done := await _poll_until(func(): return Game.venture.is_empty(), 10.0)
	_check("venture returned and cleared", vent_done)

	# ---- 4) اللعبة ما زلت تستجيب بعد كل ذلك — عد إطارات ضمن نافذة ساعة نظام
	var frames := 0
	var resp_deadline := Game.now() + 1.0
	while Game.now() < resp_deadline:
		await get_tree().process_frame
		frames += 1
	print("FRAMES_IN_1S: %d" % frames)
	# التجمّد الحقيقي (حلقة لا نهائية) يمنع عودة await إطلاقاً فيقتل المهلةُ الاختبار؛
	# معالجة إطار واحد على الأقل ضمن النافذة تعني أن الحلقة الرئيسية تعمل.
	_check("game still responsive", frames > 0)

	map.free()
	await get_tree().process_frame
	if m_failed == 0:
		print("PASS: arrival crossing repro completed — %d checks" % m_checks)
		print("ALL_CHECKS: " + " | ".join(m_pass))
	else:
		print("FAILED: %d checks failed" % m_failed)
	get_tree().quit(1 if m_failed else 0)
