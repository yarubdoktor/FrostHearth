extends Node
## فحص بصري سريع: الأبطال المملوكة يقفون أمام قاعة الأبطال — والجنود أمام ثكناتهم
## التشغيل: godot --headless --path . res://tests/test_hero_hall_visuals.tscn

var failed := 0

func _ready() -> void:
	Game.save_path_override = "user://frost_save_test_heroes.json"
	Game.new_game()
	Game.dev_mode = true
	for r in ["food", "wood", "coal", "iron"]:
		Game.res[r] = 100000.0
	# بناء قاعة الأبطال والثكنات وامتلاك أبطال
	Game.plots["hh1"] = 1
	Game.plots["bs1"] = 1
	Game.plots["bp1"] = 1
	Game.plots["ba1"] = 1
	Game.heroes["siraj"]["owned"] = true
	Game.heroes["layla"]["owned"] = true
	Game.troops["shield_1"] = 45
	Game.troops["spear_2"] = 20
	var city_scene: PackedScene = load("res://city.tscn")
	var city: Node3D = city_scene.instantiate()
	add_child(city)
	await get_tree().process_frame
	await get_tree().process_frame
	await get_tree().process_frame
	# الأبطال ظهروا أمام القاعة
	if city.hero_nodes.size() != 2:
		print("FAIL: expected 2 hero figures, got %d" % city.hero_nodes.size())
		failed += 1
	else:
		print("PASS: %d hero figures at the hall" % city.hero_nodes.size())
	# الجنود ظهروا (الدروع أمام ثكنتها والرماح أمام ثكنتها)
	if city.soldier_nodes.size() < 4:
		print("FAIL: expected soldiers, got %d" % city.soldier_nodes.size())
		failed += 1
	else:
		print("PASS: %d soldier figures in the camps" % city.soldier_nodes.size())
	# صور الجنود موجودة وتُحمّل
	for tp in ["shield", "spear", "bow"]:
		var tex: Texture2D = load("res://assets/ui/portrait_%s.png" % tp)
		if tex == null:
			print("FAIL: portrait missing for " + tp)
			failed += 1
	print("PASS: portraits load" if failed == 0 else "FAIL: portraits missing")
	# بطاقة الجيش تستخدم الصور
	if failed == 0:
		print("PASS: hero hall visuals test completed")
	get_tree().quit(1 if failed > 0 else 0)
