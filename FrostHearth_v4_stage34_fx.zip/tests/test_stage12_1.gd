extends Node
## المرحلة 12.1 (أعيدت كتابتها لتصميم الإقليم المصغّر):
## توزيع المدن والموارد — لا تراكب بين أي كيانين، وكل شيء مسجّل في شبكة التحديد، والحفظ يصمد.
var checks := 0
var failures := 0


func check(value: bool, message: String) -> void:
	checks += 1
	if not value:
		failures += 1
	print(("PASS: " if value else "FAIL: ") + message)


func _ready() -> void:
	Game.save_path_override = "user://frost_stage121_region_test_only.json"
	Game.new_game()
	Game.set_process(false)
	var map: Node3D = load("res://world_map.tscn").instantiate()
	add_child(map)
	await get_tree().process_frame
	await get_tree().process_frame

	# 1) لا تراكب بين أي زوج من الكيانات (مدن، موارد، وحوش، منفث، عرس الإقليم)
	var entities: Array = []
	for c in map.data["cities"]:
		entities.append([float(c["x"]), float(c["y"])])
	for r in map.data["resources"]:
		entities.append([float(r["x"]), float(r["y"])])
	for b in map.data["beasts"]:
		entities.append([float(b["x"]), float(b["y"])])
	entities.append([float(map.data["vent"]["x"]), float(map.data["vent"]["y"])])
	var collisions := 0
	for i in entities.size():
		for j in i:
			if Vector2(entities[i][0] - entities[j][0], entities[i][1] - entities[j][1]).length() < 3.0:
				collisions += 1
	check(collisions == 0, "no entity pair closer than three tiles")

	# 2) كل الموارد والوحوش مسجلة في شبكة التحديد ببياناتها الكاملة
	var resources_ok := true
	for r in map.data["resources"]:
		var tile := Vector2i(int(r["x"]), int(r["y"]))
		var e: Dictionary = map.lookup.get(tile, {})
		if e.get("kind", "") != "res" or e.get("t", "") != r["t"] or int(e.get("l", -1)) != int(r["l"]):
			resources_ok = false
	check(resources_ok, "every gathering site registered with full data")
	var beasts_ok := true
	for b in map.data["beasts"]:
		var tile := Vector2i(int(b["x"]), int(b["y"]))
		var e: Dictionary = map.lookup.get(tile, {})
		if e.get("kind", "") != "beast" or e.get("t", "") != b["t"]:
			beasts_ok = false
	check(beasts_ok, "every beast pack registered with full data")

	# 3) موقع مدينتي الافتراضي صالح: داخل حدود الإقليم وبعيد عن الكيانات الأخرى
	var home := Vector2i(Game.home.x, Game.home.y)
	check(home.x >= 2 and home.y >= 2 and home.x < 94 and home.y < 94, "default home inside the region")
	var home_clear := true
	for e in entities:
		if Vector2(e[0] - home.x, e[1] - home.y).length() < 3.0:
			home_clear = false
	check(home_clear, "default home clear of all other entities")

	# 4) مسيرة إلى مورد تعمل، ولا معالم قابلة للتحديد في شبكة الخريطة (أزيلت مع التصميم الجديد)
	var res0: Dictionary = map.data["resources"][0]
	var started := Game.start_march({"kind": "res", "t": res0["t"], "l": res0["l"], "x": int(res0["x"]), "y": int(res0["y"])})
	check(started and Game.marches.size() == 1, "march to a gathering site starts")
	var lm_tiles := 0
	for tile in map.lookup:
		if map.lookup[tile].get("kind", "") == "lm":
			lm_tiles += 1
	check(lm_tiles == 0, "no selectable landmark tiles remain in the region grid")

	# 5) حفظ وتحميل: موقع مدينتي والمسيرة يصمدان
	Game.save_game()
	check(Game.load_game(), "game reloads")
	check(Game.home == home, "home position persists through save/load")
	check(Game.marches.size() == 1, "active march persists through save/load")

	map.queue_free()
	await get_tree().process_frame
	DirAccess.remove_absolute(ProjectSettings.globalize_path(Game.save_path_override))
	print("STAGE12.1: %d checks, %d failures" % [checks, failures])
	get_tree().quit(1 if failures else 0)
