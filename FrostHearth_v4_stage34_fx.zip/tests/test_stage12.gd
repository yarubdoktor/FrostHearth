extends Node
## المرحلة 12 (أعيدت كتابتها لتصميم الإقليم المصغّر 96×96):
## البيئة الشتوية للإقليم — لا أخضر خارجي بعد الآن، وأربع مدن تتحارب على عرس الإقليم.
const CitySkins := preload("res://scripts/city_skins.gd")
var checks := 0
var failures := 0


func check(value: bool, message: String) -> void:
	checks += 1
	if not value:
		failures += 1
	print(("PASS: " if value else "FAIL: ") + message)


func _ready() -> void:
	Game.save_path_override = "user://frost_stage12_region_test_only.json"
	Game.new_game()
	Game.set_process(false)
	var map: Node3D = load("res://world_map.tscn").instantiate()
	add_child(map)
	await get_tree().process_frame
	await get_tree().process_frame

	# 1) إقليم مصغّر: ثلاث مدن خصوم + مدينتي
	check(map.data["cities"].size() == 3, "three rival cities in the region data")
	check(map.data["resources"].size() == 10, "ten gathering sites distributed")
	check(map.data["beasts"].size() == 3, "three beast packs distributed")
	check(map.data.get("landmarks", []).is_empty(), "no landmarks in the small region (by design)")

	# 2) البيئة الخضراء الخارجية أزيلت مع التصميم الجديد
	check(map.external_environment == null, "green exterior biome removed by region redesign")
	check(map.biome_button == null, "biome comparison button removed with the exterior")

	# 3) ثلج شتوي فعّال فوق الإقليم كله
	check(map.snow.visible and map.snow.emitting, "winter snow particles active over the region")

	# 4) مدينتي مسجلة عند موقعها مع سكنها المختار
	check(map.home_node != null, "home city node exists")
	check(map.home_node.mesh == map._mesh_from(CitySkins.mesh_path(Game.city_skin)), "home city uses the selected skin mesh")

	# 5) مدن الخصوم الثلاث مسجلة في شبكة التحديد كأهداف حرب
	var rival_count := 0
	for c in map.data["cities"]:
		var t: Vector2i = Vector2i(int(c["x"]), int(c["y"]))
		if map.lookup.has(t) and map.lookup[t].get("team", "") == "enemy":
			rival_count += 1
	check(rival_count == 3, "three rival cities registered as war targets")

	# 6) تبديل الليل/النهار يعمل على بيئة الخريطة
	check(not map.night, "map starts in daylight")
	map._toggle_night()
	await get_tree().process_frame
	check(map.night, "night mode toggles on")
	map._toggle_night()
	await get_tree().process_frame
	check(not map.night, "night mode toggles back off")

	# 7) كل الإقليم مكتشف بلا ضباب إخفاء (تصميم المنطقة الصغيرة)
	check(Game.is_explored(2, 2) and Game.is_explored(93, 93) and Game.is_explored(48, 48),
		"whole small region explored from the start")

	map.queue_free()
	await get_tree().process_frame
	DirAccess.remove_absolute(ProjectSettings.globalize_path(Game.save_path_override))
	print("STAGE12: %d checks, %d failures" % [checks, failures])
	get_tree().quit(1 if failures else 0)
