extends Node
## اختبار استنساخ تجمّد إرسال المسيرة — عبر مسار الواجهة الفعلي بالكامل مع نقاط تفتيش
## التشغيل: godot --headless --path . res://tests/test_freeze_repro.tscn

var failed := 0
const MarchTimers := preload("res://scripts/ui/march_timers.gd")

func _ck(tag: String) -> void:
	print("CK:" + tag)

func _fail(why: String) -> void:
	print("FAIL: " + why)
	failed += 1

func _ready() -> void:
	Game.save_path_override = "user://frost_save_test_freeze.json"
	Game.new_game()
	Game.dev_mode = true
	for r in ["food", "wood", "coal", "iron"]:
		Game.res[r] = 100000.0
	Game.troops = {}
	for tp in ["shield", "spear", "bow"]:
		for t in range(1, 5):
			Game.troops["%s_%d" % [tp, t]] = 20
	_ck("01 state ready")
	var map_scene: PackedScene = load("res://world_map.tscn")
	var map: Node3D = map_scene.instantiate()
	add_child(map)
	await get_tree().process_frame
	await get_tree().process_frame
	_ck("02 map loaded")

	# مسيرة عادية عبر المعالج الفعلي: اختيار ثم _on_action
	var res_info := {}
	for tile in map.lookup:
		var info: Dictionary = map.lookup[tile]
		if str(info.get("kind", "")) == "res":
			res_info = info
			break
	if res_info.is_empty():
		_fail("no res site found in lookup")
	else:
		_ck("03 selecting res site")
		map._select(res_info)
		_ck("04 selected")
		map._on_action()
		_ck("05 _on_action returned")
		if Game.marches.is_empty():
			_fail("no march created by _on_action")
	await get_tree().process_frame
	_ck("06 frame after march")
	await get_tree().process_frame
	_ck("07 second frame")

	# فرقة عسكرية عبر النافذة الفعلية ومعالج الإرسال الفعلي
	map._open_venture_window({})
	_ck("08 venture window opened")
	if map.vent_spins.is_empty():
		_fail("venture spins empty")
	else:
		var k0: String = map.vent_spins.keys()[0]
		map.vent_spins[k0].value = 5
		_ck("09 spin set")
	map._send_venture()
	_ck("10 _send_venture returned")
	if Game.venture.is_empty():
		_fail("venture not created by _send_venture")
	await get_tree().process_frame
	_ck("11 frame after venture")

	# تقدّم الزمن والمحاكاة — عدة دورات محاكاة 0.5 ثانية
	for i in 30:
		await get_tree().process_frame
		if i % 10 == 0:
			_ck("12 ticking %d (marches=%d)" % [i, Game.marches.size()])

	# التحقق: الفرقة تتحرك فعليًا على الخريطة — موضع المجسم يتغير بين الإطارات
	var march0: Dictionary = {}
	var key0 := ""
	if not Game.marches.is_empty():
		march0 = Game.marches[0]
		key0 = str(march0["start"])
		if not map.march_vis.has(key0):
			_fail("march visual missing")
		else:
			var troop0: Node3D = map.march_vis[key0]["troop"]
			var p0: Vector3 = troop0.global_position
			await get_tree().create_timer(1.2).timeout
			var p1: Vector3 = troop0.global_position
			var ph1: Dictionary = MarchTimers.phase(march0, Game.now())
			var travelling: bool = float(march0["arrive"]) > Game.now() or float(march0["back"]) > Game.now() + 1.0
			if travelling and p0.distance_to(p1) < 0.01:
				_fail("march troop did not move (p0=%s p1=%s)" % [str(p0), str(p1)])
			else:
				_ck("14 march troop moving (dist=%.2f caption=%s)" % [p0.distance_to(p1), str(ph1.get("caption", ""))])
	# دورة الحياة: الوصول والعودة والإزالة — تسريع الزمن ومحاكاة
	if not march0.is_empty():
		march0["arrive"] = Game.now() - 1.0
		march0["leave"] = Game.now() - 0.5
		march0["back"] = Game.now() - 0.1
		Game._simulate(0.5, Game.now())
		await get_tree().process_frame
		await get_tree().process_frame
		if not Game.marches.is_empty():
			_fail("march not removed after lifecycle fast-forward")
		else:
			_ck("15 march lifecycle completed and removed")
		if map.march_vis.has(key0):
			_fail("march visual not cleaned up")
		else:
			_ck("16 march visual cleaned up")
	var alive_vis: int = map.march_vis.size()
	if alive_vis == 0:
		_fail("no march visuals created")
	_ck("13 all frames ticked — marches: %d venture: %s vis: %d" % [Game.marches.size(), str(not Game.venture.is_empty()), alive_vis])
	if failed == 0:
		print("PASS: freeze repro completed via real handlers")
	get_tree().quit(1 if failed > 0 else 0)
